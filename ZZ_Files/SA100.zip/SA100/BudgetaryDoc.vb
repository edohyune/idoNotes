Imports System.Data
Imports DevExpress.XtraReports.UI

Public Class BudgetaryDoc
    Public Sub New()
        InitializeComponent()
    End Sub

    Public Sub New(ByVal dSet As DataSet)
        InitializeComponent()
        Me.SetDateSet(dSet)
    End Sub

    Public Sub SetDateSet(ByVal dSet As DataSet)
        'Select contract_no, plate_no, contract_date, brand, rental_ty
        '       model, vehicle_ty,
        '       frto_date = concat(from_date, '~', to_date),
        '       dept_name = dbo.fnDeptNm_BJC(dept),
        '       project_name = dbo.fnProjectNm_BJC(project),
        '       month_cnt = DateDiff(Month, from_date, to_date) + 1,
        '       contract_amount, emp_no, emp_name = dbo.fnEmpNm_BJC(emp_no),
        '       down_payment, cust_name = dbo.fnCustNm_BJC(cust),
        '       monthly_fee, usage
        '  From ga300
        ' Where contract_no = @doc_no

        'Select seq, pay_month, rental_fee, status, memoDtl=memo
        '  From ga310
        ' Where contract_no = @doc_no

        'master1
        DetailReport1.DataSource = dSet.Tables(1)

        bid_no.DataBindings.Add("Text", dSet.Tables(0), "bid_no")
        bid_date.DataBindings.Add("Text", dSet.Tables(0), "bid_date")
        sop_type.DataBindings.Add("Text", dSet.Tables(0), "sop_type")
        validity.DataBindings.Add("Text", dSet.Tables(0), "validity")
        rev.DataBindings.Add("Text", dSet.Tables(0), "rev")
        scope.DataBindings.Add("Text", dSet.Tables(0), "scope")
        memo.DataBindings.Add("Text", dSet.Tables(0), "memo")
        client.DataBindings.Add("Text", dSet.Tables(0), "client")
        client_name.DataBindings.Add("Text", dSet.Tables(0), "client_name")
        project_owner.DataBindings.Add("Text", dSet.Tables(0), "project_owner")
        project_name.DataBindings.Add("Text", dSet.Tables(0), "project_name")
        project_location.DataBindings.Add("Text", dSet.Tables(0), "project_location")
        invoice_to.DataBindings.Add("Text", dSet.Tables(0), "invoice_to")
        invoice_client.DataBindings.Add("Text", dSet.Tables(0), "invoice_client")
        invoice_addr.DataBindings.Add("Text", dSet.Tables(0), "invoice_addr")
        delivery_company.DataBindings.Add("Text", dSet.Tables(0), "delivery_company")
        company_name.DataBindings.Add("Text", dSet.Tables(0), "company_name")
        company_addr.DataBindings.Add("Text", dSet.Tables(0), "company_addr")
        delivery_term.DataBindings.Add("Text", dSet.Tables(0), "delivery_term")


        'detail1
        sq.DataBindings.Add("Text", dSet.Tables(1), "sq")
        job_desc.DataBindings.Add("Text", dSet.Tables(1), "job_desc")
        job_ref.DataBindings.Add("Text", dSet.Tables(1), "job_ref")
        qty.DataBindings.Add("Text", dSet.Tables(1), "qty", "{0:#,0}")
        memoDtl.DataBindings.Add("Text", dSet.Tables(1), "memo")


        'ImageBinding(dSet.Tables(0), img, "photo")
    End Sub

    Private Sub ImageBinding(ByVal dTable As DataTable, ByVal PictureBoxControl As DevExpress.XtraReports.UI.XRPictureBox, ByVal ImageField As String)
        If IsDBNull(dTable.Rows(0)(ImageField)) Then
            PictureBoxControl.Image = Nothing
        Else
            Dim photo() As Byte = dTable.Rows(0)(ImageField)
            Dim ms As New System.IO.MemoryStream(photo)
            PictureBoxControl.Image = New Bitmap(ms)
            PictureBoxControl.Sizing = DevExpress.XtraPrinting.ImageSizeMode.Squeeze
        End If
    End Sub

    Private Sub DetailReport_BeforePrint(sender As Object, e As Printing.PrintEventArgs)

    End Sub
End Class