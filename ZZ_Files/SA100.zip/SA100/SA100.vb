﻿Imports Frame9
Imports Base9
Imports Base9.Shared
Imports System.Data
Imports System.Net
Imports System.IO

Public Class SA100

    Private Sub SA100_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'bid_no.CodeNo = "SA100"
        'bid_no.CodeDateField = bid_date
        '
        startCustomFtp(Me.Name) 'FTP Inint
        '
        btn_show.Visible = False
        btn_hide.Visible = True
        '
        _SOPVisible(False)
    End Sub

    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
        Select Case mty
            Case MenuType.Open
                Me.Open()
                '
                g20.RowAutoHeight = True
                g30.RowAutoHeight = True
                '
                g30.ColumnReadOnly("lvl1") = True
                g30.ColumnReadOnly("lvl2") = True
                '
                Select Case sop_type.Text
                    Case "BJ006100"
                        If bugetary_status.Text = "FI020100" Then
                            bid_no.ReadOnly = False
                            rfq_no.ReadOnly = True
                            project_no.ReadOnly = True
                            g20.Editable = True
                            g30.Editable = True
                        Else
                            bid_no.ReadOnly = True
                            rfq_no.ReadOnly = True
                            project_no.ReadOnly = True
                            g20.Editable = False
                            g30.Editable = False
                        End If

                    Case "BJ006200"
                        If rfq_status.Text = "FI020100" Then
                            bid_no.ReadOnly = True
                            rfq_no.ReadOnly = False
                            project_no.ReadOnly = True
                            g20.Editable = True
                            g30.Editable = True
                        Else
                            bid_no.ReadOnly = True
                            rfq_no.ReadOnly = True
                            project_no.ReadOnly = True
                            g20.Editable = False
                            g30.Editable = False
                        End If
                    Case "BJ006300"
                        If final_status.Text = "FI020100" Then
                            bid_no.ReadOnly = True
                            rfq_no.ReadOnly = True
                            project_no.ReadOnly = False
                            g20.Editable = True
                            g30.Editable = True
                        Else
                            bid_no.ReadOnly = True
                            rfq_no.ReadOnly = True
                            project_no.ReadOnly = True
                            g20.Editable = False
                            g30.Editable = False
                        End If
                End Select

            'Case MenuType.Print
            '    Me.Print()

            Case MenuType.New
                New_Form()

            Case MenuType.Save
                If Not CheckRequired(sop_type) Then
                    Exit Select
                End If
                '
                If sop_type.Text = "BJ006100" Then
                    If Not CheckRequired(bid_no) Then
                        Exit Sub
                    End If
                ElseIf sop_type.Text = "BJ006200" Then
                    If Not CheckRequired(rfq_no) Then
                        Exit Sub
                    End If
                ElseIf sop_type.Text = "BJ006300" Then
                    If Not CheckRequired(project_no) Then
                        Exit Sub
                    End If
                End If
                '
                If Me.Save() Then
                    Dim finder As String = bid_no.Text
                    Me.Open()
                    g10.Find("bid_no=" + finder)
                End If

            Case Else
                MyBase.MenuButton_Click(mty)
        End Select

    End Sub

    Private Sub New_Form()
        bid_no.Text = ""
        sop_type.Text = "BJ006100"
        OpenTrigger("sa100_g10")
        _ReadOnly(False)
    End Sub

    Private Sub _Open()
        Dim finder As String = bid_no.Text
        Me.Open()
        g10.Find("bid_no=" + finder)
    End Sub

    Public m_stop_event As Boolean
    Private Sub g10_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g10.AfterMoveRow
        Select Case g10.Text("sop_type", RowIndex)
            Case "BJ006100"
                If g10.Text("bugetary_status") = "FI020100" Then
                    bid_no.ReadOnly = False
                    rfq_no.ReadOnly = True
                    project_no.ReadOnly = True
                    g20.Editable = True
                    g30.Editable = True
                Else
                    bid_no.ReadOnly = True
                    rfq_no.ReadOnly = True
                    project_no.ReadOnly = True
                    g20.Editable = False
                    g30.Editable = False
                End If

            Case "BJ006200"
                If g10.Text("rfq_status") = "FI020100" Then
                    bid_no.ReadOnly = True
                    rfq_no.ReadOnly = False
                    project_no.ReadOnly = True
                    g20.Editable = True
                    g30.Editable = True
                Else
                    bid_no.ReadOnly = True
                    rfq_no.ReadOnly = True
                    project_no.ReadOnly = True
                    g20.Editable = False
                    g30.Editable = False
                End If
            Case "BJ006300"
                If g10.Text("final_status") = "FI020100" Then
                    bid_no.ReadOnly = True
                    rfq_no.ReadOnly = True
                    project_no.ReadOnly = False
                    g20.Editable = True
                    g30.Editable = True
                Else
                    bid_no.ReadOnly = True
                    rfq_no.ReadOnly = True
                    project_no.ReadOnly = True
                    g20.Editable = False
                    g30.Editable = False
                End If
        End Select
        '
        If g10.Text("final_status", RowIndex) > "FI020100" Then
            _ReadOnly(True)
            btn_groupware.Enabled = False
            project_no.ReadOnly = True
        Else
            _ReadOnly(False)
            btn_groupware.Enabled = True
            project_no.ReadOnly = False
        End If
        '
        g30.ColumnReadOnly("lvl1") = True
        g30.ColumnReadOnly("lvl2") = True
    End Sub

    Private Sub XtraTabControl1_Click(sender As Object, e As EventArgs) Handles XtraTabControl1.Click
        If XtraTabControl1.SelectedTabPageIndex = 1 Then
            _SOPVisible(True)
        Else
            _SOPVisible(False)
        End If
    End Sub

    'Private Sub btn_groupware_Click(sender As Object, e As EventArgs) Handles btn_groupware.Click
    '    If m_stop_event Then Exit Sub
    '    '
    '    m_stop_event = True
    '    '
    '    If bid_no.Text = "" Then
    '        Exit Sub
    '    End If

    '    Dim dset As DataSet
    '    dset = OpenDataSet("sa100_approval1")

    '    If DataValue(dset, "rtn") = "OK" Then
    '        m_stop_event = False
    '        PutMessage("BJC100_14", "It has been submitted for electronic approval.")
    '        Dim finder As String = bid_no.Text
    '        Me.Open()
    '        g10.Find("bid_no = " + finder)
    '        Exit Sub
    '    End If
    '    '
    '    m_stop_event = False
    'End Sub

    Private Sub btn_apply_Click(sender As Object, e As EventArgs) Handles btn_apply.Click
        If g30.RowCount < 1 Then
            Dim dSet As DataSet = Me.OpenDataSet("sa100_create")
            '
            If Not IsEmpty(dSet) Then
                Dim i As Integer = 0
                For Each dRow As DataRow In dSet.Tables(0).Rows
                    g30.AddNewRow()
                    g30.Text("lvl1") = ToStr(dRow("lvl1"))
                    g30.Text("lvl2") = ToStr(dRow("lvl2"))
                    g30.Text("work_desc") = ToStr(dRow("dsc"))
                    'g30.Text("dept") = ToStr(dRow("dept"))
                Next
            End If
        End If
    End Sub

    Private Sub currency_TextChanged(sender As Object, e As EventArgs) Handles currency.TextChanged
        If m_stop_event Then Exit Sub
        Dim dSet As DataSet = Me.OpenDataSet("sa100_exRt")
        If dSet.Tables(0).Rows(0)("rtn") = "ERROR" Then
            m_stop_event = False
            PutMessage("", "Exchange rate is not registered.")
            currency.Text = ""
            currency_rate.Text = 1.0
            Exit Sub
        Else
            If dSet.Tables(0).Rows(0)("rtn") = "OK" Then
                m_stop_event = False
                currency_rate.Text = dSet.Tables(0).Rows(0)("currency_rate")
                Exit Sub
            End If
        End If
    End Sub

    Private Sub status_TextChanged(sender As Object, e As EventArgs)
        'If bugetary_status.Text = "FI020100" Then
        '    _ReadOnly(False)
        'Else
        '    _ReadOnly(True)
        'End If
    End Sub

    Private Sub btn_jump_Click(sender As Object, e As EventArgs)
        Dim menuName As String = "SA110"
        Dim ctr As Object = Parameter.MainFrame.Frame.CallMenuForm(menuName)
        If Not ctr Is Nothing Then ctr.Open2(bid_no.Text)
        'Parameter.MainFrame.Frame.todialogform(ctr, False) '팝업으로 창을 띄웁니다. ‘True면 모달, False면 비모달 
    End Sub

    Private Sub btn_hide_Click(sender As Object, e As EventArgs) Handles btn_hide.Click
        SplitContainer2.Panel1Collapsed = True
        btn_show.Visible = True
        btn_hide.Visible = False
        'SplitContainer3.Panel2Collapsed = True
    End Sub

    Private Sub btn_show_Click(sender As Object, e As EventArgs) Handles btn_show.Click
        SplitContainer2.Panel1Collapsed = False
        btn_show.Visible = False
        btn_hide.Visible = True
        'SplitContainer3.Panel2Collapsed = False
    End Sub

    Private Sub sop_type_TextChanged(sender As Object, oldValue As String) Handles sop_type.TextChanged
        If sop_type.Text = "BJ006200" Then
            If bugetary_status.Text <> "FI020300" Then
                PutMessage("BJC100_32", "Previous step approval has not been completed.")
                _Open()
                Exit Sub
            ElseIf final_status.Text >= "FI020100" Then
                PutMessage("BJC100_33", "You cannot return to the previous step.")
                _Open()
                Exit Sub
            End If
            '
            bid_no.ReadOnly = True
            rfq_no.ReadOnly = False
            project_no.ReadOnly = True
            g20.Editable = True
            g30.Editable = True
        ElseIf sop_type.Text = "BJ006300" Then
            If rfq_status.Text <> "FI020300" Then
                PutMessage("BJC100_32", "Previous step approval has not been completed.")
                _Open()
                Exit Sub
            End If
            '
            bid_no.ReadOnly = True
            rfq_no.ReadOnly = True
            project_no.ReadOnly = False
            g20.Editable = True
            g30.Editable = True
        ElseIf sop_type.Text = "BJ006100" And bid_no.Text <> "" Then
            If bugetary_status.Text >= "FI020100" Then
                PutMessage("BJC100_33", "You cannot return to the previous step.")
                _Open()
                Exit Sub
            End If
            '
            bid_no.ReadOnly = False
            rfq_no.ReadOnly = True
            project_no.ReadOnly = True
            g20.Editable = True
            g30.Editable = True
        Else
            bid_no.ReadOnly = False
            rfq_no.ReadOnly = True
            project_no.ReadOnly = True
            g20.Editable = True
            g30.Editable = True
        End If
    End Sub

    Private Sub _ReadOnly(ByVal ref As Boolean)
        'bid_no.ReadOnly = ref
        bid_date.ReadOnly = ref
        rev.ReadOnly = ref
        validity.ReadOnly = ref
        invoice_to.ReadOnly = ref
        delivery_term.ReadOnly = ref
        delivery_company.ReadOnly = ref
        scope.ReadOnly = ref
        memo.ReadOnly = ref
        client.ReadOnly = ref
        project_owner.ReadOnly = ref
        project_name.ReadOnly = ref
        project_location.ReadOnly = ref
        'rfq_no.ReadOnly = ref
        'project_no.ReadOnly = ref
        sop_type.ReadOnly = ref
    End Sub

    Private Sub _SOPVisible(ByVal ref As Boolean)
        temp_cd.Visible = ref
        temp_name.Visible = ref
        btn_apply.Visible = ref
    End Sub

    Private Sub g30_AddedRow(sender As Object, RowIndex As Integer) Handles g30.AddedRow
        g30.ColumnReadOnly("lvl1") = False
        g30.ColumnReadOnly("lvl2") = False
    End Sub


#Region "Approval Button =========================================  Edit"
    'Connect to Handles
    Private Sub btn_groupware_Click(sender As Object, e As EventArgs) Handles btn_groupware.Click
        If Not CheckRequired(sop_type) Then
            Exit Sub
        End If
        '
        If sop_type.Text = "BJ006100" Then
            If Not CheckRequired(bid_no) Then
                Exit Sub
            End If
        ElseIf sop_type.Text = "BJ006200" Then
            If Not CheckRequired(rfq_no) Then
                Exit Sub
            End If
        ElseIf sop_type.Text = "BJ006300" Then
            If Not CheckRequired(project_no) Then
                Exit Sub
            End If
        End If

        If Me.Save() Then
            If m_stop_event Then Exit Sub

            'Current Document Parameters Value Setting
            Dim docNo As String = Nothing
            Dim docDt As String = Nothing
            Dim empNo As String = Nothing
            Dim deptCd As String = Nothing
            Dim fileYn As String = "0"

            If cuFtp.RowCount > 0 Then
                fileYn = "1"
            End If

            Select Case sop_type.Text
                Case "BJ006100" 'Budgetary      BJ006100
                    docNo = bid_no.Text
                    docDt = bid_date.Text
                    empNo = ""
                    deptCd = ""
                Case "BJ006200" 'Official RFQ	BJ006200
                    docNo = rfq_no.Text
                    docDt = Today.ToString("yyyy-MM-dd")
                    empNo = ""
                    deptCd = ""
                Case "BJ006300" 'Final Proposal	BJ006300
                    docNo = project_no.Text
                    docDt = Today.ToString("yyyy-MM-dd")
                    empNo = ""
                    deptCd = ""
            End Select
            Dim rtnGroupWareProcess As String = groupWareProcess(sop_type.Text, docNo, docDt, empNo, deptCd, fileYn)
            If rtnGroupWareProcess = "OK" Then
                m_stop_event = False
                PutMessage("BJC100_24", "It has been processed succeed.")
                Dim find As String = bid_no.Text
                Me.Open()
                g10.Find("bid_no=" + find)
                Exit Sub
            End If
        End If
    End Sub

    Private Function groupWareProcess(sopTy As String, docNo As String, docDt As String, empNo As String, deptCd As String, fileYn As String) As String

        Dim frmCd As String = Me.Name
        Dim dinitSet As System.Data.DataSet = Nothing

        Select Case sopTy
            Case "BJ006100" 'Budgetary      BJ006100
                dinitSet = MyBase.OpenDataSet("sa100_appBudInit")
                If IsEmpty(dinitSet) Then Return "disiSet을 구성하는데 에러가 있습니다."
            Case "BJ006200" 'Official RFQ	BJ006200
                dinitSet = MyBase.OpenDataSet("sa100_appRFQInit")
                If IsEmpty(dinitSet) Then Return "disiSet을 구성하는데 에러가 있습니다."
            Case "BJ006300" 'Final Proposal	BJ006300
                dinitSet = MyBase.OpenDataSet("sa100_appFNLInit")
                If IsEmpty(dinitSet) Then Return "disiSet을 구성하는데 에러가 있습니다."
        End Select

        Dim gwNo As String = DataValue(dinitSet, "doc_code")
        Dim docStat As String = DataValue(dinitSet, "doc_status")
        Dim tblNm As String = DataValue(dinitSet, "table_name")

        If empNo = "" Then
            empNo = DataValue(dinitSet, "emp_no")
        End If
        If deptCd = "" Then
            deptCd = DataValue(dinitSet, "dept_cd")
        End If

        Dim p As OpenParameters = New OpenParameters
        p.Add("@form_name", frmCd)
        p.Add("@table_name", tblNm)
        p.Add("@doc_code", gwNo)
        p.Add("@doc_no", docNo)
        p.Add("@doc_date", docDt)
        p.Add("@dept", deptCd)
        p.Add("@emp_no", empNo)
        p.Add("@doc_stat", docStat)
        p.Add("@file_yn", fileYn)

        Dim dSet1 As DataSet = Nothing
        Select Case sopTy
            Case "BJ006100" 'Budgetary      BJ006100
                dSet1 = OpenDataSet("sa100_appBudHtml", p)
            Case "BJ006200" 'Official RFQ	BJ006200
                dSet1 = OpenDataSet("sa100_appRFQHtml", p)
            Case "BJ006300" 'Final Proposal	BJ006300
                dSet1 = OpenDataSet("sa100_appFNLHtml", p)
        End Select

        If IsEmpty(dSet1) Then
            Return "Error in " + frmCd + "_approvalHtml"
        End If

        If Directory.Exists("c:\temp\") = False Then
            Directory.CreateDirectory("c:\temp\")
        End If

        Dim htmlId As String = Guid.NewGuid().ToString("N")
        Dim fileNm As String = "c:\temp\" + htmlId + ".html"


        Select Case sopTy
            Case "BJ006100" 'Budgetary      BJ006100
                Dim RptBud As New BudgetaryDoc(dSet1)
                RptBud.CreateDocument()
                RptBud.ExportToHtml(fileNm)
            Case "BJ006200" 'Official RFQ	BJ006200
                Dim RptRFQ As New OfficialRFQ(dSet1)
                RptRFQ.CreateDocument()
                RptRFQ.ExportToHtml(fileNm)
            Case "BJ006300" 'Final Proposal	BJ006300
                Dim RptFnl As New FinalProposal(dSet1)
                RptFnl.CreateDocument()
                RptFnl.ExportToHtml(fileNm)
        End Select

        Dim client As New WebClient
                client.Encoding = System.Text.Encoding.UTF8
        Dim html As String = client.DownloadString(New Uri(fileNm))

        html = Replace(html, "'", "''")

        p.Add("@htm", html)

        Dim dset2 As DataSet = Nothing
        Select Case sopTy
            Case "BJ006100" 'Budgetary      BJ006100
                dset2 = OpenDataSet("sa100_appBudSubmit", p)
            Case "BJ006200" 'Official RFQ	BJ006200
                dset2 = OpenDataSet("sa100_appRFQSubmit", p)
            Case "BJ006300" 'Final Proposal	BJ006300
                dset2 = OpenDataSet("sa100_appFNLSubmit", p)
        End Select

        If IsEmpty(dset2) Then
            Return frmCd + "_approvalSubmit ERROR"
        Else
            Return DataValue(dset2, "rtn")
        End If

    End Function
#End Region
#Region "Custom FTP"
    Private cuFtpid As String, cuFtpip As String, cuFtppwd As String, cuFtproot As String, cuFtppath As String, cuFtpfullpath As String, cuLocalpath As String, cuFrmcd As String

    Private Sub startCustomFtp(frmCd As String)
        '0. FB100을 참고하여 만들었음
        '1. Grid 이름은 cuFtp
        '2. FormLoad시 startCustomFtp(Me.Name) 호출
        '3. GLBFTP에서 WorkSet Copy ([formName]_cuFtp, [formName]_ftpInfo)
        '* FTP path information에는 셋팅하지 않는다. 

        cuFtp.AllowDrop = True
        cuFtp.AllowAddRows = True
        cuFtp.AllowDeleteRows = True

        Dim strinfo As String = frmCd + "_ftpInfo"
        Dim dset As DataSet = OpenDataSet(strinfo)

        If IsEmpty(dset) Then
            Exit Sub
        End If

        cuFtpip = DataValue(dset, "cuFtpip").ToString()
        cuFtpid = DataValue(dset, "cuFtpid").ToString()
        cuFtppwd = DataValue(dset, "cuFtppwd").ToString()
        cuFtproot = DataValue(dset, "cuFtproot").ToString()
        cuFtppath = DataValue(dset, "cuFtproot").ToString() + Year(Today).ToString + Format(Today, "MM")
        cuLocalpath = DataValue(dset, "cuLocalpath").ToString()
        cuFtpfullpath = cuFtpip + cuFtproot + Year(Today).ToString + Format(Today, "MM")
        cuFrmcd = frmCd

        CreateFTPDirectory(cuFtpip + cuFtproot, cuFtpid, cuFtppwd)
        CreateFTPDirectory(cuFtpip + cuFtproot + Year(Today).ToString + Format(Today, "MM"), cuFtpid, cuFtppwd)
    End Sub

    Private Sub CreateFTPDirectory(cuFtpfullpath As String, cuFtpid As String, cuFtppwd As String)
        Try
            Dim request As FtpWebRequest = FtpWebRequest.Create(cuFtpfullpath)
            request.Method = WebRequestMethods.Ftp.MakeDirectory
            request.Credentials = New NetworkCredential(cuFtpid, cuFtppwd)
            Using response = DirectCast(request.GetResponse(), FtpWebResponse)
            End Using
        Catch ex As WebException
            If TypeOf ex.Response Is FtpWebResponse Then
                Dim response As FtpWebResponse = DirectCast(ex.Response, FtpWebResponse)
                If response.StatusCode = FtpStatusCode.ActionNotTakenFileUnavailable Then
                Else
                    Throw
                End If
            Else
                Throw
            End If
        End Try
    End Sub

    Private Sub cuFtp_ButtonPressed(ByVal sender As Object, ByVal columnName As String)
        Dim fileId As String = cuFtp.Text("fid")
        Dim filePath As String = cuFtp.Text("fPath")
        Dim fileNm As String = cuFtp.Text("fNm")      'LOG 생성에 사용된다.
        Dim filefrmNm As String = cuFtp.Text("frmNm") 'LOG 생성에 사용된다.

        If columnName = "upload" AndAlso fileId = "" Then
            If Not MyBase.Save() Then
                Exit Sub
            End If

            Dim fullPath As String = ""

            Try
                Dim OpenDialog As New OpenFileDialog
                OpenDialog.Filter = "All files (*.*)|*.*"
                OpenDialog.Multiselect = False

                If OpenDialog.ShowDialog = DialogResult.OK Then
                    fullPath = OpenDialog.FileName
                End If

            Catch ex As Exception

            End Try

            If fullPath = "" Then Exit Sub

            fileId = [FTPShared].FileUpload("", fullPath)

            If fileId <> "" Then

                fileId = System9.FTPShared.FileUpload(cuFtppath, fullPath, cuFrmcd, False, False)

                Dim f As New System.IO.FileInfo(fullPath)

                cuFtp.Text("fid") = fileId
                cuFtp.Text("fPath") = cuFtppath
                cuFtp.Text("fNm") = System.IO.Path.GetFileName(fullPath)
                cuFtp.Text("fSize") = f.Length.ToString()
                cuFtp.Text("fExt") = System.IO.Path.GetExtension(fullPath)
                cuFtp.Text("frmNm") = cuFrmcd

                cuFtp.Save()
                cuFtp.Open()
            End If


            Exit Sub
        End If

        If fileNm = "" Then
            Exit Sub
        End If


        If columnName = "del" Then
            Try
                If System9.FTPShared.FileDelete(fileId, fileNm, filePath, cuFrmcd, False) = True Then
                    cuFtp.AllowDeleteRows = True
                    cuFtp.DeleteRow(cuFtp.RowIndex)
                    cuFtp.AllowDeleteRows = False
                    Me.Save(cuFtp.WorkSet)
                End If
            Catch ex As Exception
                MessageInfo(ex)
            End Try

        End If

        If columnName = "show" Then
            System9.FTPShared.FileDownLoad(fileId, fileNm, filePath, True, cuFrmcd, cuLocalpath)
        End If

        If columnName = "down" Then
            System9.FTPShared.FileDownLoad(fileId, fileNm, filePath, False, cuFrmcd, cuLocalpath)
        End If
    End Sub


    Private Sub cuFtp_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs)
        If e.Data.GetDataPresent(DataFormats.FileDrop.ToString) Then
            If Not MyBase.Save() Then
                Exit Sub
            End If

            Dim fullPath As String
            cuFtp.AllowAddRows = True
            For Each fullPath In e.Data.GetData(DataFormats.FileDrop)
                Dim FileID As String = System9.FTPShared.FileUpload(cuFtppath, fullPath, cuFrmcd, False, False)
                If FileID <> "" And fullPath <> "" Then
                    Dim f As New System.IO.FileInfo(fullPath)
                    cuFtp.AddNewRow()
                    cuFtp.Text("fid") = FileID
                    cuFtp.Text("fPath") = cuFtppath
                    cuFtp.Text("fNm") = System.IO.Path.GetFileName(fullPath)
                    cuFtp.Text("fSize") = f.Length.ToString()
                    cuFtp.Text("fExt") = System.IO.Path.GetExtension(fullPath)
                    cuFtp.Text("frmNm") = cuFrmcd
                End If
            Next
            cuFtp.AllowAddRows = False
            Me.Save(cuFtp.WorkSet)
            cuFtp.Open()
        End If
    End Sub

    Private Sub cuFtp_DragOver(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs)
        If e.Data.GetDataPresent(DataFormats.FileDrop.ToString) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub

#End Region
End Class
