<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SA100
    Inherits Base9.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame9.ePanel()
        Me.btn_apply = New Frame9.eButton()
        Me.temp_name = New Frame9.eText()
        Me.temp_cd = New Frame9.eText()
        Me.btn_groupware = New Frame9.eButton()
        Me.f_sop_type = New Frame9.eCheckCombo()
        Me.f_status = New Frame9.eCheckCombo()
        Me.f_client = New Frame9.eText()
        Me.f_project_no = New Frame9.eText()
        Me.f_project_name = New Frame9.eText()
        Me.f_to_dt = New Frame9.eDate()
        Me.f_fr_dt = New Frame9.eDate()
        Me.f_category = New Frame9.eCheckCombo()
        Me.f_bid_no = New Frame9.eText()
        Me.f_rfq_no = New Frame9.eText()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.g10 = New Frame9.eGrid()
        Me.EPanel4 = New Frame9.ePanel()
        Me.final_status = New Frame9.eCombo()
        Me.rfq_status = New Frame9.eCombo()
        Me.btn_hide = New Frame9.eButton()
        Me.sop_type = New Frame9.eOptionBox()
        Me.client_name = New Frame9.eText()
        Me.project_location = New Frame9.eText()
        Me.project_name = New Frame9.eText()
        Me.project_owner = New Frame9.eText()
        Me.bugetary_status = New Frame9.eCombo()
        Me.validity = New Frame9.eText()
        Me.bid_date = New Frame9.eDate()
        Me.project_no = New Frame9.eText()
        Me.rfq_no = New Frame9.eText()
        Me.scope = New Frame9.eText()
        Me.rev = New Frame9.eText()
        Me.client = New Frame9.eText()
        Me.memo = New Frame9.eMemo()
        Me.bid_no = New Frame9.eText()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.invoice_to = New Frame9.eText()
        Me.invoice_addr = New Frame9.eMemo()
        Me.invoice_client = New Frame9.eMemo()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.delivery_company = New Frame9.eText()
        Me.company_addr = New Frame9.eMemo()
        Me.company_name = New Frame9.eMemo()
        Me.delivery_term = New Frame9.eText()
        Me.EPanel2 = New Frame9.ePanel()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.g20 = New Frame9.eGrid()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.EPanel3 = New Frame9.ePanel()
        Me.pid = New Frame9.eText()
        Me.rt_profit = New Frame9.eText()
        Me.rt_sga = New Frame9.eText()
        Me.rt_cogs = New Frame9.eText()
        Me.rt_indir = New Frame9.eText()
        Me.rt_equip = New Frame9.eText()
        Me.rt_tc = New Frame9.eText()
        Me.currency_rate = New Frame9.eText()
        Me.currency = New Frame9.eCombo()
        Me.g30 = New Frame9.eGrid()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.cuFtp = New Frame9.eGrid()
        Me.btn_show = New Frame9.eButton()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.XtraTabPage3.SuspendLayout()
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1900, 900)
        Me.SplitContainer1.SplitterDistance = 78
        Me.SplitContainer1.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.btn_apply)
        Me.EPanel1.Controls.Add(Me.temp_name)
        Me.EPanel1.Controls.Add(Me.temp_cd)
        Me.EPanel1.Controls.Add(Me.btn_groupware)
        Me.EPanel1.Controls.Add(Me.f_sop_type)
        Me.EPanel1.Controls.Add(Me.f_status)
        Me.EPanel1.Controls.Add(Me.f_client)
        Me.EPanel1.Controls.Add(Me.f_project_no)
        Me.EPanel1.Controls.Add(Me.f_project_name)
        Me.EPanel1.Controls.Add(Me.f_to_dt)
        Me.EPanel1.Controls.Add(Me.f_fr_dt)
        Me.EPanel1.Controls.Add(Me.f_category)
        Me.EPanel1.Controls.Add(Me.f_bid_no)
        Me.EPanel1.Controls.Add(Me.f_rfq_no)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1900, 78)
        Me.EPanel1.TabIndex = 1
        Me.EPanel1.Text = "     Search"
        '
        'btn_apply
        '
        Me.btn_apply.Location = New System.Drawing.Point(1600, 22)
        Me.btn_apply.Name = "btn_apply"
        Me.btn_apply.Size = New System.Drawing.Size(75, 23)
        Me.btn_apply.TabIndex = 27
        Me.btn_apply.Text = "Apply"
        '
        'temp_name
        '
        Me.temp_name.Location = New System.Drawing.Point(1359, 24)
        Me.temp_name.Name = "temp_name"
        Me.temp_name.Size = New System.Drawing.Size(235, 20)
        Me.temp_name.TabIndex = 26
        Me.temp_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.temp_name.Title = "SOP Template Name"
        Me.temp_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.temp_name.TitleWidth = 0
        '
        'temp_cd
        '
        Me.temp_cd.Location = New System.Drawing.Point(1133, 24)
        Me.temp_cd.Name = "temp_cd"
        Me.temp_cd.Size = New System.Drawing.Size(220, 20)
        Me.temp_cd.TabIndex = 25
        Me.temp_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.temp_cd.Title = "SOP Template"
        Me.temp_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.temp_cd.TitleWidth = 100
        '
        'btn_groupware
        '
        Me.btn_groupware.Appearance.Options.UseTextOptions = True
        Me.btn_groupware.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
        Me.btn_groupware.Location = New System.Drawing.Point(1710, 30)
        Me.btn_groupware.Name = "btn_groupware"
        Me.btn_groupware.Size = New System.Drawing.Size(133, 43)
        Me.btn_groupware.TabIndex = 24
        Me.btn_groupware.Text = "Approval Request (Groupware)"
        '
        'f_sop_type
        '
        Me.f_sop_type.Location = New System.Drawing.Point(907, 47)
        Me.f_sop_type.Name = "f_sop_type"
        Me.f_sop_type.Size = New System.Drawing.Size(220, 20)
        Me.f_sop_type.TabIndex = 23
        Me.f_sop_type.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_sop_type.Title = "SOP Type"
        Me.f_sop_type.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_sop_type.TitleWidth = 90
        '
        'f_status
        '
        Me.f_status.Location = New System.Drawing.Point(907, 24)
        Me.f_status.Name = "f_status"
        Me.f_status.Size = New System.Drawing.Size(220, 20)
        Me.f_status.TabIndex = 22
        Me.f_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.Title = "Status"
        Me.f_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.TitleWidth = 90
        '
        'f_client
        '
        Me.f_client.Location = New System.Drawing.Point(681, 24)
        Me.f_client.Name = "f_client"
        Me.f_client.Size = New System.Drawing.Size(220, 20)
        Me.f_client.TabIndex = 21
        Me.f_client.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_client.Title = "Client"
        Me.f_client.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_client.TitleWidth = 90
        '
        'f_project_no
        '
        Me.f_project_no.Location = New System.Drawing.Point(455, 24)
        Me.f_project_no.Name = "f_project_no"
        Me.f_project_no.Size = New System.Drawing.Size(220, 20)
        Me.f_project_no.TabIndex = 20
        Me.f_project_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_project_no.Title = "Project No"
        Me.f_project_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_project_no.TitleWidth = 90
        '
        'f_project_name
        '
        Me.f_project_name.Location = New System.Drawing.Point(455, 47)
        Me.f_project_name.Name = "f_project_name"
        Me.f_project_name.Size = New System.Drawing.Size(220, 20)
        Me.f_project_name.TabIndex = 19
        Me.f_project_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_project_name.Title = "Project Name"
        Me.f_project_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_project_name.TitleWidth = 90
        '
        'f_to_dt
        '
        Me.f_to_dt.Location = New System.Drawing.Point(5, 47)
        Me.f_to_dt.Name = "f_to_dt"
        Me.f_to_dt.Size = New System.Drawing.Size(220, 20)
        Me.f_to_dt.TabIndex = 18
        Me.f_to_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_to_dt.Title = "~"
        Me.f_to_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_to_dt.TitleWidth = 90
        '
        'f_fr_dt
        '
        Me.f_fr_dt.Location = New System.Drawing.Point(5, 24)
        Me.f_fr_dt.Name = "f_fr_dt"
        Me.f_fr_dt.Size = New System.Drawing.Size(220, 20)
        Me.f_fr_dt.TabIndex = 17
        Me.f_fr_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_fr_dt.Title = "Date"
        Me.f_fr_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_fr_dt.TitleWidth = 90
        '
        'f_category
        '
        Me.f_category.Location = New System.Drawing.Point(681, 47)
        Me.f_category.Name = "f_category"
        Me.f_category.Size = New System.Drawing.Size(220, 20)
        Me.f_category.TabIndex = 12
        Me.f_category.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_category.Title = "Category"
        Me.f_category.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_category.TitleWidth = 90
        '
        'f_bid_no
        '
        Me.f_bid_no.Location = New System.Drawing.Point(229, 24)
        Me.f_bid_no.Name = "f_bid_no"
        Me.f_bid_no.Size = New System.Drawing.Size(220, 20)
        Me.f_bid_no.TabIndex = 6
        Me.f_bid_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_bid_no.Title = "Bidding No"
        Me.f_bid_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_bid_no.TitleWidth = 90
        '
        'f_rfq_no
        '
        Me.f_rfq_no.Location = New System.Drawing.Point(229, 47)
        Me.f_rfq_no.Name = "f_rfq_no"
        Me.f_rfq_no.Size = New System.Drawing.Size(220, 20)
        Me.f_rfq_no.TabIndex = 2
        Me.f_rfq_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_rfq_no.Title = "RFQ No"
        Me.f_rfq_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_rfq_no.TitleWidth = 90
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.EPanel2)
        Me.SplitContainer2.Size = New System.Drawing.Size(1900, 818)
        Me.SplitContainer2.SplitterDistance = 309
        Me.SplitContainer2.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.g10)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel4)
        Me.SplitContainer3.Size = New System.Drawing.Size(1900, 309)
        Me.SplitContainer3.SplitterDistance = 530
        Me.SplitContainer3.TabIndex = 0
        '
        'g10
        '
        Me.g10.AllowColumnResizing = True
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(530, 309)
        Me.g10.TabIndex = 2
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.final_status)
        Me.EPanel4.Controls.Add(Me.rfq_status)
        Me.EPanel4.Controls.Add(Me.btn_hide)
        Me.EPanel4.Controls.Add(Me.sop_type)
        Me.EPanel4.Controls.Add(Me.client_name)
        Me.EPanel4.Controls.Add(Me.project_location)
        Me.EPanel4.Controls.Add(Me.project_name)
        Me.EPanel4.Controls.Add(Me.project_owner)
        Me.EPanel4.Controls.Add(Me.bugetary_status)
        Me.EPanel4.Controls.Add(Me.validity)
        Me.EPanel4.Controls.Add(Me.bid_date)
        Me.EPanel4.Controls.Add(Me.project_no)
        Me.EPanel4.Controls.Add(Me.rfq_no)
        Me.EPanel4.Controls.Add(Me.scope)
        Me.EPanel4.Controls.Add(Me.rev)
        Me.EPanel4.Controls.Add(Me.client)
        Me.EPanel4.Controls.Add(Me.memo)
        Me.EPanel4.Controls.Add(Me.bid_no)
        Me.EPanel4.Controls.Add(Me.GroupBox1)
        Me.EPanel4.Controls.Add(Me.GroupBox2)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(1366, 309)
        Me.EPanel4.TabIndex = 3
        Me.EPanel4.Text = "     Bidding Info"
        '
        'final_status
        '
        Me.final_status.Location = New System.Drawing.Point(528, 273)
        Me.final_status.Name = "final_status"
        Me.final_status.Size = New System.Drawing.Size(255, 20)
        Me.final_status.TabIndex = 65
        Me.final_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.final_status.Title = "Final Status"
        Me.final_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.final_status.TitleWidth = 120
        '
        'rfq_status
        '
        Me.rfq_status.Location = New System.Drawing.Point(272, 273)
        Me.rfq_status.Name = "rfq_status"
        Me.rfq_status.Size = New System.Drawing.Size(250, 20)
        Me.rfq_status.TabIndex = 64
        Me.rfq_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rfq_status.Title = "RFQ Status"
        Me.rfq_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rfq_status.TitleWidth = 120
        '
        'btn_hide
        '
        Me.btn_hide.Appearance.ForeColor = System.Drawing.Color.Black
        Me.btn_hide.Appearance.Options.UseForeColor = True
        Me.btn_hide.Location = New System.Drawing.Point(1233, 284)
        Me.btn_hide.Name = "btn_hide"
        Me.btn_hide.Size = New System.Drawing.Size(117, 20)
        Me.btn_hide.TabIndex = 3
        Me.btn_hide.Text = "Hide Master"
        '
        'sop_type
        '
        Me.sop_type.Location = New System.Drawing.Point(302, 21)
        Me.sop_type.Name = "sop_type"
        Me.sop_type.Size = New System.Drawing.Size(481, 23)
        Me.sop_type.TabIndex = 63
        Me.sop_type.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.sop_type.Title = "SOP Type"
        Me.sop_type.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.sop_type.TitleWidth = 80
        '
        'client_name
        '
        Me.client_name.Location = New System.Drawing.Point(302, 116)
        Me.client_name.Name = "client_name"
        Me.client_name.Size = New System.Drawing.Size(481, 20)
        Me.client_name.TabIndex = 54
        Me.client_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.client_name.Title = "Client Name"
        Me.client_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.client_name.TitleWidth = 0
        '
        'project_location
        '
        Me.project_location.Location = New System.Drawing.Point(488, 93)
        Me.project_location.Name = "project_location"
        Me.project_location.Size = New System.Drawing.Size(295, 20)
        Me.project_location.TabIndex = 53
        Me.project_location.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_location.Title = "Project Location"
        Me.project_location.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_location.TitleWidth = 100
        '
        'project_name
        '
        Me.project_name.Location = New System.Drawing.Point(488, 70)
        Me.project_name.Name = "project_name"
        Me.project_name.Size = New System.Drawing.Size(295, 20)
        Me.project_name.TabIndex = 52
        Me.project_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_name.Title = "Project Name"
        Me.project_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_name.TitleWidth = 100
        '
        'project_owner
        '
        Me.project_owner.Location = New System.Drawing.Point(488, 47)
        Me.project_owner.Name = "project_owner"
        Me.project_owner.Size = New System.Drawing.Size(295, 20)
        Me.project_owner.TabIndex = 51
        Me.project_owner.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_owner.Title = "Project Owner"
        Me.project_owner.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_owner.TitleWidth = 100
        '
        'bugetary_status
        '
        Me.bugetary_status.Location = New System.Drawing.Point(16, 273)
        Me.bugetary_status.Name = "bugetary_status"
        Me.bugetary_status.Size = New System.Drawing.Size(250, 20)
        Me.bugetary_status.TabIndex = 50
        Me.bugetary_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bugetary_status.Title = "Bugetary Status"
        Me.bugetary_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bugetary_status.TitleWidth = 120
        '
        'validity
        '
        Me.validity.Location = New System.Drawing.Point(302, 93)
        Me.validity.Name = "validity"
        Me.validity.Size = New System.Drawing.Size(180, 20)
        Me.validity.TabIndex = 49
        Me.validity.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.validity.Title = "Validity"
        Me.validity.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.validity.TitleWidth = 80
        '
        'bid_date
        '
        Me.bid_date.Location = New System.Drawing.Point(16, 93)
        Me.bid_date.Name = "bid_date"
        Me.bid_date.Size = New System.Drawing.Size(280, 20)
        Me.bid_date.TabIndex = 24
        Me.bid_date.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bid_date.Title = "Bidding Date"
        Me.bid_date.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bid_date.TitleWidth = 120
        '
        'project_no
        '
        Me.project_no.Location = New System.Drawing.Point(16, 70)
        Me.project_no.Name = "project_no"
        Me.project_no.Size = New System.Drawing.Size(280, 20)
        Me.project_no.TabIndex = 48
        Me.project_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_no.Title = "Project No"
        Me.project_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.project_no.TitleWidth = 120
        '
        'rfq_no
        '
        Me.rfq_no.Location = New System.Drawing.Point(16, 47)
        Me.rfq_no.Name = "rfq_no"
        Me.rfq_no.Size = New System.Drawing.Size(280, 20)
        Me.rfq_no.TabIndex = 47
        Me.rfq_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rfq_no.Title = "RFQ No"
        Me.rfq_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rfq_no.TitleWidth = 120
        '
        'scope
        '
        Me.scope.Location = New System.Drawing.Point(16, 139)
        Me.scope.Name = "scope"
        Me.scope.Size = New System.Drawing.Size(767, 20)
        Me.scope.TabIndex = 16
        Me.scope.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.scope.Title = "Scope of Supply"
        Me.scope.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.scope.TitleWidth = 120
        '
        'rev
        '
        Me.rev.Location = New System.Drawing.Point(302, 70)
        Me.rev.Name = "rev"
        Me.rev.Size = New System.Drawing.Size(180, 20)
        Me.rev.TabIndex = 15
        Me.rev.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rev.Title = "Rev"
        Me.rev.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rev.TitleWidth = 80
        '
        'client
        '
        Me.client.Location = New System.Drawing.Point(16, 116)
        Me.client.Name = "client"
        Me.client.Size = New System.Drawing.Size(280, 20)
        Me.client.TabIndex = 14
        Me.client.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.client.Title = "Client"
        Me.client.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.client.TitleWidth = 120
        '
        'memo
        '
        Me.memo.Location = New System.Drawing.Point(16, 162)
        Me.memo.Name = "memo"
        Me.memo.Size = New System.Drawing.Size(767, 108)
        Me.memo.TabIndex = 12
        Me.memo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.memo.Title = "Memo"
        Me.memo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.memo.TitleWidth = 120
        '
        'bid_no
        '
        Me.bid_no.Location = New System.Drawing.Point(16, 24)
        Me.bid_no.Name = "bid_no"
        Me.bid_no.Size = New System.Drawing.Size(280, 20)
        Me.bid_no.TabIndex = 4
        Me.bid_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bid_no.Title = "Bidding No"
        Me.bid_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bid_no.TitleWidth = 120
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.invoice_to)
        Me.GroupBox1.Controls.Add(Me.invoice_addr)
        Me.GroupBox1.Controls.Add(Me.invoice_client)
        Me.GroupBox1.Location = New System.Drawing.Point(790, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(568, 110)
        Me.GroupBox1.TabIndex = 61
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "■ Invoice"
        '
        'invoice_to
        '
        Me.invoice_to.AutoHeight = False
        Me.invoice_to.Location = New System.Drawing.Point(9, 23)
        Me.invoice_to.Name = "invoice_to"
        Me.invoice_to.Size = New System.Drawing.Size(240, 40)
        Me.invoice_to.TabIndex = 56
        Me.invoice_to.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.invoice_to.Title = "Invoice To"
        Me.invoice_to.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.invoice_to.TitleWidth = 90
        '
        'invoice_addr
        '
        Me.invoice_addr.Location = New System.Drawing.Point(9, 66)
        Me.invoice_addr.Name = "invoice_addr"
        Me.invoice_addr.Size = New System.Drawing.Size(551, 40)
        Me.invoice_addr.TabIndex = 28
        Me.invoice_addr.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.invoice_addr.Title = "Address"
        Me.invoice_addr.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.invoice_addr.TitleWidth = 90
        '
        'invoice_client
        '
        Me.invoice_client.Location = New System.Drawing.Point(255, 23)
        Me.invoice_client.Name = "invoice_client"
        Me.invoice_client.Size = New System.Drawing.Size(305, 40)
        Me.invoice_client.TabIndex = 27
        Me.invoice_client.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.invoice_client.Title = "Invoice To Name"
        Me.invoice_client.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.invoice_client.TitleWidth = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.delivery_company)
        Me.GroupBox2.Controls.Add(Me.company_addr)
        Me.GroupBox2.Controls.Add(Me.company_name)
        Me.GroupBox2.Controls.Add(Me.delivery_term)
        Me.GroupBox2.Location = New System.Drawing.Point(789, 143)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(569, 135)
        Me.GroupBox2.TabIndex = 62
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "■ Delivery"
        '
        'delivery_company
        '
        Me.delivery_company.AutoHeight = False
        Me.delivery_company.Location = New System.Drawing.Point(10, 19)
        Me.delivery_company.Name = "delivery_company"
        Me.delivery_company.Size = New System.Drawing.Size(240, 42)
        Me.delivery_company.TabIndex = 60
        Me.delivery_company.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.delivery_company.Title = "Company"
        Me.delivery_company.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.delivery_company.TitleWidth = 90
        '
        'company_addr
        '
        Me.company_addr.Location = New System.Drawing.Point(10, 64)
        Me.company_addr.Name = "company_addr"
        Me.company_addr.Size = New System.Drawing.Size(551, 40)
        Me.company_addr.TabIndex = 29
        Me.company_addr.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.company_addr.Title = "Address"
        Me.company_addr.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.company_addr.TitleWidth = 90
        '
        'company_name
        '
        Me.company_name.Location = New System.Drawing.Point(256, 19)
        Me.company_name.Name = "company_name"
        Me.company_name.Size = New System.Drawing.Size(305, 42)
        Me.company_name.TabIndex = 30
        Me.company_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.company_name.Title = "Company Name"
        Me.company_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.company_name.TitleWidth = 0
        '
        'delivery_term
        '
        Me.delivery_term.Location = New System.Drawing.Point(10, 107)
        Me.delivery_term.Name = "delivery_term"
        Me.delivery_term.Size = New System.Drawing.Size(551, 20)
        Me.delivery_term.TabIndex = 57
        Me.delivery_term.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.delivery_term.Title = "Term"
        Me.delivery_term.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.delivery_term.TitleWidth = 90
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.XtraTabControl1)
        Me.EPanel2.Controls.Add(Me.btn_show)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(1900, 505)
        Me.EPanel2.TabIndex = 0
        Me.EPanel2.Text = "     SOP Status"
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(2, 21)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1896, 482)
        Me.XtraTabControl1.TabIndex = 3
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage3, Me.XtraTabPage2})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.g20)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1890, 453)
        Me.XtraTabPage1.Text = "Job Scope"
        '
        'g20
        '
        Me.g20.AllowColumnResizing = True
        Me.g20.AllowInsertRows = False
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(1890, 453)
        Me.g20.TabIndex = 0
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.Controls.Add(Me.SplitContainer4)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(1890, 453)
        Me.XtraTabPage3.Text = "SOP"
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.EPanel3)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.g30)
        Me.SplitContainer4.Size = New System.Drawing.Size(1890, 453)
        Me.SplitContainer4.SplitterDistance = 33
        Me.SplitContainer4.TabIndex = 0
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.pid)
        Me.EPanel3.Controls.Add(Me.rt_profit)
        Me.EPanel3.Controls.Add(Me.rt_sga)
        Me.EPanel3.Controls.Add(Me.rt_cogs)
        Me.EPanel3.Controls.Add(Me.rt_indir)
        Me.EPanel3.Controls.Add(Me.rt_equip)
        Me.EPanel3.Controls.Add(Me.rt_tc)
        Me.EPanel3.Controls.Add(Me.currency_rate)
        Me.EPanel3.Controls.Add(Me.currency)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.IconVisible = False
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.ShowCaption = False
        Me.EPanel3.Size = New System.Drawing.Size(1890, 33)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "SOP Status"
        '
        'pid
        '
        Me.pid.Location = New System.Drawing.Point(1493, 6)
        Me.pid.Name = "pid"
        Me.pid.Size = New System.Drawing.Size(160, 20)
        Me.pid.TabIndex = 73
        Me.pid.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pid.Title = "ID"
        Me.pid.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pid.TitleWidth = 80
        '
        'rt_profit
        '
        Me.rt_profit.Location = New System.Drawing.Point(1327, 6)
        Me.rt_profit.Name = "rt_profit"
        Me.rt_profit.Size = New System.Drawing.Size(160, 20)
        Me.rt_profit.TabIndex = 72
        Me.rt_profit.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_profit.Title = "Profit"
        Me.rt_profit.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_profit.TitleWidth = 80
        '
        'rt_sga
        '
        Me.rt_sga.Location = New System.Drawing.Point(1161, 6)
        Me.rt_sga.Name = "rt_sga"
        Me.rt_sga.Size = New System.Drawing.Size(160, 20)
        Me.rt_sga.TabIndex = 71
        Me.rt_sga.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_sga.Title = "SG&&A"
        Me.rt_sga.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_sga.TitleWidth = 80
        '
        'rt_cogs
        '
        Me.rt_cogs.Location = New System.Drawing.Point(995, 6)
        Me.rt_cogs.Name = "rt_cogs"
        Me.rt_cogs.Size = New System.Drawing.Size(160, 20)
        Me.rt_cogs.TabIndex = 70
        Me.rt_cogs.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_cogs.Title = "COGS"
        Me.rt_cogs.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_cogs.TitleWidth = 80
        '
        'rt_indir
        '
        Me.rt_indir.Location = New System.Drawing.Point(829, 6)
        Me.rt_indir.Name = "rt_indir"
        Me.rt_indir.Size = New System.Drawing.Size(160, 20)
        Me.rt_indir.TabIndex = 69
        Me.rt_indir.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_indir.Title = "Indirect"
        Me.rt_indir.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_indir.TitleWidth = 80
        '
        'rt_equip
        '
        Me.rt_equip.Location = New System.Drawing.Point(663, 6)
        Me.rt_equip.Name = "rt_equip"
        Me.rt_equip.Size = New System.Drawing.Size(160, 20)
        Me.rt_equip.TabIndex = 68
        Me.rt_equip.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_equip.Title = "Equipment"
        Me.rt_equip.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_equip.TitleWidth = 80
        '
        'rt_tc
        '
        Me.rt_tc.Location = New System.Drawing.Point(497, 6)
        Me.rt_tc.Name = "rt_tc"
        Me.rt_tc.Size = New System.Drawing.Size(160, 20)
        Me.rt_tc.TabIndex = 67
        Me.rt_tc.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_tc.Title = "T&&C"
        Me.rt_tc.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rt_tc.TitleWidth = 80
        '
        'currency_rate
        '
        Me.currency_rate.Location = New System.Drawing.Point(251, 6)
        Me.currency_rate.Name = "currency_rate"
        Me.currency_rate.Size = New System.Drawing.Size(240, 20)
        Me.currency_rate.TabIndex = 28
        Me.currency_rate.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.currency_rate.Title = "Rate"
        Me.currency_rate.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.currency_rate.TitleWidth = 90
        '
        'currency
        '
        Me.currency.Location = New System.Drawing.Point(5, 6)
        Me.currency.Name = "currency"
        Me.currency.Size = New System.Drawing.Size(240, 20)
        Me.currency.TabIndex = 66
        Me.currency.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.currency.Title = "Currency"
        Me.currency.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.currency.TitleWidth = 90
        '
        'g30
        '
        Me.g30.AllowColumnResizing = True
        Me.g30.AllowInsertRows = False
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(0, 0)
        Me.g30.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g30.Name = "g30"
        Me.g30.Size = New System.Drawing.Size(1890, 416)
        Me.g30.TabIndex = 1
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.cuFtp)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1890, 453)
        Me.XtraTabPage2.Text = "Document"
        '
        'cuFtp
        '
        Me.cuFtp.AllowColumnResizing = True
        Me.cuFtp.AllowInsertRows = False
        Me.cuFtp.Dock = System.Windows.Forms.DockStyle.Fill
        Me.cuFtp.Location = New System.Drawing.Point(0, 0)
        Me.cuFtp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cuFtp.Name = "cuFtp"
        Me.cuFtp.Size = New System.Drawing.Size(1890, 453)
        Me.cuFtp.TabIndex = 1
        '
        'btn_show
        '
        Me.btn_show.Location = New System.Drawing.Point(1767, 1)
        Me.btn_show.Name = "btn_show"
        Me.btn_show.Size = New System.Drawing.Size(117, 20)
        Me.btn_show.TabIndex = 64
        Me.btn_show.Text = "Show Master"
        '
        'SA100
        '
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "SA100"
        Me.Size = New System.Drawing.Size(1900, 900)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.XtraTabPage3.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame9.ePanel
    Friend WithEvents f_category As Frame9.eCheckCombo
    Friend WithEvents f_bid_no As Frame9.eText
    Friend WithEvents f_rfq_no As Frame9.eText
    Friend WithEvents f_to_dt As Frame9.eDate
    Friend WithEvents f_fr_dt As Frame9.eDate
    Friend WithEvents f_project_no As Frame9.eText
    Friend WithEvents f_project_name As Frame9.eText
    Friend WithEvents f_client As Frame9.eText
    Friend WithEvents f_sop_type As Frame9.eCheckCombo
    Friend WithEvents f_status As Frame9.eCheckCombo
    Friend WithEvents btn_groupware As Frame9.eButton
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents g10 As Frame9.eGrid
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g20 As Frame9.eGrid
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g30 As Frame9.eGrid
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents cuFtp As Frame9.eGrid
    Friend WithEvents EPanel4 As Frame9.ePanel
    Friend WithEvents btn_show As Frame9.eButton
    Friend WithEvents sop_type As Frame9.eOptionBox
    Friend WithEvents client_name As Frame9.eText
    Friend WithEvents project_location As Frame9.eText
    Friend WithEvents project_name As Frame9.eText
    Friend WithEvents project_owner As Frame9.eText
    Friend WithEvents bugetary_status As Frame9.eCombo
    Friend WithEvents validity As Frame9.eText
    Friend WithEvents bid_date As Frame9.eDate
    Friend WithEvents project_no As Frame9.eText
    Friend WithEvents rfq_no As Frame9.eText
    Friend WithEvents scope As Frame9.eText
    Friend WithEvents rev As Frame9.eText
    Friend WithEvents client As Frame9.eText
    Friend WithEvents memo As Frame9.eMemo
    Friend WithEvents bid_no As Frame9.eText
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents delivery_term As Frame9.eText
    Friend WithEvents btn_hide As Frame9.eButton
    Friend WithEvents EPanel2 As Frame9.ePanel
    Friend WithEvents invoice_client As Frame9.eMemo
    Friend WithEvents invoice_addr As Frame9.eMemo
    Friend WithEvents company_name As Frame9.eMemo
    Friend WithEvents company_addr As Frame9.eMemo
    Friend WithEvents invoice_to As Frame9.eText
    Friend WithEvents delivery_company As Frame9.eText
    Friend WithEvents final_status As Frame9.eCombo
    Friend WithEvents rfq_status As Frame9.eCombo
    Friend WithEvents temp_name As Frame9.eText
    Friend WithEvents temp_cd As Frame9.eText
    Friend WithEvents btn_apply As Frame9.eButton
    Friend WithEvents SplitContainer4 As SplitContainer
    Friend WithEvents EPanel3 As Frame9.ePanel
    Friend WithEvents rt_profit As Frame9.eText
    Friend WithEvents rt_sga As Frame9.eText
    Friend WithEvents rt_cogs As Frame9.eText
    Friend WithEvents rt_indir As Frame9.eText
    Friend WithEvents rt_equip As Frame9.eText
    Friend WithEvents rt_tc As Frame9.eText
    Friend WithEvents currency_rate As Frame9.eText
    Friend WithEvents currency As Frame9.eCombo
    Friend WithEvents pid As Frame9.eText
End Class
