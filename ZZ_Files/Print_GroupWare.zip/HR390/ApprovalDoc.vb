Imports System.Data
Imports DevExpress.XtraReports.UI

Public Class ApprovalDoc
    Public Sub New()
        InitializeComponent()
    End Sub

    Public Sub New(ByVal dSet As DataSet)
        InitializeComponent()
        Me.SetDateSet(dSet)
    End Sub

    Public Sub SetDateSet(ByVal dSet As DataSet)

        'DETAIL1
        DetailReport1.DataSource = dSet.Tables(1)
        doc_no.DataBindings.Add("Text", dSet.Tables(0), "doc_no")
        expense.DataBindings.Add("Text", dSet.Tables(0), "expense")
        apply_date.DataBindings.Add("Text", dSet.Tables(0), "apply_date")
        training_type.DataBindings.Add("Text", dSet.Tables(0), "training_type")
        frto_date.DataBindings.Add("Text", dSet.Tables(0), "frto_date")
        course.DataBindings.Add("Text", dSet.Tables(0), "course")
        institution.DataBindings.Add("Text", dSet.Tables(0), "institution")
        memo.DataBindings.Add("Text", dSet.Tables(0), "memo")

        emp_no.DataBindings.Add("Text", dSet.Tables(1), "emp_no")
        emp_nm.DataBindings.Add("Text", dSet.Tables(1), "name")
        other_lang_name.DataBindings.Add("Text", dSet.Tables(1), "other_lang_name")
        dept.DataBindings.Add("Text", dSet.Tables(1), "dept")
        project.DataBindings.Add("Text", dSet.Tables(1), "project")
        section.DataBindings.Add("Text", dSet.Tables(1), "section")
        job_site.DataBindings.Add("Text", dSet.Tables(1), "job_site")
        position.DataBindings.Add("Text", dSet.Tables(1), "position")
        job_class.DataBindings.Add("Text", dSet.Tables(1), "job_class")

    End Sub

    Private Sub ImageBinding(ByVal dTable As DataTable, ByVal PictureBoxControl As DevExpress.XtraReports.UI.XRPictureBox, ByVal ImageField As String)
        If IsDBNull(dTable.Rows(0)(ImageField)) Then
            PictureBoxControl.Image = Nothing
        Else
            Dim photo() As Byte = dTable.Rows(0)(ImageField)
            Dim ms As New System.IO.MemoryStream(photo)
            PictureBoxControl.Image = New Bitmap(ms)
            PictureBoxControl.Sizing = DevExpress.XtraPrinting.ImageSizeMode.Squeeze
        End If
    End Sub

    Private Sub DetailReport_BeforePrint(sender As Object, e As Printing.PrintEventArgs)

    End Sub
End Class