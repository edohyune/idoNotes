Imports Frame9
Imports Base9
Imports Base9.Shared
Imports System.Data
Imports System.IO
Imports System.Net
Imports System9

Public Class HR390
    Private Sub SA100_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        doc_no.CodeNo = "HA500"
        doc_no.CodeDateField = apply_date
    End Sub


    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
        Select Case mty
            Case MenuType.Open
                Me.Open()
            Case MenuType.Print
            Case MenuType.New
                New_Form()
            Case MenuType.Save
                If Me.Save() Then
                    Dim finder As String = doc_no.Text
                    Me.Open()
                    g10.Find("doc_no = " + finder)
                    g10.Find("doc_no= " + finder)
                    g10.Find("doc_no= " + finder)
                End If

                'Case MenuType.Save
                '    Dim finder As String = doc_no.Text
                '    If MyBase.Save() Then
                '        Me.Open()
                '        g10.Find("doc_no= " + finder)

                '    End If

                'Me.Open()
                'g10.Find("doc_no= " + finder)
            Case Else
                MyBase.MenuButton_Click(mty)
        End Select
    End Sub

    Private Sub New_Form()
        doc_no.Text = ""
        OpenTrigger("hr390_g10")
        _ReadOnly(False)
    End Sub

    Private Sub _ReadOnly(ByVal ref As Boolean)
        g20.ReadOnly = ref
        apply_date.ReadOnly = ref
        from_date.ReadOnly = ref
        to_date.ReadOnly = ref
        training_type.ReadOnly = ref
        course.ReadOnly = ref
        expense.ReadOnly = ref
        Memo.ReadOnly = ref
        institution.ReadOnly = ref
    End Sub

    Private Sub g10_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g10.AfterMoveRow
        If g10.Text("status", RowIndex) = "FI020100" Then
            _ReadOnly(False)
            btn_groupware.Enabled = True
        Else
            _ReadOnly(True)
            btn_groupware.Enabled = False
        End If
    End Sub

    Private Sub to_date_TextChanged(sender As Object, e As EventArgs) Handles to_date.TextChanged
        If from_date.Text <> "" And to_date.Text <> "" Then
            If to_date.Text < from_date.Text Then
                PutMessage("BJC100_23", "The start date is greater than the end date.")
                to_date.Text = ""
                Exit Sub
            End If
        End If
    End Sub

#Region "Approval Button =========================================  Edit"
    Public m_stop_event As Boolean
    'Connect to Handles
    Private Sub btn_groupware_Click(sender As Object, e As EventArgs) Handles btn_groupware.Click
        If m_stop_event Then Exit Sub
        m_stop_event = True

        'Condtion Check
        If g20.RowCount < 1 Then      '''''''''''''''''''''''''''''''''Edit Grid 
            Exit Sub
        End If

        'Current Document Parameters Value Setting
        Dim docNo As String = doc_no.Text        ''''''''''''''''''''''Edit
        Dim docDt As String = apply_date.Text    ''''''''''''''''''''''Edit
        Dim empNo As String = "" 'emp_no.Text    ''''''''''''''''''''''Edit 
        Dim deptCd As String = "" 'dept.Text     ''''''''''''''''''''''Edit
        Dim testYn As Boolean = False            ''''''''''''''''''''''Edit (True : Can See Print)

        Dim rtnGroupWareProcess As String = groupWareProcess(docNo, docDt, empNo, deptCd, testYn)
        If rtnGroupWareProcess = "OK" Then
            m_stop_event = False
            PutMessage("BJC100_24", "It has been processed succeed.")
            Dim find As String = doc_no.Text
            Me.Open()
            g10.Find("doc_no=" + find)
            Exit Sub
        End If
    End Sub
#End Region
#Region "Approval ===================================== Do not need Edit"
    Private Function groupWareProcess(docNo As String, docDt As String, empNo As String, deptCd As String, testYn As Boolean) As String
        Dim frmCd As String = Me.Name

        Dim dinitSet As System.Data.DataSet = MyBase.OpenDataSet(frmCd + "_approvalInit")
        Dim gwNo As String = DataValue(dinitSet, "doc_code")
        Dim docStat As String = DataValue(dinitSet, "doc_status")
        Dim tblNm As String = DataValue(dinitSet, "table_name")
        If empNo = "" Then
            empNo = DataValue(dinitSet, "emp_no")
        End If
        If deptCd = "" Then
            empNo = DataValue(dinitSet, "dept_cd")
        End If

        Dim p As OpenParameters = New OpenParameters
        p.Add("@form_name", frmCd)
        p.Add("@table_name", tblNm)
        p.Add("@doc_code", gwNo)
        p.Add("@doc_no", docNo)
        p.Add("@doc_date", docDt)
        p.Add("@dept", deptCd)
        p.Add("@emp_no", empNo)
        p.Add("@doc_stat", docStat)

        Dim dSet1 As DataSet = OpenDataSet(frmCd + "_approvalHtml", p)
        Dim Rpt1 As New ApprovalDoc(dSet1)

        If testYn Then
            Dim ReportPrintTool As New DevExpress.XtraReports.UI.ReportPrintTool(Rpt1)
            ReportPrintTool.ShowPreviewDialog()
            Return "TEST"
        Else
            If Directory.Exists("c:\temp\") = False Then
                Directory.CreateDirectory("c:\temp\")
            End If

            Rpt1.CreateDocument()

            Dim htmlId As String = Guid.NewGuid().ToString("N")
            Dim fileNm As String = "c:\temp\" + htmlId + ".html"

            Rpt1.ExportToHtml(fileNm)

            Dim client As New WebClient
            client.Encoding = System.Text.Encoding.UTF8
            Dim html As String = client.DownloadString(New Uri(fileNm))

            html = Replace(html, "'", "''")

            p.Add("@htm", html)

            Dim dset2 As DataSet = OpenDataSet(frmCd + "_approvalSubmit", p)

            If IsEmpty(dset2) Then
                Return frmCd + "_approvalSubmit ERROR"
            Else
                Return DataValue(dset2, "rtn")
            End If
        End If
    End Function
#End Region

End Class
