<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HR390
    Inherits Base9.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel3 = New Frame9.ePanel()
        Me.btn_groupware = New Frame9.eButton()
        Me.s_status = New Frame9.eCombo()
        Me.s_course = New Frame9.eText()
        Me.to_dt = New Frame9.eDate()
        Me.fr_dt = New Frame9.eDate()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.g10 = New Frame9.eGrid()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel4 = New Frame9.ePanel()
        Me.institution = New Frame9.eText()
        Me.apply_date = New Frame9.eDate()
        Me.status = New Frame9.eCombo()
        Me.expense = New Frame9.eText()
        Me.voucher_no = New Frame9.eText()
        Me.Memo = New Frame9.eMemo()
        Me.course = New Frame9.eText()
        Me.training_type = New Frame9.eCombo()
        Me.to_date = New Frame9.eDate()
        Me.from_date = New Frame9.eDate()
        Me.doc_no = New Frame9.eText()
        Me.g20 = New Frame9.eGrid()
        Me.EPanel1 = New Frame9.ePanel()
        Me.EPanel2 = New Frame9.ePanel()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel3)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1750, 750)
        Me.SplitContainer1.SplitterDistance = 75
        Me.SplitContainer1.TabIndex = 0
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.btn_groupware)
        Me.EPanel3.Controls.Add(Me.s_status)
        Me.EPanel3.Controls.Add(Me.s_course)
        Me.EPanel3.Controls.Add(Me.to_dt)
        Me.EPanel3.Controls.Add(Me.fr_dt)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(1750, 75)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     Training Request"
        '
        'btn_groupware
        '
        Me.btn_groupware.Appearance.Options.UseTextOptions = True
        Me.btn_groupware.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
        Me.btn_groupware.Location = New System.Drawing.Point(1314, 23)
        Me.btn_groupware.Name = "btn_groupware"
        Me.btn_groupware.Size = New System.Drawing.Size(133, 43)
        Me.btn_groupware.TabIndex = 57
        Me.btn_groupware.Text = "Approval Request (Groupware)"
        '
        's_status
        '
        Me.s_status.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_status.Location = New System.Drawing.Point(385, 34)
        Me.s_status.Name = "s_status"
        Me.s_status.Size = New System.Drawing.Size(240, 20)
        Me.s_status.TabIndex = 14
        Me.s_status.Title = "Status"
        Me.s_status.TitleWidth = 60
        '
        's_course
        '
        Me.s_course.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_course.Location = New System.Drawing.Point(632, 34)
        Me.s_course.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.s_course.Name = "s_course"
        Me.s_course.Size = New System.Drawing.Size(238, 20)
        Me.s_course.TabIndex = 12
        Me.s_course.Title = "Course"
        Me.s_course.TitleWidth = 60
        '
        'to_dt
        '
        Me.to_dt.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.to_dt.Location = New System.Drawing.Point(241, 34)
        Me.to_dt.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(135, 20)
        Me.to_dt.TabIndex = 11
        Me.to_dt.Title = "~"
        Me.to_dt.TitleWidth = 15
        '
        'fr_dt
        '
        Me.fr_dt.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fr_dt.Location = New System.Drawing.Point(32, 34)
        Me.fr_dt.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(201, 20)
        Me.fr_dt.TabIndex = 10
        Me.fr_dt.Title = "Training Date"
        Me.fr_dt.TitleWidth = 80
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.g10)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(1750, 671)
        Me.SplitContainer2.SplitterDistance = 411
        Me.SplitContainer2.TabIndex = 0
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(411, 671)
        Me.g10.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel4)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.g20)
        Me.SplitContainer3.Size = New System.Drawing.Size(1335, 671)
        Me.SplitContainer3.SplitterDistance = 237
        Me.SplitContainer3.TabIndex = 0
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.institution)
        Me.EPanel4.Controls.Add(Me.apply_date)
        Me.EPanel4.Controls.Add(Me.status)
        Me.EPanel4.Controls.Add(Me.expense)
        Me.EPanel4.Controls.Add(Me.voucher_no)
        Me.EPanel4.Controls.Add(Me.Memo)
        Me.EPanel4.Controls.Add(Me.course)
        Me.EPanel4.Controls.Add(Me.training_type)
        Me.EPanel4.Controls.Add(Me.to_date)
        Me.EPanel4.Controls.Add(Me.from_date)
        Me.EPanel4.Controls.Add(Me.doc_no)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(1335, 237)
        Me.EPanel4.TabIndex = 0
        Me.EPanel4.Text = "     Training Request"
        '
        'institution
        '
        Me.institution.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.institution.Location = New System.Drawing.Point(15, 147)
        Me.institution.Name = "institution"
        Me.institution.Size = New System.Drawing.Size(661, 20)
        Me.institution.TabIndex = 13
        Me.institution.Title = "Institution"
        Me.institution.TitleWidth = 80
        '
        'apply_date
        '
        Me.apply_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.apply_date.Location = New System.Drawing.Point(15, 55)
        Me.apply_date.Name = "apply_date"
        Me.apply_date.Size = New System.Drawing.Size(240, 20)
        Me.apply_date.TabIndex = 12
        Me.apply_date.Title = "Date"
        Me.apply_date.TitleWidth = 80
        '
        'status
        '
        Me.status.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status.Location = New System.Drawing.Point(436, 78)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(240, 20)
        Me.status.TabIndex = 11
        Me.status.Title = "Status"
        Me.status.TitleWidth = 80
        '
        'expense
        '
        Me.expense.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.expense.Location = New System.Drawing.Point(436, 55)
        Me.expense.Name = "expense"
        Me.expense.Size = New System.Drawing.Size(240, 20)
        Me.expense.TabIndex = 10
        Me.expense.Title = "Expense"
        Me.expense.TitleWidth = 80
        '
        'voucher_no
        '
        Me.voucher_no.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.voucher_no.Location = New System.Drawing.Point(436, 32)
        Me.voucher_no.Name = "voucher_no"
        Me.voucher_no.Size = New System.Drawing.Size(240, 20)
        Me.voucher_no.TabIndex = 9
        Me.voucher_no.Title = "Voucher No"
        Me.voucher_no.TitleWidth = 80
        '
        'Memo
        '
        Me.Memo.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Memo.Location = New System.Drawing.Point(15, 170)
        Me.Memo.Name = "Memo"
        Me.Memo.Size = New System.Drawing.Size(661, 60)
        Me.Memo.TabIndex = 8
        Me.Memo.Title = "Memo"
        Me.Memo.TitleWidth = 80
        '
        'course
        '
        Me.course.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.course.Location = New System.Drawing.Point(15, 124)
        Me.course.Name = "course"
        Me.course.Size = New System.Drawing.Size(661, 20)
        Me.course.TabIndex = 7
        Me.course.Title = "Course"
        Me.course.TitleWidth = 80
        '
        'training_type
        '
        Me.training_type.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.training_type.Location = New System.Drawing.Point(15, 101)
        Me.training_type.Name = "training_type"
        Me.training_type.Size = New System.Drawing.Size(661, 20)
        Me.training_type.TabIndex = 6
        Me.training_type.Title = "Training Type"
        Me.training_type.TitleWidth = 80
        '
        'to_date
        '
        Me.to_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.to_date.Location = New System.Drawing.Point(258, 78)
        Me.to_date.Name = "to_date"
        Me.to_date.Size = New System.Drawing.Size(172, 20)
        Me.to_date.TabIndex = 5
        Me.to_date.Title = "    ~"
        Me.to_date.TitleWidth = 40
        '
        'from_date
        '
        Me.from_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.from_date.Location = New System.Drawing.Point(15, 78)
        Me.from_date.Name = "from_date"
        Me.from_date.Size = New System.Drawing.Size(240, 20)
        Me.from_date.TabIndex = 4
        Me.from_date.Title = "Period"
        Me.from_date.TitleWidth = 80
        '
        'doc_no
        '
        Me.doc_no.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.doc_no.Location = New System.Drawing.Point(15, 32)
        Me.doc_no.Name = "doc_no"
        Me.doc_no.Size = New System.Drawing.Size(240, 20)
        Me.doc_no.TabIndex = 2
        Me.doc_no.Title = "Doc No"
        Me.doc_no.TitleWidth = 80
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(1335, 430)
        Me.g20.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(274, 185)
        Me.EPanel1.TabIndex = 0
        '
        'EPanel2
        '
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(274, 185)
        Me.EPanel2.TabIndex = 0
        '
        'HR390
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "HR390"
        Me.Size = New System.Drawing.Size(1750, 750)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents EPanel1 As Frame9.ePanel
    Friend WithEvents EPanel2 As Frame9.ePanel
    Friend WithEvents EPanel3 As Frame9.ePanel
    Friend WithEvents s_course As Frame9.eText
    Friend WithEvents to_dt As Frame9.eDate
    Friend WithEvents fr_dt As Frame9.eDate
    Friend WithEvents s_status As Frame9.eCombo
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents g10 As Frame9.eGrid
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents EPanel4 As Frame9.ePanel
    Friend WithEvents g20 As Frame9.eGrid
    Friend WithEvents btn_groupware As Frame9.eButton
    Friend WithEvents apply_date As Frame9.eDate
    Friend WithEvents status As Frame9.eCombo
    Friend WithEvents expense As Frame9.eText
    Friend WithEvents voucher_no As Frame9.eText
    Friend WithEvents Memo As Frame9.eMemo
    Friend WithEvents course As Frame9.eText
    Friend WithEvents training_type As Frame9.eCombo
    Friend WithEvents to_date As Frame9.eDate
    Friend WithEvents from_date As Frame9.eDate
    Friend WithEvents doc_no As Frame9.eText
    Friend WithEvents institution As Frame9.eText
End Class
