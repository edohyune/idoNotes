<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HR370
    Inherits Base9.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel3 = New Frame9.ePanel()
        Me.s_course = New Frame9.eText()
        Me.s_status = New Frame9.eCombo()
        Me.s_dept = New Frame9.eText()
        Me.s_emp_no = New Frame9.eText()
        Me.btn_groupware = New Frame9.eButton()
        Me.s_to_dt = New Frame9.eDate()
        Me.s_fr_dt = New Frame9.eDate()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.g10 = New Frame9.eGrid()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel4 = New Frame9.ePanel()
        Me.dd = New Frame9.eText()
        Me.pid = New Frame9.eText()
        Me.doc_no = New Frame9.eText()
        Me.area = New Frame9.eCombo()
        Me.voucher_no = New Frame9.eText()
        Me.status = New Frame9.eCombo()
        Me.memo = New Frame9.eMemo()
        Me.position = New Frame9.eCombo()
        Me.apply_date = New Frame9.eDate()
        Me.days = New Frame9.eText()
        Me.to_date = New Frame9.eDate()
        Me.from_date = New Frame9.eDate()
        Me.place = New Frame9.eText()
        Me.subject_trip = New Frame9.eText()
        Me.dept = New Frame9.eText()
        Me.emp_name = New Frame9.eText()
        Me.emp_no = New Frame9.eText()
        Me.g20 = New Frame9.eGrid()
        Me.EPanel1 = New Frame9.ePanel()
        Me.EPanel2 = New Frame9.ePanel()
        Me.EButton1 = New Frame9.eButton()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel3)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1750, 750)
        Me.SplitContainer1.SplitterDistance = 75
        Me.SplitContainer1.TabIndex = 0
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.EButton1)
        Me.EPanel3.Controls.Add(Me.s_course)
        Me.EPanel3.Controls.Add(Me.s_status)
        Me.EPanel3.Controls.Add(Me.s_dept)
        Me.EPanel3.Controls.Add(Me.s_emp_no)
        Me.EPanel3.Controls.Add(Me.btn_groupware)
        Me.EPanel3.Controls.Add(Me.s_to_dt)
        Me.EPanel3.Controls.Add(Me.s_fr_dt)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(1750, 75)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     EPanel3"
        '
        's_course
        '
        Me.s_course.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_course.Location = New System.Drawing.Point(1008, 37)
        Me.s_course.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.s_course.Name = "s_course"
        Me.s_course.Size = New System.Drawing.Size(217, 20)
        Me.s_course.TabIndex = 62
        Me.s_course.Title = "Course"
        Me.s_course.TitleWidth = 60
        '
        's_status
        '
        Me.s_status.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_status.Location = New System.Drawing.Point(784, 37)
        Me.s_status.Name = "s_status"
        Me.s_status.Size = New System.Drawing.Size(217, 20)
        Me.s_status.TabIndex = 61
        Me.s_status.Title = "Status"
        Me.s_status.TitleWidth = 60
        '
        's_dept
        '
        Me.s_dept.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_dept.Location = New System.Drawing.Point(335, 37)
        Me.s_dept.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.s_dept.Name = "s_dept"
        Me.s_dept.Size = New System.Drawing.Size(217, 20)
        Me.s_dept.TabIndex = 60
        Me.s_dept.Title = "Dept"
        Me.s_dept.TitleWidth = 60
        '
        's_emp_no
        '
        Me.s_emp_no.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_emp_no.Location = New System.Drawing.Point(560, 37)
        Me.s_emp_no.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.s_emp_no.Name = "s_emp_no"
        Me.s_emp_no.Size = New System.Drawing.Size(217, 20)
        Me.s_emp_no.TabIndex = 59
        Me.s_emp_no.Title = "Employee"
        Me.s_emp_no.TitleWidth = 60
        '
        'btn_groupware
        '
        Me.btn_groupware.Appearance.Options.UseTextOptions = True
        Me.btn_groupware.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
        Me.btn_groupware.Location = New System.Drawing.Point(1273, 24)
        Me.btn_groupware.Name = "btn_groupware"
        Me.btn_groupware.Size = New System.Drawing.Size(133, 43)
        Me.btn_groupware.TabIndex = 58
        Me.btn_groupware.Text = "Approval Request (Groupware)"
        '
        's_to_dt
        '
        Me.s_to_dt.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_to_dt.Location = New System.Drawing.Point(208, 37)
        Me.s_to_dt.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.s_to_dt.Name = "s_to_dt"
        Me.s_to_dt.Size = New System.Drawing.Size(119, 20)
        Me.s_to_dt.TabIndex = 5
        Me.s_to_dt.Title = "~"
        Me.s_to_dt.TitleWidth = 15
        '
        's_fr_dt
        '
        Me.s_fr_dt.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_fr_dt.Location = New System.Drawing.Point(6, 37)
        Me.s_fr_dt.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.s_fr_dt.Name = "s_fr_dt"
        Me.s_fr_dt.Size = New System.Drawing.Size(194, 20)
        Me.s_fr_dt.TabIndex = 4
        Me.s_fr_dt.Title = "Trip Date"
        Me.s_fr_dt.TitleWidth = 90
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.g10)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(1750, 671)
        Me.SplitContainer2.SplitterDistance = 500
        Me.SplitContainer2.SplitterWidth = 5
        Me.SplitContainer2.TabIndex = 0
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(500, 671)
        Me.g10.TabIndex = 1
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel4)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.g20)
        Me.SplitContainer3.Size = New System.Drawing.Size(1245, 671)
        Me.SplitContainer3.SplitterDistance = 255
        Me.SplitContainer3.TabIndex = 0
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.dd)
        Me.EPanel4.Controls.Add(Me.pid)
        Me.EPanel4.Controls.Add(Me.doc_no)
        Me.EPanel4.Controls.Add(Me.area)
        Me.EPanel4.Controls.Add(Me.voucher_no)
        Me.EPanel4.Controls.Add(Me.status)
        Me.EPanel4.Controls.Add(Me.memo)
        Me.EPanel4.Controls.Add(Me.position)
        Me.EPanel4.Controls.Add(Me.apply_date)
        Me.EPanel4.Controls.Add(Me.days)
        Me.EPanel4.Controls.Add(Me.to_date)
        Me.EPanel4.Controls.Add(Me.from_date)
        Me.EPanel4.Controls.Add(Me.place)
        Me.EPanel4.Controls.Add(Me.subject_trip)
        Me.EPanel4.Controls.Add(Me.dept)
        Me.EPanel4.Controls.Add(Me.emp_name)
        Me.EPanel4.Controls.Add(Me.emp_no)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(1245, 255)
        Me.EPanel4.TabIndex = 1
        Me.EPanel4.Text = "     Business Trip Information"
        '
        'dd
        '
        Me.dd.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dd.Location = New System.Drawing.Point(694, 211)
        Me.dd.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dd.Name = "dd"
        Me.dd.Size = New System.Drawing.Size(227, 20)
        Me.dd.TabIndex = 37
        Me.dd.Title = "Days"
        Me.dd.TitleWidth = 90
        '
        'pid
        '
        Me.pid.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pid.Location = New System.Drawing.Point(694, 228)
        Me.pid.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.pid.Name = "pid"
        Me.pid.Size = New System.Drawing.Size(227, 20)
        Me.pid.TabIndex = 36
        Me.pid.Title = "PID"
        Me.pid.TitleWidth = 90
        '
        'doc_no
        '
        Me.doc_no.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.doc_no.Location = New System.Drawing.Point(6, 27)
        Me.doc_no.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.doc_no.Name = "doc_no"
        Me.doc_no.Size = New System.Drawing.Size(227, 20)
        Me.doc_no.TabIndex = 35
        Me.doc_no.Title = "Doc No"
        Me.doc_no.TitleWidth = 90
        '
        'area
        '
        Me.area.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.area.Location = New System.Drawing.Point(6, 96)
        Me.area.Name = "area"
        Me.area.Size = New System.Drawing.Size(412, 20)
        Me.area.TabIndex = 34
        Me.area.Title = "Area"
        Me.area.TitleWidth = 90
        '
        'voucher_no
        '
        Me.voucher_no.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.voucher_no.Location = New System.Drawing.Point(426, 27)
        Me.voucher_no.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.voucher_no.Name = "voucher_no"
        Me.voucher_no.Size = New System.Drawing.Size(261, 20)
        Me.voucher_no.TabIndex = 33
        Me.voucher_no.Title = "Voucher No"
        Me.voucher_no.TitleWidth = 90
        '
        'status
        '
        Me.status.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status.Location = New System.Drawing.Point(426, 50)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(261, 20)
        Me.status.TabIndex = 32
        Me.status.Title = "Status"
        Me.status.TitleWidth = 90
        '
        'memo
        '
        Me.memo.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.memo.Location = New System.Drawing.Point(6, 188)
        Me.memo.Name = "memo"
        Me.memo.Size = New System.Drawing.Size(681, 60)
        Me.memo.TabIndex = 31
        Me.memo.Title = "Memo"
        Me.memo.TitleWidth = 90
        '
        'position
        '
        Me.position.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.position.Location = New System.Drawing.Point(426, 96)
        Me.position.Name = "position"
        Me.position.Size = New System.Drawing.Size(261, 20)
        Me.position.TabIndex = 30
        Me.position.Title = "Position"
        Me.position.TitleWidth = 90
        '
        'apply_date
        '
        Me.apply_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.apply_date.Location = New System.Drawing.Point(6, 50)
        Me.apply_date.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.apply_date.Name = "apply_date"
        Me.apply_date.Size = New System.Drawing.Size(227, 20)
        Me.apply_date.TabIndex = 23
        Me.apply_date.Title = "Apply Date"
        Me.apply_date.TitleWidth = 90
        '
        'days
        '
        Me.days.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.days.Location = New System.Drawing.Point(426, 119)
        Me.days.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.days.Name = "days"
        Me.days.Size = New System.Drawing.Size(261, 20)
        Me.days.TabIndex = 20
        Me.days.Title = "Days"
        Me.days.TitleWidth = 90
        '
        'to_date
        '
        Me.to_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.to_date.Location = New System.Drawing.Point(241, 119)
        Me.to_date.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.to_date.Name = "to_date"
        Me.to_date.Size = New System.Drawing.Size(177, 20)
        Me.to_date.TabIndex = 19
        Me.to_date.Title = "~"
        Me.to_date.TitleAlign = Frame9.Alignment.Center
        Me.to_date.TitleWidth = 40
        '
        'from_date
        '
        Me.from_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.from_date.Location = New System.Drawing.Point(6, 119)
        Me.from_date.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.from_date.Name = "from_date"
        Me.from_date.Size = New System.Drawing.Size(227, 20)
        Me.from_date.TabIndex = 18
        Me.from_date.Title = "Period"
        Me.from_date.TitleWidth = 90
        '
        'place
        '
        Me.place.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.place.Location = New System.Drawing.Point(6, 142)
        Me.place.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.place.Name = "place"
        Me.place.Size = New System.Drawing.Size(681, 20)
        Me.place.TabIndex = 8
        Me.place.Title = "Place"
        Me.place.TitleWidth = 90
        '
        'subject_trip
        '
        Me.subject_trip.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.subject_trip.Location = New System.Drawing.Point(6, 165)
        Me.subject_trip.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.subject_trip.Name = "subject_trip"
        Me.subject_trip.Size = New System.Drawing.Size(681, 20)
        Me.subject_trip.TabIndex = 7
        Me.subject_trip.Title = "Subject"
        Me.subject_trip.TitleWidth = 90
        '
        'dept
        '
        Me.dept.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dept.Location = New System.Drawing.Point(426, 73)
        Me.dept.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dept.Name = "dept"
        Me.dept.Size = New System.Drawing.Size(261, 20)
        Me.dept.TabIndex = 6
        Me.dept.Title = "Dept."
        Me.dept.TitleWidth = 90
        '
        'emp_name
        '
        Me.emp_name.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.emp_name.Location = New System.Drawing.Point(237, 73)
        Me.emp_name.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.emp_name.Name = "emp_name"
        Me.emp_name.Size = New System.Drawing.Size(181, 20)
        Me.emp_name.TabIndex = 5
        Me.emp_name.Title = "Applicant"
        Me.emp_name.TitleWidth = 0
        '
        'emp_no
        '
        Me.emp_no.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.emp_no.Location = New System.Drawing.Point(6, 73)
        Me.emp_no.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.emp_no.Name = "emp_no"
        Me.emp_no.Size = New System.Drawing.Size(227, 20)
        Me.emp_no.TabIndex = 4
        Me.emp_no.Title = "Emp No"
        Me.emp_no.TitleWidth = 90
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(1245, 412)
        Me.g20.TabIndex = 2
        '
        'EPanel1
        '
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(274, 185)
        Me.EPanel1.TabIndex = 0
        '
        'EPanel2
        '
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(274, 185)
        Me.EPanel2.TabIndex = 0
        '
        'EButton1
        '
        Me.EButton1.Appearance.Options.UseTextOptions = True
        Me.EButton1.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
        Me.EButton1.Location = New System.Drawing.Point(1412, 24)
        Me.EButton1.Name = "EButton1"
        Me.EButton1.Size = New System.Drawing.Size(133, 43)
        Me.EButton1.TabIndex = 63
        Me.EButton1.Text = "TEST"
        '
        'HR370
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "HR370"
        Me.Size = New System.Drawing.Size(1750, 750)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents EPanel1 As Frame9.ePanel
    Friend WithEvents EPanel2 As Frame9.ePanel
    Friend WithEvents EPanel3 As Frame9.ePanel
    Friend WithEvents s_to_dt As Frame9.eDate
    Friend WithEvents s_fr_dt As Frame9.eDate
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents g10 As Frame9.eGrid
    Friend WithEvents btn_groupware As Frame9.eButton
    Friend WithEvents s_course As Frame9.eText
    Friend WithEvents s_status As Frame9.eCombo
    Friend WithEvents s_dept As Frame9.eText
    Friend WithEvents s_emp_no As Frame9.eText
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents EPanel4 As Frame9.ePanel
    Friend WithEvents doc_no As Frame9.eText
    Friend WithEvents area As Frame9.eCombo
    Friend WithEvents voucher_no As Frame9.eText
    Friend WithEvents status As Frame9.eCombo
    Friend WithEvents memo As Frame9.eMemo
    Friend WithEvents position As Frame9.eCombo
    Friend WithEvents apply_date As Frame9.eDate
    Friend WithEvents days As Frame9.eText
    Friend WithEvents to_date As Frame9.eDate
    Friend WithEvents from_date As Frame9.eDate
    Friend WithEvents place As Frame9.eText
    Friend WithEvents subject_trip As Frame9.eText
    Friend WithEvents dept As Frame9.eText
    Friend WithEvents emp_name As Frame9.eText
    Friend WithEvents emp_no As Frame9.eText
    Friend WithEvents g20 As Frame9.eGrid
    Friend WithEvents pid As Frame9.eText
    Friend WithEvents dd As Frame9.eText
    Friend WithEvents EButton1 As Frame9.eButton
End Class
