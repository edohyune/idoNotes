Imports Frame9
Imports Base9
Imports Base9.Shared
Imports System.IO
Imports System.Net
Imports DevExpress.XtraReports
Imports System9

Public Class HR370
    Private Sub SA100_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'doc_no.CodeNo = "HA560"
        'doc_no.CodeDateField = apply_date
    End Sub

    Private Sub from_date_TextChanged(sender As Object, e As EventArgs)        '
        Dim ds As DataSet = OpenDataSet("hr370_getday")
        dd.Text = DataValue(ds)
    End Sub

    'Private Sub to_date_TextChanged(sender As Object, e As EventArgs)
    '    Dim ds As DataSet = OpenDataSet("hr370_getday")
    '    dd.Text = DataValue(ds)
    'End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
        Select Case mty
            Case MenuType.Open
                Me.Open()
            Case MenuType.Print
            Case MenuType.New
                doc_no.Text = ""
                OpenTrigger("hr370_g10")
                _ReadOnly(False)
            Case MenuType.Save
                If doc_no.Text = "" Then
                    Dim dset As DataSet = OpenDataSet("hr370_getAutoNum")
                    doc_no.Text = DataValue(dset, "doc_no")
                End If
                If Me.Save() Then
                    Dim finder As String = doc_no.Text
                    Me.Open()
                    g10.Find("doc_no = " + finder)
                End If
        End Select

    End Sub

    Private Sub _ReadOnly(ByVal ref As Boolean)
        emp_no.ReadOnly = ref
        apply_date.ReadOnly = ref
        area.ReadOnly = ref
        subject_trip.ReadOnly = ref
        place.ReadOnly = ref
        from_date.ReadOnly = ref
        to_date.ReadOnly = ref
        days.ReadOnly = ref
        memo.ReadOnly = ref
        g20.ReadOnly = ref
    End Sub

    Private Sub g10_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g10.AfterMoveRow
        If g10.Text("status", RowIndex) = "FI020100" Then
            _ReadOnly(False)
            btn_groupware.Enabled = True
        Else
            _ReadOnly(True)
            btn_groupware.Enabled = False
        End If
    End Sub

    Private Sub to_date_TextChanged(sender As Object, e As EventArgs) Handles to_date.TextChanged

        If from_date.Text <> "" And to_date.Text <> "" Then
            If to_date.Text < from_date.Text Then
                PutMessage("BJC100_23", "The start date is greater than the end date.")
                to_date.Text = ""
                Exit Sub
            End If
        End If
        Dim ds As DataSet = OpenDataSet("hr370_getday")
        dd.Text = DataValue(ds)
    End Sub

    Private Sub g20_CellValueChanged(sender As Object, ColumnName As String, RowIndex As Integer, ByRef Value As Object) Handles g20.CellValueChanged
        If ColumnName = "allowance_type" Then
            If g20.Text("allowance_type", RowIndex) <> "FI017100" Then
                g20.ColumnReadOnly("allowance_amt") = False
            End If
            If g20.Text("allowance_type", RowIndex) = "FI017100" Then
                g20.ColumnReadOnly("allowance_amt") = True
                Dim amt As DataSet = OpenDataSet("hr370_getallowance")
                g20.Text("allowance_amt") = DataValue(amt)
            End If
        End If
    End Sub

#Region "Approval Button =========================================  Edit"
    Public m_stop_event As Boolean
    'Connect to Handles
    Private Sub btn_groupware_Click(sender As Object, e As EventArgs) Handles btn_groupware.Click
        If m_stop_event Then Exit Sub
        m_stop_event = True

        'Condtion Check
        If g20.RowCount < 1 Then      '''''''''''''''''''''''''''''''''Edit Grid 
            Exit Sub
        End If

        'Current Document Parameters Value Setting
        Dim docNo As String = doc_no.Text        ''''''''''''''''''''''Edit
        Dim docDt As String = apply_date.Text    ''''''''''''''''''''''Edit
        Dim empNo As String = emp_no.Text        ''''''''''''''''''''''Edit
        Dim deptCd As String = dept.Text         ''''''''''''''''''''''Edit
        Dim testYn As Boolean = False            ''''''''''''''''''''''Edit (True : Can See Print)

        Dim rtnGroupWareProcess As String = groupWareProcess(docNo, docDt, empNo, deptCd, testYn)
        If rtnGroupWareProcess = "OK" Then
            m_stop_event = False
            PutMessage("BJC100_24", "It has been processed succeed.")
            Dim find As String = doc_no.Text
            Me.Open()
            g10.Find("doc_no=" + find)
            Exit Sub
        End If
    End Sub
#End Region
#Region "Approval Can See Print ======================= Do not need Edit"
    'Handles EButton1.Click
    Private Sub CanSeePrint_Click(sender As Object, e As EventArgs) 'Handles EButton1.Click
        'Condtion Check
        If m_stop_event Then Exit Sub
        m_stop_event = True

        If g20.RowCount < 1 Then      '''''''''''''''''''''''''''''''''Edit Grid 
            Exit Sub
        End If

        'Current Document Parameters Value Setting
        Dim docNo As String = doc_no.Text        ''''''''''''''''''''''Edit
        Dim docDt As String = apply_date.Text    ''''''''''''''''''''''Edit
        Dim empNo As String = emp_no.Text        ''''''''''''''''''''''Edit
        Dim deptCd As String = dept.Text         ''''''''''''''''''''''Edit
        Dim testYn As Boolean = True             ''''''''''''''''''''''Edit

        Dim rtnGroupWareProcess As String = groupWareProcess(docNo, docDt, empNo, deptCd, testYn)
        If rtnGroupWareProcess = "OK" Then
            MsgBox("")
        ElseIf rtnGroupWareProcess = "TEST" Then
            MsgBox("testYn���� False�� �����ϸ� �׷����� �����Ͱ� ���۵˴ϴ�.")
        Else
            MsgBox(rtnGroupWareProcess)
        End If
    End Sub
#End Region
#Region "Approval ===================================== Do not need Edit"
    Private Function groupWareProcess(docNo As String, docDt As String, empNo As String, deptCd As String, testYn As Boolean) As String
        Dim frmCd As String = Me.Name

        Dim dinitSet As System.Data.DataSet = MyBase.OpenDataSet(frmCd + "_approvalInit")
        Dim gwNo As String = DataValue(dinitSet, "doc_code")
        Dim docStat As String = DataValue(dinitSet, "doc_status")
        Dim tblNm As String = DataValue(dinitSet, "table_name")
        If empNo = "" Then
            empNo = DataValue(dinitSet, "emp_no")
        End If
        If deptCd = "" Then
            empNo = DataValue(dinitSet, "dept_cd")
        End If

        Dim p As OpenParameters = New OpenParameters
        p.Add("@form_name", frmCd)
        p.Add("@table_name", tblNm)
        p.Add("@doc_code", gwNo)
        p.Add("@doc_no", docNo)
        p.Add("@doc_date", docDt)
        p.Add("@dept", deptCd)
        p.Add("@emp_no", empNo)
        p.Add("@doc_stat", docStat)

        Dim dSet1 As DataSet = OpenDataSet(frmCd + "_approvalHtml", p)
        Dim Rpt1 As New ApprovalDoc(dSet1)

        If testYn Then
            Dim ReportPrintTool As New DevExpress.XtraReports.UI.ReportPrintTool(Rpt1)
            ReportPrintTool.ShowPreviewDialog()
            Return "TEST"
        Else
            If Directory.Exists("c:\temp\") = False Then
                Directory.CreateDirectory("c:\temp\")
            End If

            Rpt1.CreateDocument()

            Dim htmlId As String = Guid.NewGuid().ToString("N")
            Dim fileNm As String = "c:\temp\" + htmlId + ".html"

            Rpt1.ExportToHtml(fileNm)

            Dim client As New WebClient
            client.Encoding = System.Text.Encoding.UTF8
            Dim html As String = client.DownloadString(New Uri(fileNm))

            html = Replace(html, "'", "''")

            p.Add("@htm", html)

            Dim dset2 As DataSet = OpenDataSet(frmCd + "_approvalSubmit", p)

            If IsEmpty(dset2) Then
                Return frmCd + "_approvalSubmit ERROR"
            Else
                Return DataValue(dset2, "rtn")
            End If
        End If
    End Function
#End Region

End Class
