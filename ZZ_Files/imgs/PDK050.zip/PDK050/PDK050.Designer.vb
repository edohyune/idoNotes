<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PDK050
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.Worker = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer17 = New System.Windows.Forms.SplitContainer()
        Me.EPanel25 = New Frame8.ePanel()
        Me.z_ismanager = New Frame8.eText()
        Me.z_kioskNm = New Frame8.eText()
        Me.z_kioskCd = New Frame8.eText()
        Me.f_use_yn = New Frame8.eCheck()
        Me.z_today = New Frame8.eDate()
        Me.z_btnSearch = New Frame8.eButton()
        Me.z_emp = New Frame8.eText()
        Me.z01 = New Frame8.eGrid()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.panSearch = New Frame8.ePanel()
        Me.s_mdlBc = New Frame8.eCombo()
        Me.btnSearch = New Frame8.eButton()
        Me.s_vinNo = New Frame8.eText()
        Me.s_lineCd = New Frame8.eCombo()
        Me.panList = New Frame8.ePanel()
        Me.g40 = New Frame8.eGrid()
        Me.g30 = New Frame8.eGrid()
        Me.g20 = New Frame8.eGrid()
        Me.g10 = New Frame8.eGrid()
        Me.panJob = New Frame8.ePanel()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.EPanel1 = New Frame8.ePanel()
        Me.curr_KIOSK = New Frame8.eCombo()
        Me.set_lineset = New Frame8.eCombo()
        Me.set_kiosk = New Frame8.eCombo()
        Me.btnSetting = New Frame8.eButton()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.btn_query = New Frame8.eButton()
        Me.r30 = New Frame8.eGrid()
        Me.r20 = New Frame8.eGrid()
        Me.r10 = New Frame8.eGrid()
        Me.r40 = New Frame8.eGrid()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.Worker.SuspendLayout()
        Me.SplitContainer17.Panel1.SuspendLayout()
        Me.SplitContainer17.Panel2.SuspendLayout()
        Me.SplitContainer17.SuspendLayout()
        CType(Me.EPanel25, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel25.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.panSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panSearch.SuspendLayout()
        CType(Me.panList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panList.SuspendLayout()
        CType(Me.panJob, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabPage2.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.XtraTabPage3.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.Worker
        Me.XtraTabControl1.Size = New System.Drawing.Size(1240, 901)
        Me.XtraTabControl1.TabIndex = 100
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.Worker, Me.XtraTabPage1, Me.XtraTabPage2, Me.XtraTabPage3})
        '
        'Worker
        '
        Me.Worker.Controls.Add(Me.SplitContainer17)
        Me.Worker.Name = "Worker"
        Me.Worker.Size = New System.Drawing.Size(1234, 873)
        Me.Worker.TabPageWidth = 150
        Me.Worker.Text = "Worker"
        '
        'SplitContainer17
        '
        Me.SplitContainer17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer17.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer17.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer17.Name = "SplitContainer17"
        Me.SplitContainer17.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer17.Panel1
        '
        Me.SplitContainer17.Panel1.Controls.Add(Me.EPanel25)
        '
        'SplitContainer17.Panel2
        '
        Me.SplitContainer17.Panel2.Controls.Add(Me.z01)
        Me.SplitContainer17.Size = New System.Drawing.Size(1234, 873)
        Me.SplitContainer17.SplitterDistance = 125
        Me.SplitContainer17.TabIndex = 100
        '
        'EPanel25
        '
        Me.EPanel25.Controls.Add(Me.z_ismanager)
        Me.EPanel25.Controls.Add(Me.z_kioskNm)
        Me.EPanel25.Controls.Add(Me.z_kioskCd)
        Me.EPanel25.Controls.Add(Me.f_use_yn)
        Me.EPanel25.Controls.Add(Me.z_today)
        Me.EPanel25.Controls.Add(Me.z_btnSearch)
        Me.EPanel25.Controls.Add(Me.z_emp)
        Me.EPanel25.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel25.Location = New System.Drawing.Point(0, 0)
        Me.EPanel25.Name = "EPanel25"
        Me.EPanel25.Size = New System.Drawing.Size(1234, 125)
        Me.EPanel25.TabIndex = 0
        Me.EPanel25.Text = "     Search"
        '
        'z_ismanager
        '
        Me.z_ismanager.AutoHeight = False
        Me.z_ismanager.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.z_ismanager.Location = New System.Drawing.Point(706, 77)
        Me.z_ismanager.Name = "z_ismanager"
        Me.z_ismanager.Size = New System.Drawing.Size(189, 45)
        Me.z_ismanager.TabIndex = 1007
        Me.z_ismanager.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_ismanager.Title = "Status"
        Me.z_ismanager.TitleAlign = Frame8.Alignment.Right
        Me.z_ismanager.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_ismanager.TitleWidth = 120
        '
        'z_kioskNm
        '
        Me.z_kioskNm.AutoHeight = False
        Me.z_kioskNm.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.z_kioskNm.Location = New System.Drawing.Point(6, 24)
        Me.z_kioskNm.Name = "z_kioskNm"
        Me.z_kioskNm.Size = New System.Drawing.Size(450, 45)
        Me.z_kioskNm.TabIndex = 1006
        Me.z_kioskNm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_kioskNm.Title = "KIOSK"
        Me.z_kioskNm.TitleAlign = Frame8.Alignment.Right
        Me.z_kioskNm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_kioskNm.TitleWidth = 120
        '
        'z_kioskCd
        '
        Me.z_kioskCd.AutoHeight = False
        Me.z_kioskCd.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.z_kioskCd.Location = New System.Drawing.Point(462, 26)
        Me.z_kioskCd.Name = "z_kioskCd"
        Me.z_kioskCd.Size = New System.Drawing.Size(315, 45)
        Me.z_kioskCd.TabIndex = 1005
        Me.z_kioskCd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_kioskCd.Title = "kiosk_cd"
        Me.z_kioskCd.TitleAlign = Frame8.Alignment.Right
        Me.z_kioskCd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_kioskCd.TitleWidth = 120
        '
        'f_use_yn
        '
        Me.f_use_yn.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.f_use_yn.Location = New System.Drawing.Point(635, 79)
        Me.f_use_yn.Name = "f_use_yn"
        Me.f_use_yn.Size = New System.Drawing.Size(65, 33)
        Me.f_use_yn.TabIndex = 1004
        Me.f_use_yn.Title = "ALL"
        Me.f_use_yn.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_use_yn.TitleLocation = Frame8.TitleLocation.Right
        Me.f_use_yn.TitleWidth = 50
        '
        'z_today
        '
        Me.z_today.BorderStyle = Frame8.BorderStyle.None
        Me.z_today.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.z_today.Location = New System.Drawing.Point(783, 29)
        Me.z_today.Name = "z_today"
        Me.z_today.Size = New System.Drawing.Size(300, 40)
        Me.z_today.TabIndex = 1003
        Me.z_today.TextAlign = Frame8.Alignment.Center
        Me.z_today.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_today.Title = "Today"
        Me.z_today.TitleAlign = Frame8.Alignment.Right
        Me.z_today.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_today.TitleWidth = 85
        '
        'z_btnSearch
        '
        Me.z_btnSearch.Appearance.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.z_btnSearch.Appearance.Options.UseFont = True
        Me.z_btnSearch.Location = New System.Drawing.Point(471, 73)
        Me.z_btnSearch.Name = "z_btnSearch"
        Me.z_btnSearch.Size = New System.Drawing.Size(153, 45)
        Me.z_btnSearch.TabIndex = 29
        Me.z_btnSearch.Text = "Search"
        '
        'z_emp
        '
        Me.z_emp.AutoHeight = False
        Me.z_emp.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.z_emp.Location = New System.Drawing.Point(6, 73)
        Me.z_emp.Name = "z_emp"
        Me.z_emp.Size = New System.Drawing.Size(450, 45)
        Me.z_emp.TabIndex = 25
        Me.z_emp.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_emp.Title = "Emp.ID"
        Me.z_emp.TitleAlign = Frame8.Alignment.Right
        Me.z_emp.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.z_emp.TitleWidth = 120
        '
        'z01
        '
        Me.z01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.z01.Location = New System.Drawing.Point(0, 0)
        Me.z01.Name = "z01"
        Me.z01.Size = New System.Drawing.Size(1234, 744)
        Me.z01.TabIndex = 4
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.SplitContainer1)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1234, 873)
        Me.XtraTabPage1.TabPageWidth = 150
        Me.XtraTabPage1.Text = "Line"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.panJob)
        Me.SplitContainer1.Size = New System.Drawing.Size(1234, 873)
        Me.SplitContainer1.SplitterDistance = 660
        Me.SplitContainer1.TabIndex = 108
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.panSearch)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.panList)
        Me.SplitContainer2.Size = New System.Drawing.Size(660, 873)
        Me.SplitContainer2.SplitterDistance = 240
        Me.SplitContainer2.TabIndex = 107
        '
        'panSearch
        '
        Me.panSearch.Controls.Add(Me.s_mdlBc)
        Me.panSearch.Controls.Add(Me.btnSearch)
        Me.panSearch.Controls.Add(Me.s_vinNo)
        Me.panSearch.Controls.Add(Me.s_lineCd)
        Me.panSearch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panSearch.Location = New System.Drawing.Point(0, 0)
        Me.panSearch.Name = "panSearch"
        Me.panSearch.Size = New System.Drawing.Size(660, 240)
        Me.panSearch.TabIndex = 101
        Me.panSearch.Text = "     Search"
        '
        's_mdlBc
        '
        Me.s_mdlBc.BorderStyle = Frame8.BorderStyle.Office2003
        Me.s_mdlBc.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_mdlBc.Location = New System.Drawing.Point(15, 123)
        Me.s_mdlBc.Name = "s_mdlBc"
        Me.s_mdlBc.Size = New System.Drawing.Size(625, 42)
        Me.s_mdlBc.TabIndex = 1006
        Me.s_mdlBc.TextAlign = Frame8.Alignment.Left
        Me.s_mdlBc.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.s_mdlBc.Title = "Model"
        Me.s_mdlBc.TitleAlign = Frame8.Alignment.Left
        Me.s_mdlBc.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.s_mdlBc.TitleWidth = 115
        '
        'btnSearch
        '
        Me.btnSearch.Appearance.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.Appearance.Options.UseFont = True
        Me.btnSearch.Location = New System.Drawing.Point(15, 171)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(625, 59)
        Me.btnSearch.TabIndex = 1005
        Me.btnSearch.Text = "Search"
        '
        's_vinNo
        '
        Me.s_vinNo.AutoHeight = False
        Me.s_vinNo.BorderStyle = Frame8.BorderStyle.Office2003
        Me.s_vinNo.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_vinNo.Location = New System.Drawing.Point(15, 72)
        Me.s_vinNo.Name = "s_vinNo"
        Me.s_vinNo.Size = New System.Drawing.Size(625, 45)
        Me.s_vinNo.TabIndex = 1003
        Me.s_vinNo.TextAlign = Frame8.Alignment.Left
        Me.s_vinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.s_vinNo.Title = "Frame#"
        Me.s_vinNo.TitleAlign = Frame8.Alignment.Left
        Me.s_vinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.s_vinNo.TitleWidth = 115
        '
        's_lineCd
        '
        Me.s_lineCd.BorderStyle = Frame8.BorderStyle.Office2003
        Me.s_lineCd.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s_lineCd.Location = New System.Drawing.Point(15, 26)
        Me.s_lineCd.Name = "s_lineCd"
        Me.s_lineCd.Size = New System.Drawing.Size(625, 42)
        Me.s_lineCd.TabIndex = 1002
        Me.s_lineCd.TextAlign = Frame8.Alignment.Left
        Me.s_lineCd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.s_lineCd.Title = "Line"
        Me.s_lineCd.TitleAlign = Frame8.Alignment.Left
        Me.s_lineCd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.s_lineCd.TitleWidth = 115
        '
        'panList
        '
        Me.panList.Controls.Add(Me.g40)
        Me.panList.Controls.Add(Me.g30)
        Me.panList.Controls.Add(Me.g20)
        Me.panList.Controls.Add(Me.g10)
        Me.panList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panList.Location = New System.Drawing.Point(0, 0)
        Me.panList.Name = "panList"
        Me.panList.Size = New System.Drawing.Size(660, 629)
        Me.panList.TabIndex = 101
        Me.panList.Text = "     Job List"
        '
        'g40
        '
        Me.g40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g40.Location = New System.Drawing.Point(2, 21)
        Me.g40.Name = "g40"
        Me.g40.Size = New System.Drawing.Size(656, 606)
        Me.g40.TabIndex = 6
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(2, 21)
        Me.g30.Name = "g30"
        Me.g30.Size = New System.Drawing.Size(656, 606)
        Me.g30.TabIndex = 4
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(2, 21)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(656, 606)
        Me.g20.TabIndex = 3
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(2, 21)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(656, 606)
        Me.g10.TabIndex = 2
        '
        'panJob
        '
        Me.panJob.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panJob.Location = New System.Drawing.Point(0, 0)
        Me.panJob.Name = "panJob"
        Me.panJob.Size = New System.Drawing.Size(570, 873)
        Me.panJob.TabIndex = 101
        Me.panJob.Text = "     Job Excute"
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.EPanel1)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1234, 873)
        Me.XtraTabPage2.TabPageWidth = 150
        Me.XtraTabPage2.Text = "Setting"
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.curr_KIOSK)
        Me.EPanel1.Controls.Add(Me.set_lineset)
        Me.EPanel1.Controls.Add(Me.set_kiosk)
        Me.EPanel1.Controls.Add(Me.btnSetting)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1234, 873)
        Me.EPanel1.TabIndex = 102
        Me.EPanel1.Text = "     Job Excute"
        '
        'curr_KIOSK
        '
        Me.curr_KIOSK.BorderStyle = Frame8.BorderStyle.None
        Me.curr_KIOSK.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.curr_KIOSK.Location = New System.Drawing.Point(29, 47)
        Me.curr_KIOSK.Name = "curr_KIOSK"
        Me.curr_KIOSK.Size = New System.Drawing.Size(563, 40)
        Me.curr_KIOSK.TabIndex = 1010
        Me.curr_KIOSK.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.curr_KIOSK.Title = "Current KIOSK"
        Me.curr_KIOSK.TitleAlign = Frame8.Alignment.Right
        Me.curr_KIOSK.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.curr_KIOSK.TitleWidth = 220
        '
        'set_lineset
        '
        Me.set_lineset.BorderStyle = Frame8.BorderStyle.None
        Me.set_lineset.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.set_lineset.Location = New System.Drawing.Point(29, 231)
        Me.set_lineset.Name = "set_lineset"
        Me.set_lineset.Size = New System.Drawing.Size(563, 40)
        Me.set_lineset.TabIndex = 1008
        Me.set_lineset.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.set_lineset.Title = "LineSet"
        Me.set_lineset.TitleAlign = Frame8.Alignment.Right
        Me.set_lineset.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.set_lineset.TitleWidth = 220
        '
        'set_kiosk
        '
        Me.set_kiosk.BorderStyle = Frame8.BorderStyle.None
        Me.set_kiosk.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.set_kiosk.Location = New System.Drawing.Point(29, 286)
        Me.set_kiosk.Name = "set_kiosk"
        Me.set_kiosk.Size = New System.Drawing.Size(563, 40)
        Me.set_kiosk.TabIndex = 1007
        Me.set_kiosk.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.set_kiosk.Title = "KIOSK"
        Me.set_kiosk.TitleAlign = Frame8.Alignment.Right
        Me.set_kiosk.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.set_kiosk.TitleWidth = 220
        '
        'btnSetting
        '
        Me.btnSetting.Appearance.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetting.Appearance.Options.UseFont = True
        Me.btnSetting.Location = New System.Drawing.Point(145, 351)
        Me.btnSetting.Name = "btnSetting"
        Me.btnSetting.Size = New System.Drawing.Size(447, 59)
        Me.btnSetting.TabIndex = 1006
        Me.btnSetting.Text = "Setting"
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.Controls.Add(Me.SplitContainer3)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(1234, 873)
        Me.XtraTabPage3.TabPageWidth = 150
        Me.XtraTabPage3.Text = "Today Result"
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.r30)
        Me.SplitContainer3.Panel2.Controls.Add(Me.r20)
        Me.SplitContainer3.Panel2.Controls.Add(Me.r10)
        Me.SplitContainer3.Panel2.Controls.Add(Me.r40)
        Me.SplitContainer3.Size = New System.Drawing.Size(1234, 873)
        Me.SplitContainer3.SplitterDistance = 84
        Me.SplitContainer3.TabIndex = 0
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.btn_query)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(1234, 84)
        Me.EPanel2.TabIndex = 104
        Me.EPanel2.Text = "     Today result"
        '
        'btn_query
        '
        Me.btn_query.Appearance.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_query.Appearance.Options.UseFont = True
        Me.btn_query.Location = New System.Drawing.Point(56, 28)
        Me.btn_query.Name = "btn_query"
        Me.btn_query.Size = New System.Drawing.Size(153, 45)
        Me.btn_query.TabIndex = 30
        Me.btn_query.Text = "Query"
        '
        'r30
        '
        Me.r30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.r30.Location = New System.Drawing.Point(0, 0)
        Me.r30.Name = "r30"
        Me.r30.Size = New System.Drawing.Size(1234, 785)
        Me.r30.TabIndex = 11
        '
        'r20
        '
        Me.r20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.r20.Location = New System.Drawing.Point(0, 0)
        Me.r20.Name = "r20"
        Me.r20.Size = New System.Drawing.Size(1234, 785)
        Me.r20.TabIndex = 10
        '
        'r10
        '
        Me.r10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.r10.Location = New System.Drawing.Point(0, 0)
        Me.r10.Name = "r10"
        Me.r10.Size = New System.Drawing.Size(1234, 785)
        Me.r10.TabIndex = 9
        '
        'r40
        '
        Me.r40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.r40.Location = New System.Drawing.Point(0, 0)
        Me.r40.Name = "r40"
        Me.r40.Size = New System.Drawing.Size(1234, 785)
        Me.r40.TabIndex = 12
        '
        'PDK050
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.XtraTabControl1)
        Me.Name = "PDK050"
        Me.Size = New System.Drawing.Size(1240, 901)
        Me.Controls.SetChildIndex(Me.XtraTabControl1, 0)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.Worker.ResumeLayout(False)
        Me.SplitContainer17.Panel1.ResumeLayout(False)
        Me.SplitContainer17.Panel2.ResumeLayout(False)
        Me.SplitContainer17.ResumeLayout(False)
        CType(Me.EPanel25, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel25.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.panSearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panSearch.ResumeLayout(False)
        CType(Me.panList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panList.ResumeLayout(False)
        CType(Me.panJob, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabPage2.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.XtraTabPage3.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents Worker As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer17 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel25 As Frame8.ePanel
    Friend WithEvents z_emp As Frame8.eText
    Friend WithEvents z_btnSearch As Frame8.eButton
    Friend WithEvents z01 As Frame8.eGrid
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents panSearch As Frame8.ePanel
    Friend WithEvents btnSearch As Frame8.eButton
    Friend WithEvents s_vinNo As Frame8.eText
    Friend WithEvents panList As Frame8.ePanel
    Friend WithEvents panJob As Frame8.ePanel
    Friend WithEvents s_mdlBc As Frame8.eCombo
    Friend WithEvents f_use_yn As Frame8.eCheck
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents EPanel1 As Frame8.ePanel
    Friend WithEvents curr_KIOSK As Frame8.eCombo
    Friend WithEvents set_lineset As Frame8.eCombo
    Friend WithEvents set_kiosk As Frame8.eCombo
    Friend WithEvents btnSetting As Frame8.eButton
    Public WithEvents z_kioskCd As Frame8.eText
    Public WithEvents g30 As Frame8.eGrid
    Public WithEvents g20 As Frame8.eGrid
    Public WithEvents g10 As Frame8.eGrid
    Public WithEvents s_lineCd As Frame8.eCombo
    Public WithEvents z_today As Frame8.eDate
    Public WithEvents g40 As Frame8.eGrid
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Public WithEvents z_kioskNm As Frame8.eText
    Public WithEvents z_ismanager As Frame8.eText
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents btn_query As Frame8.eButton
    Friend WithEvents r30 As Frame8.eGrid
    Friend WithEvents r20 As Frame8.eGrid
    Friend WithEvents r10 As Frame8.eGrid
    Friend WithEvents r40 As Frame8.eGrid

End Class
