﻿Imports Frame8
Imports Base8
Imports Base8.Shared
Imports System.Data
Imports System.IO
Imports System.Text

Public Class PDK050

    Private Sub Me_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        g10.RowHeight = 50
        g10.Font = New Font("Tahoma", 16, FontStyle.Regular, GraphicsUnit.Point)
        g20.RowHeight = 50
        g20.Font = New Font("Tahoma", 16, FontStyle.Regular, GraphicsUnit.Point)
        g30.RowHeight = 50
        g30.Font = New Font("Tahoma", 16, FontStyle.Regular, GraphicsUnit.Point)
        g40.RowHeight = 50
        g40.Font = New Font("Tahoma", 16, FontStyle.Regular, GraphicsUnit.Point)
        z01.RowHeight = 50
        z01.Font = New Font("Tahoma", 16, FontStyle.Regular, GraphicsUnit.Point)

        Dim fFindFile As New System.IO.FileInfo("C:\KIOSK\KIOSK.txt")

        If IsManager Then
            z_today.ReadOnly = False
            z_kioskNm.ReadOnly = False
            XtraTabPage2.PageVisible = True
            z_ismanager.Text = 1
        Else
            z_today.ReadOnly = True
            z_kioskNm.ReadOnly = True
            XtraTabPage2.PageVisible = False
            z_ismanager.Text = 0
        End If

        If fFindFile.Exists Then
            Dim fileReader As String
            fileReader = My.Computer.FileSystem.ReadAllText("C:\KIOSK\KIOSK.txt")

            z_kioskCd.Text = fileReader.Substring(0, 8)
            curr_KIOSK.Text = fileReader.Substring(0, 8)
        Else
            MsgBox("First, you need to set KIOSK. Please contact the Manager.")
        End If

        XtraTabControl1.SelectedTabPageIndex = 0

        Open("pdk050_Settting")
        Open("pdk050_z01")
    End Sub

    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
        Select Case mty
            Case MenuType.Save
                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Me.Open()
                End If
            Case MenuType.Delete
            Case Else
                MyBase.MenuButton_Click(mty)
        End Select
    End Sub

#Region "Common Function"

    Private Sub s_lineCd_TextChanging(sender As Object, e As EventArgs) Handles s_lineCd.TextChanging
        Dim p As OpenParameters = New OpenParameters

        p.Add("@kiosk", z_kioskCd.Text)
        p.Add("@line", s_lineCd.Text)

        Dim dset As DataSet = OpenDataSet("pdk050_InitUI", p)

        If IsEmpty(dset) Then
            Exit Sub
        End If

        initKiosk(dset.Tables(0).Rows(0)("jobStyle").ToString(), _
                  dset.Tables(0).Rows(0)("btn_ty").ToString(), _
                  dset.Tables(0).Rows(0)("letOut").ToString())

        initEditable(dset.Tables(0).Rows(0)("jobStyle").ToString(), _
                     dset.Tables(0).Rows(0)("vinNo").ToString(), _
                     dset.Tables(0).Rows(0)("engineNo").ToString(), _
                     dset.Tables(0).Rows(0)("missionNo").ToString(), _
                     dset.Tables(0).Rows(0)("keyNo").ToString(), _
                     dset.Tables(0).Rows(0)("cabinNo").ToString(), _
                     dset.Tables(0).Rows(0)("cargoNo").ToString(), _
                     dset.Tables(0).Rows(0)("rearaxleNo").ToString(), _
                     dset.Tables(0).Rows(0)("chkNo").ToString(), _
                     dset.Tables(0).Rows(0)("itmID").ToString(), _
                     dset.Tables(0).Rows(0)("itmQty").ToString(), _
                     dset.Tables(0).Rows(0)("uniqueNo").ToString(), _
                     dset.Tables(0).Rows(0)("ref4").ToString(), _
                     dset.Tables(0).Rows(0)("ref5").ToString(), _
                     dset.Tables(0).Rows(0)("ref6").ToString(), _
                     dset.Tables(0).Rows(0)("ref7").ToString(), _
                     dset.Tables(0).Rows(0)("ref8").ToString())
    End Sub

    Public defect As New Defective
    Private Sub initKiosk(jobStyle As String, btn_ty As String, letOut As String)

        panJob.Controls.Clear()

        g10.Visible = False 'Frame
        g20.Visible = False 'indentity
        g30.Visible = False 'Parts
        g40.Visible = False 'Defective

        r10.Visible = False 'Frame
        r20.Visible = False 'indentity
        r30.Visible = False 'Parts
        r40.Visible = False 'Defective


        'jobStyle
        'PD310100 Frame
        'PD310200 Identity
        'PD310200 Parts ID
        'btn_ty
        'PD320100 Excution
        'PD320200 Start
        'PD320300 End
        'PD320400 Start/End
        'letOut
        '1 / 0 

        Select Case jobStyle
            Case "PD310100"

                s_vinNo.Title = "Frame#"

                g10.Visible = True
                r10.Visible = True
                Frame.Set_Param(Me)
                Frame.TopLevel = False
                Frame.TopMost = True
                panJob.Controls.Add(Frame)
                Frame.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
                Frame.Dock = DockStyle.Fill
                Frame.Show()

                Select Case btn_ty
                    Case "PD320100"
                        Frame.btnExec.Visible = True
                        Frame.btnStart.Visible = False
                        Frame.btnEnd.Visible = False
                        Frame.btnGood.Visible = False
                        Frame.btnNotgood.Visible = False
                    Case "PD320200"
                        Frame.btnExec.Visible = False
                        Frame.btnStart.Visible = True
                        Frame.btnEnd.Visible = False
                        Frame.btnGood.Visible = False
                        Frame.btnNotgood.Visible = False
                    Case "PD320300"
                        Frame.btnExec.Visible = False
                        Frame.btnStart.Visible = False
                        Frame.btnEnd.Visible = True
                        Frame.btnGood.Visible = False
                        Frame.btnNotgood.Visible = False
                    Case "PD320400"
                        Frame.btnExec.Visible = False
                        Frame.btnStart.Visible = True
                        Frame.btnEnd.Visible = True
                        Frame.btnGood.Visible = False
                        Frame.btnNotgood.Visible = False
                    Case "PD320500"
                        Frame.btnExec.Visible = False
                        Frame.btnStart.Visible = False
                        Frame.btnEnd.Visible = False
                        Frame.btnGood.Visible = True
                        Frame.btnNotgood.Visible = True
                End Select

                If letOut = "1" Then
                    Frame.btnletOut.Visible = True
                Else
                    Frame.btnletOut.Visible = False
                End If

                SplitContainer1.SplitterDistance = 550
                s_lineCd.Width = 500
                s_vinNo.Width = 500
                s_mdlBc.Width = 500
                btnSearch.Width = 500

            Case "PD310200"

                s_vinNo.Title = "Cabin#"

                g20.Visible = True
                r20.Visible = True
                identity.Set_Param(Me)
                identity.TopLevel = False
                identity.TopMost = True
                panJob.Controls.Add(identity)
                identity.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
                identity.Dock = DockStyle.Fill
                identity.Show()
                Select Case btn_ty
                    Case "PD320100"
                        identity.btnExec.Visible = True
                        identity.btnStart.Visible = False
                        identity.btnEnd.Visible = False
                        identity.btnGood.Visible = False
                        identity.btnNotgood.Visible = False
                    Case "PD320200"
                        identity.btnExec.Visible = False
                        identity.btnStart.Visible = True
                        identity.btnEnd.Visible = False
                        identity.btnGood.Visible = False
                        identity.btnNotgood.Visible = False
                    Case "PD320300"
                        identity.btnExec.Visible = False
                        identity.btnStart.Visible = False
                        identity.btnEnd.Visible = True
                        identity.btnGood.Visible = False
                        identity.btnNotgood.Visible = False
                    Case "PD320400"
                        identity.btnExec.Visible = False
                        identity.btnStart.Visible = True
                        identity.btnEnd.Visible = True
                        identity.btnGood.Visible = False
                        identity.btnNotgood.Visible = False
                    Case "PD320500"
                        identity.btnExec.Visible = False
                        identity.btnStart.Visible = False
                        identity.btnEnd.Visible = False
                        identity.btnGood.Visible = True
                        identity.btnNotgood.Visible = True
                End Select

                If letOut = "1" Then
                    identity.btnletOut.Visible = True
                Else
                    identity.btnletOut.Visible = False
                End If

                SplitContainer1.SplitterDistance = 630
                s_lineCd.Width = 605
                s_vinNo.Width = 605
                s_mdlBc.Width = 605
                btnSearch.Width = 605

            Case "PD310300"

                s_vinNo.Title = "Parts"

                g30.Visible = True
                r30.Visible = True
                quantity.Set_Param(Me)
                quantity.TopLevel = False
                quantity.TopMost = True
                panJob.Controls.Add(quantity)
                quantity.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
                quantity.Dock = DockStyle.Fill
                quantity.Show()
                Select Case btn_ty
                    Case "PD320100"
                        quantity.btnExec.Visible = True
                        quantity.btnStart.Visible = False
                        quantity.btnEnd.Visible = False
                    Case "PD320200"
                        quantity.btnExec.Visible = False
                        quantity.btnStart.Visible = True
                        quantity.btnEnd.Visible = False
                    Case "PD320300"
                        quantity.btnExec.Visible = False
                        quantity.btnStart.Visible = False
                        quantity.btnEnd.Visible = True
                    Case "PD320400"
                        quantity.btnExec.Visible = False
                        quantity.btnStart.Visible = False
                        quantity.btnEnd.Visible = False
                End Select

                If letOut = "1" Then
                    quantity.btnletOut.Visible = True
                Else
                    quantity.btnletOut.Visible = False
                End If

                SplitContainer1.SplitterDistance = 890
                s_lineCd.Width = 855
                s_vinNo.Width = 855
                s_mdlBc.Width = 855
                btnSearch.Width = 855

            Case "PD310400"

                s_vinNo.Title = "Frame#"
                g40.Visible = True
                r40.Visible = True
                defect = New Defective
                defect.InitPopUP(Me, "")

                defect.TopLevel = False
                defect.TopMost = True
                panJob.Controls.Add(defect)
                defect.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
                defect.Dock = DockStyle.Fill
                defect.Show()

                SplitContainer1.SplitterDistance = 630
                s_lineCd.Width = 605
                s_vinNo.Width = 605
                s_mdlBc.Width = 605
                btnSearch.Width = 605

                defect.initKiosk(btn_ty, letOut)

        End Select

        openGrid()

    End Sub

    Private Sub initEditable(jobStyle As String,
                             vinNo As String, _
                             engineNo As String, _
                             missionNo As String, _
                             keyNo As String, _
                             cabinNo As String, _
                             cargoNo As String, _
                             rearaxleNo As String, _
                             chkNo As String, _
                             itmID As String, _
                             itmQty As String, _
                             uniqueNo As String, _
                             ref4 As String, _
                             ref5 As String, _
                             ref6 As String, _
                             ref7 As String, _
                             ref8 As String)
        'PD330100 readonly
        'PD330200 editable
        'PD330300 hidden

        Select Case jobStyle
            Case "PD310100"

                If vinNo = "PD330300" Then
                    Frame.vinNo.Visible = False
                ElseIf vinNo = "PD330100" Then
                    Frame.vinNo.Visible = True
                    Frame.vinNo.ReadOnly = True
                ElseIf vinNo = "PD330200" Then
                    Frame.vinNo.ReadOnly = False
                    Frame.vinNo.Visible = True
                End If

                If engineNo = "PD330300" Then
                    Frame.engineNo.Visible = False
                ElseIf engineNo = "PD330100" Then
                    Frame.engineNo.Visible = True
                    Frame.engineNo.ReadOnly = True
                ElseIf engineNo = "PD330200" Then
                    Frame.engineNo.ReadOnly = False
                    Frame.engineNo.Visible = True
                End If

                If missionNo = "PD330300" Then
                    Frame.missionNo.Visible = False
                ElseIf missionNo = "PD330100" Then
                    Frame.missionNo.Visible = True
                    Frame.missionNo.ReadOnly = True
                ElseIf missionNo = "PD330200" Then
                    Frame.missionNo.ReadOnly = False
                    Frame.missionNo.Visible = True
                End If

                If keyNo = "PD330300" Then
                    Frame.keyNo.Visible = False
                ElseIf keyNo = "PD330100" Then
                    Frame.keyNo.Visible = True
                    Frame.keyNo.ReadOnly = True
                ElseIf keyNo = "PD330200" Then
                    Frame.keyNo.ReadOnly = False
                    Frame.keyNo.Visible = True
                End If

                If cabinNo = "PD330300" Then
                    Frame.cabinNo.Visible = False
                ElseIf cabinNo = "PD330100" Then
                    Frame.cabinNo.Visible = True
                    Frame.cabinNo.ReadOnly = True
                ElseIf cabinNo = "PD330200" Then
                    Frame.cabinNo.ReadOnly = False
                    Frame.cabinNo.Visible = True
                End If

                If cargoNo = "PD330300" Then
                    Frame.cargoNo.Visible = False
                ElseIf cargoNo = "PD330100" Then
                    Frame.cargoNo.Visible = True
                    Frame.cargoNo.ReadOnly = True
                ElseIf cargoNo = "PD330200" Then
                    Frame.cargoNo.ReadOnly = False
                    Frame.cargoNo.Visible = True
                End If

                If rearaxleNo = "PD330300" Then
                    Frame.rearaxleNo.Visible = False
                ElseIf rearaxleNo = "PD330100" Then
                    Frame.rearaxleNo.Visible = True
                    Frame.rearaxleNo.ReadOnly = True
                ElseIf rearaxleNo = "PD330200" Then
                    Frame.rearaxleNo.ReadOnly = False
                    Frame.rearaxleNo.Visible = True
                End If

                If chkNo = "PD330300" Then
                    Frame.ChkNo.Visible = False
                ElseIf chkNo = "PD330100" Then
                    Frame.ChkNo.Visible = True
                    Frame.ChkNo.ReadOnly = True
                ElseIf chkNo = "PD330200" Then
                    Frame.ChkNo.ReadOnly = False
                    Frame.ChkNo.Visible = True
                End If

                If itmID = "PD330300" Then
                    Frame.itmId.Visible = False
                ElseIf itmID = "PD330100" Then
                    Frame.itmId.Visible = True
                    Frame.itmId.ReadOnly = True
                ElseIf itmID = "PD330200" Then
                    Frame.itmId.ReadOnly = False
                    Frame.itmId.Visible = True
                End If

                If itmQty = "PD330300" Then
                    Frame.ItmQty.Visible = False
                ElseIf itmQty = "PD330100" Then
                    Frame.ItmQty.Visible = True
                    Frame.ItmQty.ReadOnly = True
                ElseIf itmQty = "PD330200" Then
                    Frame.ItmQty.ReadOnly = False
                    Frame.ItmQty.Visible = True
                End If

                If uniqueNo = "PD330300" Then
                    Frame.uniqueNo.Visible = False
                ElseIf uniqueNo = "PD330100" Then
                    Frame.uniqueNo.Visible = True
                    Frame.uniqueNo.ReadOnly = True
                ElseIf uniqueNo = "PD330200" Then
                    Frame.uniqueNo.ReadOnly = False
                    Frame.uniqueNo.Visible = True
                End If

                If ref4 = "PD330300" Then
                    Frame.ref4.Visible = False
                ElseIf ref4 = "PD330100" Then
                    Frame.ref4.Visible = True
                    Frame.ref4.ReadOnly = True
                ElseIf ref4 = "PD330200" Then
                    Frame.ref4.ReadOnly = False
                    Frame.ref4.Visible = True
                End If

                If ref5 = "PD330300" Then
                    Frame.ref5.Visible = False
                ElseIf ref5 = "PD330100" Then
                    Frame.ref5.Visible = True
                    Frame.ref5.ReadOnly = True
                ElseIf ref5 = "PD330200" Then
                    Frame.ref5.ReadOnly = False
                    Frame.ref5.Visible = True
                End If

                If ref6 = "PD330300" Then
                    Frame.ref6.Visible = False
                ElseIf ref6 = "PD330100" Then
                    Frame.ref6.Visible = True
                    Frame.ref6.ReadOnly = True
                ElseIf ref6 = "PD330200" Then
                    Frame.ref6.ReadOnly = False
                    Frame.ref6.Visible = True
                End If

                If ref7 = "PD330300" Then
                    Frame.ref7.Visible = False
                ElseIf ref7 = "PD330100" Then
                    Frame.ref7.Visible = True
                    Frame.ref7.ReadOnly = True
                ElseIf ref7 = "PD330200" Then
                    Frame.ref7.ReadOnly = False
                    Frame.ref7.Visible = True
                End If

                If ref8 = "PD330300" Then
                    Frame.ref8.Visible = False
                ElseIf ref8 = "PD330100" Then
                    Frame.ref8.Visible = True
                    Frame.ref8.ReadOnly = True
                ElseIf ref8 = "PD330200" Then
                    Frame.ref8.ReadOnly = False
                    Frame.ref8.Visible = True
                End If

            Case "PD310200"

                If vinNo = "PD330300" Then
                    identity.vinNo.Visible = False
                ElseIf vinNo = "PD330100" Then
                    identity.vinNo.Visible = True
                    identity.vinNo.ReadOnly = True
                ElseIf vinNo = "PD330200" Then
                    identity.vinNo.ReadOnly = False
                    identity.vinNo.Visible = True
                End If

                If engineNo = "PD330300" Then
                    identity.engineNo.Visible = False
                ElseIf engineNo = "PD330100" Then
                    identity.engineNo.Visible = True
                    identity.engineNo.ReadOnly = True
                ElseIf engineNo = "PD330200" Then
                    identity.engineNo.ReadOnly = False
                    identity.engineNo.Visible = True
                End If

                If missionNo = "PD330300" Then
                    identity.missionNo.Visible = False
                ElseIf missionNo = "PD330100" Then
                    identity.missionNo.Visible = True
                    identity.missionNo.ReadOnly = True
                ElseIf missionNo = "PD330200" Then
                    identity.missionNo.ReadOnly = False
                    identity.missionNo.Visible = True
                End If

                If keyNo = "PD330300" Then
                    identity.keyNo.Visible = False
                ElseIf keyNo = "PD330100" Then
                    identity.keyNo.Visible = True
                    identity.keyNo.ReadOnly = True
                ElseIf keyNo = "PD330200" Then
                    identity.keyNo.ReadOnly = False
                    identity.keyNo.Visible = True
                End If

                If cabinNo = "PD330300" Then
                    identity.cabinNo.Visible = False
                ElseIf cabinNo = "PD330100" Then
                    identity.cabinNo.Visible = True
                    identity.cabinNo.ReadOnly = True
                ElseIf cabinNo = "PD330200" Then
                    identity.cabinNo.ReadOnly = False
                    identity.cabinNo.Visible = True
                End If

                If cargoNo = "PD330300" Then
                    identity.cargoNo.Visible = False
                ElseIf cargoNo = "PD330100" Then
                    identity.cargoNo.Visible = True
                    identity.cargoNo.ReadOnly = True
                ElseIf cargoNo = "PD330200" Then
                    identity.cargoNo.ReadOnly = False
                    identity.cargoNo.Visible = True
                End If

                If rearaxleNo = "PD330300" Then
                    identity.rearaxleNo.Visible = False
                ElseIf rearaxleNo = "PD330100" Then
                    identity.rearaxleNo.Visible = True
                    identity.rearaxleNo.ReadOnly = True
                ElseIf rearaxleNo = "PD330200" Then
                    identity.rearaxleNo.ReadOnly = False
                    identity.rearaxleNo.Visible = True
                End If

                If chkNo = "PD330300" Then
                    identity.ChkNo.Visible = False
                ElseIf chkNo = "PD330100" Then
                    identity.ChkNo.Visible = True
                    identity.ChkNo.ReadOnly = True
                ElseIf chkNo = "PD330200" Then
                    identity.ChkNo.ReadOnly = False
                    identity.ChkNo.Visible = True
                End If

                If itmID = "PD330300" Then
                    identity.itmId.Visible = False
                ElseIf itmID = "PD330100" Then
                    identity.itmId.Visible = True
                    identity.itmId.ReadOnly = True
                ElseIf itmID = "PD330200" Then
                    identity.itmId.ReadOnly = False
                    identity.itmId.Visible = True
                End If

                If itmQty = "PD330300" Then
                    identity.itmQty.Visible = False
                ElseIf itmQty = "PD330100" Then
                    identity.itmQty.Visible = True
                    identity.itmQty.ReadOnly = True
                ElseIf itmQty = "PD330200" Then
                    identity.itmQty.ReadOnly = False
                    identity.itmQty.Visible = True
                End If

                If uniqueNo = "PD330300" Then
                    identity.uniqueNo.Visible = False
                ElseIf uniqueNo = "PD330100" Then
                    identity.uniqueNo.Visible = True
                    identity.uniqueNo.ReadOnly = True
                ElseIf uniqueNo = "PD330200" Then
                    identity.uniqueNo.ReadOnly = False
                    identity.uniqueNo.Visible = True
                End If

                If ref4 = "PD330300" Then
                    identity.ref4.Visible = False
                ElseIf ref4 = "PD330100" Then
                    identity.ref4.Visible = True
                    identity.ref4.ReadOnly = True
                ElseIf ref4 = "PD330200" Then
                    identity.ref4.ReadOnly = False
                    identity.ref4.Visible = True
                End If

                If ref5 = "PD330300" Then
                    identity.ref5.Visible = False
                ElseIf ref5 = "PD330100" Then
                    identity.ref5.Visible = True
                    identity.ref5.ReadOnly = True
                ElseIf ref5 = "PD330200" Then
                    identity.ref5.ReadOnly = False
                    identity.ref5.Visible = True
                End If

                If ref6 = "PD330300" Then
                    identity.ref6.Visible = False
                ElseIf ref6 = "PD330100" Then
                    identity.ref6.Visible = True
                    identity.ref6.ReadOnly = True
                ElseIf ref6 = "PD330200" Then
                    identity.ref6.ReadOnly = False
                    identity.ref6.Visible = True
                End If

                If ref7 = "PD330300" Then
                    identity.ref7.Visible = False
                ElseIf ref7 = "PD330100" Then
                    identity.ref7.Visible = True
                    identity.ref7.ReadOnly = True
                ElseIf ref7 = "PD330200" Then
                    identity.ref7.ReadOnly = False
                    identity.ref7.Visible = True
                End If

                If ref8 = "PD330300" Then
                    identity.ref8.Visible = False
                ElseIf ref8 = "PD330100" Then
                    identity.ref8.Visible = True
                    identity.ref8.ReadOnly = True
                ElseIf ref8 = "PD330200" Then
                    identity.ref8.ReadOnly = False
                    identity.ref8.Visible = True
                End If

            Case "PD310300"

                If vinNo = "PD330300" Then
                    quantity.vinNo.Visible = False
                ElseIf vinNo = "PD330100" Then
                    quantity.vinNo.Visible = True
                    quantity.vinNo.ReadOnly = True
                ElseIf vinNo = "PD330200" Then
                    quantity.vinNo.ReadOnly = False
                    quantity.vinNo.Visible = True
                End If

                If engineNo = "PD330300" Then
                    quantity.engineNo.Visible = False
                ElseIf engineNo = "PD330100" Then
                    quantity.engineNo.Visible = True
                    quantity.engineNo.ReadOnly = True
                ElseIf engineNo = "PD330200" Then
                    quantity.engineNo.ReadOnly = False
                    quantity.engineNo.Visible = True
                End If

                If missionNo = "PD330300" Then
                    quantity.missionNo.Visible = False
                ElseIf missionNo = "PD330100" Then
                    quantity.missionNo.Visible = True
                    quantity.missionNo.ReadOnly = True
                ElseIf missionNo = "PD330200" Then
                    quantity.missionNo.ReadOnly = False
                    quantity.missionNo.Visible = True
                End If

                If keyNo = "PD330300" Then
                    quantity.keyNo.Visible = False
                ElseIf keyNo = "PD330100" Then
                    quantity.keyNo.Visible = True
                    quantity.keyNo.ReadOnly = True
                ElseIf keyNo = "PD330200" Then
                    quantity.keyNo.ReadOnly = False
                    quantity.keyNo.Visible = True
                End If

                If cabinNo = "PD330300" Then
                    quantity.cabinNo.Visible = False
                ElseIf cabinNo = "PD330100" Then
                    quantity.cabinNo.Visible = True
                    quantity.cabinNo.ReadOnly = True
                ElseIf cabinNo = "PD330200" Then
                    quantity.cabinNo.ReadOnly = False
                    quantity.cabinNo.Visible = True
                End If

                If cargoNo = "PD330300" Then
                    quantity.cargoNo.Visible = False
                ElseIf cargoNo = "PD330100" Then
                    quantity.cargoNo.Visible = True
                    quantity.cargoNo.ReadOnly = True
                ElseIf cargoNo = "PD330200" Then
                    quantity.cargoNo.ReadOnly = False
                    quantity.cargoNo.Visible = True
                End If

                If rearaxleNo = "PD330300" Then
                    quantity.rearaxleNo.Visible = False
                ElseIf rearaxleNo = "PD330100" Then
                    quantity.rearaxleNo.Visible = True
                    quantity.rearaxleNo.ReadOnly = True
                ElseIf rearaxleNo = "PD330200" Then
                    quantity.rearaxleNo.ReadOnly = False
                    quantity.rearaxleNo.Visible = True
                End If

                If chkNo = "PD330300" Then
                    quantity.ChkNo.Visible = False
                ElseIf chkNo = "PD330100" Then
                    quantity.ChkNo.Visible = True
                    quantity.ChkNo.ReadOnly = True
                ElseIf chkNo = "PD330200" Then
                    quantity.ChkNo.ReadOnly = False
                    quantity.ChkNo.Visible = True
                End If

                If itmID = "PD330300" Then
                    quantity.itmId.Visible = False
                ElseIf itmID = "PD330100" Then
                    quantity.itmId.Visible = True
                    quantity.itmId.ReadOnly = True
                ElseIf itmID = "PD330200" Then
                    quantity.itmId.ReadOnly = False
                    quantity.itmId.Visible = True
                End If

                If itmQty = "PD330300" Then
                    quantity.itmQty.Visible = False
                ElseIf itmQty = "PD330100" Then
                    quantity.itmQty.Visible = True
                    quantity.itmQty.ReadOnly = True
                ElseIf itmQty = "PD330200" Then
                    quantity.itmQty.ReadOnly = False
                    quantity.itmQty.Visible = True
                End If

                If uniqueNo = "PD330300" Then
                    quantity.uniqueNo.Visible = False
                ElseIf uniqueNo = "PD330100" Then
                    quantity.uniqueNo.Visible = True
                    quantity.uniqueNo.ReadOnly = True
                ElseIf uniqueNo = "PD330200" Then
                    quantity.uniqueNo.ReadOnly = False
                    quantity.uniqueNo.Visible = True
                End If

                If ref4 = "PD330300" Then
                    quantity.ref4.Visible = False
                ElseIf ref4 = "PD330100" Then
                    quantity.ref4.Visible = True
                    quantity.ref4.ReadOnly = True
                ElseIf ref4 = "PD330200" Then
                    quantity.ref4.ReadOnly = False
                    quantity.ref4.Visible = True
                End If

                If ref5 = "PD330300" Then
                    quantity.ref5.Visible = False
                ElseIf ref5 = "PD330100" Then
                    quantity.ref5.Visible = True
                    quantity.ref5.ReadOnly = True
                ElseIf ref5 = "PD330200" Then
                    quantity.ref5.ReadOnly = False
                    quantity.ref5.Visible = True
                End If

                If ref6 = "PD330300" Then
                    quantity.ref6.Visible = False
                ElseIf ref6 = "PD330100" Then
                    quantity.ref6.Visible = True
                    quantity.ref6.ReadOnly = True
                ElseIf ref6 = "PD330200" Then
                    quantity.ref6.ReadOnly = False
                    quantity.ref6.Visible = True
                End If

                If ref7 = "PD330300" Then
                    quantity.ref7.Visible = False
                ElseIf ref7 = "PD330100" Then
                    quantity.ref7.Visible = True
                    quantity.ref7.ReadOnly = True
                ElseIf ref7 = "PD330200" Then
                    quantity.ref7.ReadOnly = False
                    quantity.ref7.Visible = True
                End If

                If ref8 = "PD330300" Then
                    quantity.ref8.Visible = False
                ElseIf ref8 = "PD330100" Then
                    quantity.ref8.Visible = True
                    quantity.ref8.ReadOnly = True
                ElseIf ref8 = "PD330200" Then
                    quantity.ref8.ReadOnly = False
                    quantity.ref8.Visible = True
                End If

                'Case "PD310400"
                '    If vinNo = "PD330300" Then
                '        Defective.vinNo.Visible = False
                '    ElseIf vinNo = "PD330100" Then
                '        Defective.vinNo.Visible = True
                '        Defective.vinNo.ReadOnly = True
                '    ElseIf vinNo = "PD330200" Then
                '        Defective.vinNo.ReadOnly = False
                '        Defective.vinNo.Visible = True
                '    End If

        End Select
    End Sub

    Public chkBlock As Boolean
    Private Sub g10_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g10.AfterMoveRow
        chkBlock = True

        Frame.exe_qty.Text = g10.Text("exe_qty")
        Frame.job_qty.Text = g10.Text("job_qty")

        Frame.vinNo.Text = g10.Text("vin_no")
        Frame.engineNo.Text = g10.Text("engine_no")
        Frame.missionNo.Text = g10.Text("mission_no")
        Frame.keyNo.Text = g10.Text("key_no")
        Frame.cabinNo.Text = g10.Text("cabin_no")
        Frame.cargoNo.Text = g10.Text("cargo_no")
        Frame.rearaxleNo.Text = g10.Text("rearaxle_no")
        Frame.itmId.Text = g10.Text("itm_id")
        Frame.ItmQty.Text = g10.Text("itm_qty")
        Frame.uniqueNo.Text = g10.Text("ref3")
        Frame.ref4.Text = g10.Text("ref4")
        Frame.ref5.Text = g10.Text("ref5")
        Frame.ref6.Text = g10.Text("ref6")
        Frame.ref7.Text = g10.Text("ref7")
        Frame.ref8.Text = g10.Text("ref8")
        Frame.ChkNo.Text = ""

        If g10.Text("btnStat") = "Ready" Then
            Frame.btnStart.Enabled = True
            Frame.btnEnd.Enabled = False
        ElseIf g10.Text("btnStat") = "inLine" Then
            Frame.btnStart.Enabled = False
            Frame.btnEnd.Enabled = True
        End If

        'PD350380	Body Start D
        'PD350385	Sub Engine D
        'PD350390	Engine Ship D
        'PD350420	Side Door D
        'PD350450	Body End D
        'PD350500	W/A End D
        'DKD Body Start
        'DKD Sub Engine
        'DKD Engine Ship
        'DKD Side Door
        'DKD Body End
        'DKD W / A


        'F1 A1 Frame Start
        If z_kioskCd.Text = "PD350260" And z_kioskCd.Text = "PD350260" Then
            Frame.rearaxleNo.Focus()
        End If
        'F1 A1 Engine Ship
        If z_kioskCd.Text = "PD350270" And z_kioskCd.Text = "PD350260" Then
            Frame.missionNo.Focus()
        End If
        'F1 A1 Cabin Ship
        If z_kioskCd.Text = "PD350280" And z_kioskCd.Text = "PD350260" Then
            Frame.keyNo.Focus()
        End If
        'F1 A1 Frame End
        If z_kioskCd.Text = "PD350290" And z_kioskCd.Text = "PD350260" Then

        End If
        'F1 A1 Cargo Ship
        If z_kioskCd.Text = "PD350300" And z_kioskCd.Text = "PD350260" Then
            Frame.cargoNo.Focus()
        End If
        'F1 W/A
        If z_kioskCd.Text = "PD350310" And z_kioskCd.Text = "PD350260" Then

        End If
        chkBlock = False
    End Sub

    Private Sub g20_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g20.AfterMoveRow

        identity.exe_qty.Text = g20.Text("exe_qty")
        identity.job_qty.Text = g20.Text("job_qty")

        identity.vinNo.Text = g20.Text("vin_no")
        identity.engineNo.Text = g20.Text("engine_no")
        identity.missionNo.Text = g20.Text("mission_no")
        identity.keyNo.Text = g20.Text("key_no")
        identity.cabinNo.Text = g20.Text("cabin_no")
        identity.cargoNo.Text = g20.Text("cargo_no")
        identity.rearaxleNo.Text = g20.Text("rearaxle_no")
        identity.itmId.Text = g20.Text("itm_id")
        identity.itmQty.Text = g20.Text("itm_qty")
        identity.uniqueNo.Text = g20.Text("unique_no")
        identity.ref4.Text = g20.Text("ref4")
        identity.ref5.Text = g20.Text("ref5")
        identity.ref6.Text = g20.Text("ref6")
        identity.ref7.Text = g20.Text("ref7")
        identity.ref8.Text = g20.Text("ref8")
        identity.chkNo.Text = ""

        If g20.Text("btnStat") = "Ready" Then
            identity.btnStart.Enabled = True
            identity.btnEnd.Enabled = False
        ElseIf g20.Text("btnStat") = "inLine" Then
            identity.btnStart.Enabled = False
            identity.btnEnd.Enabled = True
        End If

    End Sub

    Private Sub g30_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g30.AfterMoveRow
        quantity.vinNo.Text = g30.Text("vin_no")
        quantity.engineNo.Text = g30.Text("engine_no")
        quantity.missionNo.Text = g30.Text("mission_no")
        quantity.keyNo.Text = g30.Text("key_no")
        quantity.cabinNo.Text = g30.Text("cabin_no")
        quantity.cargoNo.Text = g30.Text("cargo_no")
        quantity.rearaxleNo.Text = g30.Text("rearaxle_no")
        quantity.itmId.Text = g30.Text("itm_id")
        quantity.ItmQty.Text = g30.Text("itm_qty")
        quantity.uniqueNo.Text = g30.Text("unique_no")
        quantity.ref4.Text = g30.Text("ref4")
        quantity.ref5.Text = g30.Text("ref5")
        quantity.ref6.Text = g30.Text("ref6")
        quantity.ref7.Text = g30.Text("ref7")
        quantity.ref8.Text = g30.Text("ref8")
        quantity.chkNo.Text = ""

        quantity.exe_qty.Text = g30.Text("exe_qty")
        quantity.job_qty.Text = g30.Text("job_qty")
        quantity.pw_qty.Text = g30.Text("pw_qty")
        quantity.itmcd.Text = g30.Text("itmcd")
        quantity.itmnm.Text = g30.Text("itmnm")

        quantity.qty.Text = ""

    End Sub

    Private Sub g40_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g40.AfterMoveRow
        defect.openGrid(g40.Text("unique_no", RowIndex))
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        openGrid()
    End Sub

    Private Sub openGrid()
        If g10.Visible = True Then
            Open("pdk050_g10")
            ' Open("pdk050_r10")
        ElseIf g20.Visible = True Then
            Open("pdk050_g20")
            'Open("pdk050_r20")
        ElseIf g30.Visible = True Then
            Open("pdk050_g30")
            ' Open("pdk050_r30")
        ElseIf g40.Visible = True Then
            Open("pdk050_g40")
            ' Open("pdk050_r40")
        End If
    End Sub

#End Region

#Region "Setting"
    Private Sub btnSetting_Click(sender As Object, e As EventArgs) Handles btnSetting.Click

        If Not (System.IO.Directory.Exists("C:\KIOSK")) Then
            My.Computer.FileSystem.CreateDirectory("C:\KIOSK")
        End If

        Dim objWriter As New System.IO.StreamWriter("C:\KIOSK\KIOSK.txt", False)
        objWriter.WriteLine(set_kiosk.Text)
        objWriter.Close()

    End Sub
#End Region

    Private Sub z_btnSearch_Click(sender As Object, e As EventArgs) Handles z_btnSearch.Click
        Me.Open("pdk050_z01")
    End Sub

    Private Sub XtraTabControl1_SelectedPageChanged(sender As Object, e As DevExpress.XtraTab.TabPageChangedEventArgs) Handles XtraTabControl1.SelectedPageChanged
        If z01.RowCount < 1 And XtraTabControl1.SelectedTabPageIndex = 1 Then
            MsgBox("Worker registration is not available.")
            XtraTabControl1.SelectedTabPageIndex = 0
            Exit Sub
        End If
        If s_lineCd.Text = "" And XtraTabControl1.SelectedTabPageIndex = 3 Then
            MsgBox("Choose a line first")
            XtraTabControl1.SelectedTabPageIndex = 1
            Exit Sub
        End If
        If XtraTabControl1.SelectedTabPageIndex = 3 Then
            If g10.Visible = True Then
                Open("pdk050_r10")
            ElseIf g20.Visible = True Then
                Open("pdk050_r20")
            ElseIf g30.Visible = True Then
                Open("pdk050_r30")
            ElseIf g40.Visible = True Then
                Open("pdk050_r40")
            End If
        End If
    End Sub

    Private Sub z_kioskNm_TextChanged() Handles z_kioskNm.TextChanged
        Me.Open("pdk050_z01")
    End Sub

    Private Sub z_kioskNm_TextChanged(sender As Object, oldValue As String) Handles z_kioskNm.TextChanged

    End Sub

    Private Sub btn_query_Click(sender As Object, e As EventArgs) Handles btn_query.Click
        If r10.Visible = True Then
            Open("pdk050_r10")
        ElseIf r20.Visible = True Then
            Open("pdk050_r20")
        ElseIf r30.Visible = True Then
            Open("pdk050_r30")
        ElseIf r40.Visible = True Then
            Open("pdk050_r40")
        End If
    End Sub

End Class

