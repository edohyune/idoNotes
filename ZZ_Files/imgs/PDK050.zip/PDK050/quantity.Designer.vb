﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class quantity
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDel = New Frame8.eButton()
        Me.itmnm = New Frame8.eMemo()
        Me.exe_qty = New Frame8.eText()
        Me.qty = New Frame8.eText()
        Me.itmcd = New Frame8.eText()
        Me.btnAll = New Frame8.eButton()
        Me.btn0 = New Frame8.eButton()
        Me.btn9 = New Frame8.eButton()
        Me.btn8 = New Frame8.eButton()
        Me.btn7 = New Frame8.eButton()
        Me.btn6 = New Frame8.eButton()
        Me.btn5 = New Frame8.eButton()
        Me.btn4 = New Frame8.eButton()
        Me.btn3 = New Frame8.eButton()
        Me.btn2 = New Frame8.eButton()
        Me.btn1 = New Frame8.eButton()
        Me.btnletOut = New Frame8.eButton()
        Me.btnExec = New Frame8.eButton()
        Me.job_qty = New Frame8.eText()
        Me.btnEnd = New Frame8.eButton()
        Me.btnStart = New Frame8.eButton()
        Me.itmId = New Frame8.eText()
        Me.itmQty = New Frame8.eText()
        Me.ref8 = New Frame8.eText()
        Me.ref7 = New Frame8.eText()
        Me.ref6 = New Frame8.eText()
        Me.ref5 = New Frame8.eText()
        Me.ref4 = New Frame8.eText()
        Me.uniqueNo = New Frame8.eText()
        Me.vinNo = New Frame8.eText()
        Me.engineNo = New Frame8.eText()
        Me.rearaxleNo = New Frame8.eText()
        Me.cargoNo = New Frame8.eText()
        Me.cabinNo = New Frame8.eText()
        Me.chkNo = New Frame8.eText()
        Me.keyNo = New Frame8.eText()
        Me.missionNo = New Frame8.eText()
        Me.EButton1 = New Frame8.eButton()
        Me.pw_qty = New Frame8.eText()
        Me.SuspendLayout()
        '
        'btnDel
        '
        Me.btnDel.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDel.Appearance.Options.UseFont = True
        Me.btnDel.Location = New System.Drawing.Point(185, 391)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(80, 65)
        Me.btnDel.TabIndex = 107
        Me.btnDel.Text = "Del"
        '
        'itmnm
        '
        Me.itmnm.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.itmnm.Location = New System.Drawing.Point(10, 38)
        Me.itmnm.Name = "itmnm"
        Me.itmnm.ReadOnly = True
        Me.itmnm.Size = New System.Drawing.Size(252, 36)
        Me.itmnm.TabIndex = 106
        Me.itmnm.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.itmnm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmnm.Title = "Issue"
        Me.itmnm.TitleAlign = Frame8.Alignment.Right
        Me.itmnm.TitleForeColor = System.Drawing.Color.Gray
        Me.itmnm.TitleWidth = 0
        '
        'exe_qty
        '
        Me.exe_qty.AutoHeight = False
        Me.exe_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exe_qty.Location = New System.Drawing.Point(99, 107)
        Me.exe_qty.Name = "exe_qty"
        Me.exe_qty.ReadOnly = True
        Me.exe_qty.Size = New System.Drawing.Size(70, 27)
        Me.exe_qty.TabIndex = 104
        Me.exe_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.exe_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.exe_qty.Title = "Qty"
        Me.exe_qty.TitleAlign = Frame8.Alignment.Right
        Me.exe_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.exe_qty.TitleWidth = 0
        '
        'qty
        '
        Me.qty.AutoHeight = False
        Me.qty.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.qty.Location = New System.Drawing.Point(102, 140)
        Me.qty.Name = "qty"
        Me.qty.Size = New System.Drawing.Size(160, 39)
        Me.qty.TabIndex = 103
        Me.qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.qty.Title = "Qty"
        Me.qty.TitleAlign = Frame8.Alignment.Right
        Me.qty.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.qty.TitleWidth = 70
        '
        'itmcd
        '
        Me.itmcd.AutoHeight = False
        Me.itmcd.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.itmcd.Location = New System.Drawing.Point(10, 2)
        Me.itmcd.Name = "itmcd"
        Me.itmcd.ReadOnly = True
        Me.itmcd.Size = New System.Drawing.Size(252, 33)
        Me.itmcd.TabIndex = 102
        Me.itmcd.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.itmcd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmcd.Title = "Frame"
        Me.itmcd.TitleAlign = Frame8.Alignment.Right
        Me.itmcd.TitleForeColor = System.Drawing.Color.Gray
        Me.itmcd.TitleWidth = 0
        '
        'btnAll
        '
        Me.btnAll.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAll.Appearance.Options.UseFont = True
        Me.btnAll.Location = New System.Drawing.Point(99, 391)
        Me.btnAll.Name = "btnAll"
        Me.btnAll.Size = New System.Drawing.Size(80, 65)
        Me.btnAll.TabIndex = 101
        Me.btnAll.Text = "All"
        '
        'btn0
        '
        Me.btn0.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.Appearance.Options.UseFont = True
        Me.btn0.Location = New System.Drawing.Point(13, 391)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(80, 65)
        Me.btn0.TabIndex = 100
        Me.btn0.Text = "0"
        '
        'btn9
        '
        Me.btn9.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.Appearance.Options.UseFont = True
        Me.btn9.Location = New System.Drawing.Point(185, 326)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(80, 59)
        Me.btn9.TabIndex = 99
        Me.btn9.Text = "9"
        '
        'btn8
        '
        Me.btn8.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.Appearance.Options.UseFont = True
        Me.btn8.Location = New System.Drawing.Point(99, 326)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(80, 59)
        Me.btn8.TabIndex = 98
        Me.btn8.Text = "8"
        '
        'btn7
        '
        Me.btn7.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.Appearance.Options.UseFont = True
        Me.btn7.Location = New System.Drawing.Point(13, 326)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(80, 59)
        Me.btn7.TabIndex = 97
        Me.btn7.Text = "7"
        '
        'btn6
        '
        Me.btn6.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.Appearance.Options.UseFont = True
        Me.btn6.Location = New System.Drawing.Point(185, 254)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(80, 66)
        Me.btn6.TabIndex = 96
        Me.btn6.Text = "6"
        '
        'btn5
        '
        Me.btn5.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.Appearance.Options.UseFont = True
        Me.btn5.Location = New System.Drawing.Point(99, 254)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(80, 66)
        Me.btn5.TabIndex = 95
        Me.btn5.Text = "5"
        '
        'btn4
        '
        Me.btn4.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.Appearance.Options.UseFont = True
        Me.btn4.Location = New System.Drawing.Point(13, 254)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(80, 66)
        Me.btn4.TabIndex = 94
        Me.btn4.Text = "4"
        '
        'btn3
        '
        Me.btn3.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Appearance.Options.UseFont = True
        Me.btn3.Location = New System.Drawing.Point(185, 185)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(80, 63)
        Me.btn3.TabIndex = 93
        Me.btn3.Text = "3"
        '
        'btn2
        '
        Me.btn2.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Appearance.Options.UseFont = True
        Me.btn2.Location = New System.Drawing.Point(99, 185)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(80, 63)
        Me.btn2.TabIndex = 92
        Me.btn2.Text = "2"
        '
        'btn1
        '
        Me.btn1.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Appearance.Options.UseFont = True
        Me.btn1.Location = New System.Drawing.Point(13, 185)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(80, 63)
        Me.btn1.TabIndex = 91
        Me.btn1.Text = "1"
        '
        'btnletOut
        '
        Me.btnletOut.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnletOut.Appearance.Options.UseFont = True
        Me.btnletOut.Location = New System.Drawing.Point(13, 548)
        Me.btnletOut.Name = "btnletOut"
        Me.btnletOut.Size = New System.Drawing.Size(252, 80)
        Me.btnletOut.TabIndex = 90
        Me.btnletOut.Text = "Let Out"
        '
        'btnExec
        '
        Me.btnExec.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExec.Appearance.Options.UseFont = True
        Me.btnExec.Location = New System.Drawing.Point(13, 462)
        Me.btnExec.Name = "btnExec"
        Me.btnExec.Size = New System.Drawing.Size(252, 80)
        Me.btnExec.TabIndex = 89
        Me.btnExec.Text = "Execution"
        '
        'job_qty
        '
        Me.job_qty.AutoHeight = False
        Me.job_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.job_qty.Location = New System.Drawing.Point(122, 107)
        Me.job_qty.Name = "job_qty"
        Me.job_qty.ReadOnly = True
        Me.job_qty.Size = New System.Drawing.Size(140, 27)
        Me.job_qty.TabIndex = 105
        Me.job_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.job_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.job_qty.Title = "/ "
        Me.job_qty.TitleAlign = Frame8.Alignment.Right
        Me.job_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.job_qty.TitleWidth = 70
        '
        'btnEnd
        '
        Me.btnEnd.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnd.Appearance.Options.UseFont = True
        Me.btnEnd.Location = New System.Drawing.Point(143, 462)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(122, 80)
        Me.btnEnd.TabIndex = 111
        Me.btnEnd.Text = "End"
        '
        'btnStart
        '
        Me.btnStart.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStart.Appearance.Options.UseFont = True
        Me.btnStart.Location = New System.Drawing.Point(13, 462)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(122, 80)
        Me.btnStart.TabIndex = 110
        Me.btnStart.Text = "Start"
        '
        'itmId
        '
        Me.itmId.AutoHeight = False
        Me.itmId.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.itmId.Location = New System.Drawing.Point(602, 13)
        Me.itmId.Name = "itmId"
        Me.itmId.Size = New System.Drawing.Size(254, 46)
        Me.itmId.TabIndex = 119
        Me.itmId.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmId.Title = "Ref1"
        Me.itmId.TitleAlign = Frame8.Alignment.Right
        Me.itmId.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmId.TitleWidth = 140
        '
        'itmQty
        '
        Me.itmQty.AutoHeight = False
        Me.itmQty.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.itmQty.Location = New System.Drawing.Point(602, 64)
        Me.itmQty.Name = "itmQty"
        Me.itmQty.Size = New System.Drawing.Size(254, 46)
        Me.itmQty.TabIndex = 118
        Me.itmQty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmQty.Title = "Ref2"
        Me.itmQty.TitleAlign = Frame8.Alignment.Right
        Me.itmQty.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmQty.TitleWidth = 140
        '
        'ref8
        '
        Me.ref8.AutoHeight = False
        Me.ref8.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref8.Location = New System.Drawing.Point(602, 371)
        Me.ref8.Name = "ref8"
        Me.ref8.Size = New System.Drawing.Size(254, 46)
        Me.ref8.TabIndex = 117
        Me.ref8.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref8.Title = "Ref8"
        Me.ref8.TitleAlign = Frame8.Alignment.Right
        Me.ref8.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref8.TitleWidth = 140
        '
        'ref7
        '
        Me.ref7.AutoHeight = False
        Me.ref7.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref7.Location = New System.Drawing.Point(602, 319)
        Me.ref7.Name = "ref7"
        Me.ref7.Size = New System.Drawing.Size(254, 46)
        Me.ref7.TabIndex = 116
        Me.ref7.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref7.Title = "Ref7"
        Me.ref7.TitleAlign = Frame8.Alignment.Right
        Me.ref7.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref7.TitleWidth = 140
        '
        'ref6
        '
        Me.ref6.AutoHeight = False
        Me.ref6.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref6.Location = New System.Drawing.Point(602, 268)
        Me.ref6.Name = "ref6"
        Me.ref6.Size = New System.Drawing.Size(254, 46)
        Me.ref6.TabIndex = 115
        Me.ref6.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref6.Title = "Ref6"
        Me.ref6.TitleAlign = Frame8.Alignment.Right
        Me.ref6.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref6.TitleWidth = 140
        '
        'ref5
        '
        Me.ref5.AutoHeight = False
        Me.ref5.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref5.Location = New System.Drawing.Point(602, 217)
        Me.ref5.Name = "ref5"
        Me.ref5.Size = New System.Drawing.Size(254, 46)
        Me.ref5.TabIndex = 114
        Me.ref5.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref5.Title = "Ref5"
        Me.ref5.TitleAlign = Frame8.Alignment.Right
        Me.ref5.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref5.TitleWidth = 140
        '
        'ref4
        '
        Me.ref4.AutoHeight = False
        Me.ref4.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref4.Location = New System.Drawing.Point(602, 166)
        Me.ref4.Name = "ref4"
        Me.ref4.Size = New System.Drawing.Size(254, 46)
        Me.ref4.TabIndex = 113
        Me.ref4.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref4.Title = "Ref4"
        Me.ref4.TitleAlign = Frame8.Alignment.Right
        Me.ref4.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref4.TitleWidth = 140
        '
        'uniqueNo
        '
        Me.uniqueNo.AutoHeight = False
        Me.uniqueNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.uniqueNo.Location = New System.Drawing.Point(602, 115)
        Me.uniqueNo.Name = "uniqueNo"
        Me.uniqueNo.Size = New System.Drawing.Size(254, 46)
        Me.uniqueNo.TabIndex = 112
        Me.uniqueNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.uniqueNo.Title = "Ref3"
        Me.uniqueNo.TitleAlign = Frame8.Alignment.Right
        Me.uniqueNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.uniqueNo.TitleWidth = 140
        '
        'vinNo
        '
        Me.vinNo.AutoHeight = False
        Me.vinNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.vinNo.Location = New System.Drawing.Point(434, 13)
        Me.vinNo.Name = "vinNo"
        Me.vinNo.Size = New System.Drawing.Size(233, 46)
        Me.vinNo.TabIndex = 127
        Me.vinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vinNo.Title = "Frame"
        Me.vinNo.TitleAlign = Frame8.Alignment.Right
        Me.vinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vinNo.TitleWidth = 140
        '
        'engineNo
        '
        Me.engineNo.AutoHeight = False
        Me.engineNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.engineNo.Location = New System.Drawing.Point(434, 64)
        Me.engineNo.Name = "engineNo"
        Me.engineNo.Size = New System.Drawing.Size(233, 46)
        Me.engineNo.TabIndex = 126
        Me.engineNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.engineNo.Title = "Engine"
        Me.engineNo.TitleAlign = Frame8.Alignment.Right
        Me.engineNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.engineNo.TitleWidth = 140
        '
        'rearaxleNo
        '
        Me.rearaxleNo.AutoHeight = False
        Me.rearaxleNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.rearaxleNo.Location = New System.Drawing.Point(434, 371)
        Me.rearaxleNo.Name = "rearaxleNo"
        Me.rearaxleNo.Size = New System.Drawing.Size(233, 46)
        Me.rearaxleNo.TabIndex = 125
        Me.rearaxleNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rearaxleNo.Title = "Rearaxle"
        Me.rearaxleNo.TitleAlign = Frame8.Alignment.Right
        Me.rearaxleNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rearaxleNo.TitleWidth = 140
        '
        'cargoNo
        '
        Me.cargoNo.AutoHeight = False
        Me.cargoNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.cargoNo.Location = New System.Drawing.Point(434, 319)
        Me.cargoNo.Name = "cargoNo"
        Me.cargoNo.Size = New System.Drawing.Size(233, 46)
        Me.cargoNo.TabIndex = 124
        Me.cargoNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cargoNo.Title = "Cargo"
        Me.cargoNo.TitleAlign = Frame8.Alignment.Right
        Me.cargoNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cargoNo.TitleWidth = 140
        '
        'cabinNo
        '
        Me.cabinNo.AutoHeight = False
        Me.cabinNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.cabinNo.Location = New System.Drawing.Point(434, 268)
        Me.cabinNo.Name = "cabinNo"
        Me.cabinNo.Size = New System.Drawing.Size(233, 46)
        Me.cabinNo.TabIndex = 123
        Me.cabinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cabinNo.Title = "Cabin"
        Me.cabinNo.TitleAlign = Frame8.Alignment.Right
        Me.cabinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cabinNo.TitleWidth = 140
        '
        'chkNo
        '
        Me.chkNo.AutoHeight = False
        Me.chkNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.chkNo.Location = New System.Drawing.Point(434, 217)
        Me.chkNo.Name = "chkNo"
        Me.chkNo.Size = New System.Drawing.Size(233, 46)
        Me.chkNo.TabIndex = 122
        Me.chkNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.chkNo.Title = "Airbag"
        Me.chkNo.TitleAlign = Frame8.Alignment.Right
        Me.chkNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.chkNo.TitleWidth = 140
        '
        'keyNo
        '
        Me.keyNo.AutoHeight = False
        Me.keyNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.keyNo.Location = New System.Drawing.Point(434, 166)
        Me.keyNo.Name = "keyNo"
        Me.keyNo.Size = New System.Drawing.Size(233, 46)
        Me.keyNo.TabIndex = 121
        Me.keyNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.keyNo.Title = "Key"
        Me.keyNo.TitleAlign = Frame8.Alignment.Right
        Me.keyNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.keyNo.TitleWidth = 140
        '
        'missionNo
        '
        Me.missionNo.AutoHeight = False
        Me.missionNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.missionNo.Location = New System.Drawing.Point(434, 115)
        Me.missionNo.Name = "missionNo"
        Me.missionNo.Size = New System.Drawing.Size(233, 46)
        Me.missionNo.TabIndex = 120
        Me.missionNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.missionNo.Title = "Mission"
        Me.missionNo.TitleAlign = Frame8.Alignment.Right
        Me.missionNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.missionNo.TitleWidth = 140
        '
        'EButton1
        '
        Me.EButton1.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EButton1.Appearance.Options.UseFont = True
        Me.EButton1.Location = New System.Drawing.Point(602, 434)
        Me.EButton1.Name = "EButton1"
        Me.EButton1.Size = New System.Drawing.Size(252, 80)
        Me.EButton1.TabIndex = 128
        Me.EButton1.Text = "Execution"
        '
        'pw_qty
        '
        Me.pw_qty.AutoHeight = False
        Me.pw_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pw_qty.Location = New System.Drawing.Point(42, 77)
        Me.pw_qty.Name = "pw_qty"
        Me.pw_qty.ReadOnly = True
        Me.pw_qty.Size = New System.Drawing.Size(220, 27)
        Me.pw_qty.TabIndex = 129
        Me.pw_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.pw_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pw_qty.Title = "Possible Job Qty"
        Me.pw_qty.TitleAlign = Frame8.Alignment.Right
        Me.pw_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.pw_qty.TitleWidth = 150
        '
        'quantity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 645)
        Me.Controls.Add(Me.pw_qty)
        Me.Controls.Add(Me.EButton1)
        Me.Controls.Add(Me.vinNo)
        Me.Controls.Add(Me.engineNo)
        Me.Controls.Add(Me.rearaxleNo)
        Me.Controls.Add(Me.cargoNo)
        Me.Controls.Add(Me.cabinNo)
        Me.Controls.Add(Me.chkNo)
        Me.Controls.Add(Me.keyNo)
        Me.Controls.Add(Me.missionNo)
        Me.Controls.Add(Me.itmId)
        Me.Controls.Add(Me.itmQty)
        Me.Controls.Add(Me.ref8)
        Me.Controls.Add(Me.ref7)
        Me.Controls.Add(Me.ref6)
        Me.Controls.Add(Me.ref5)
        Me.Controls.Add(Me.ref4)
        Me.Controls.Add(Me.uniqueNo)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.btnDel)
        Me.Controls.Add(Me.itmnm)
        Me.Controls.Add(Me.exe_qty)
        Me.Controls.Add(Me.qty)
        Me.Controls.Add(Me.itmcd)
        Me.Controls.Add(Me.btnAll)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btnletOut)
        Me.Controls.Add(Me.btnExec)
        Me.Controls.Add(Me.job_qty)
        Me.Name = "quantity"
        Me.Text = "quantity"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnDel As Frame8.eButton
    Friend WithEvents btnAll As Frame8.eButton
    Friend WithEvents btn0 As Frame8.eButton
    Friend WithEvents btn9 As Frame8.eButton
    Friend WithEvents btn8 As Frame8.eButton
    Friend WithEvents btn7 As Frame8.eButton
    Friend WithEvents btn6 As Frame8.eButton
    Friend WithEvents btn5 As Frame8.eButton
    Friend WithEvents btn4 As Frame8.eButton
    Friend WithEvents btn3 As Frame8.eButton
    Friend WithEvents btn2 As Frame8.eButton
    Friend WithEvents btn1 As Frame8.eButton
    Friend WithEvents btnletOut As Frame8.eButton
    Friend WithEvents btnExec As Frame8.eButton
    Friend WithEvents btnEnd As Frame8.eButton
    Friend WithEvents btnStart As Frame8.eButton
    Public WithEvents itmnm As Frame8.eMemo
    Public WithEvents itmcd As Frame8.eText
    Friend WithEvents exe_qty As Frame8.eText
    Friend WithEvents qty As Frame8.eText
    Friend WithEvents job_qty As Frame8.eText
    Public WithEvents itmId As Frame8.eText
    Public WithEvents itmQty As Frame8.eText
    Public WithEvents ref8 As Frame8.eText
    Public WithEvents ref7 As Frame8.eText
    Public WithEvents ref6 As Frame8.eText
    Public WithEvents ref5 As Frame8.eText
    Public WithEvents ref4 As Frame8.eText
    Public WithEvents uniqueNo As Frame8.eText
    Friend WithEvents vinNo As Frame8.eText
    Friend WithEvents engineNo As Frame8.eText
    Friend WithEvents rearaxleNo As Frame8.eText
    Friend WithEvents cargoNo As Frame8.eText
    Friend WithEvents cabinNo As Frame8.eText
    Friend WithEvents chkNo As Frame8.eText
    Friend WithEvents keyNo As Frame8.eText
    Friend WithEvents missionNo As Frame8.eText
    Friend WithEvents EButton1 As Frame8.eButton
    Friend WithEvents pw_qty As Frame8.eText
End Class
