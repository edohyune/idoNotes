﻿Imports Frame8
Imports Base8
Imports Base8.Shared
Imports System.Data

Public Class identity

    Private papa As Object
    Public Sub Set_Param(parentForm As Object)
        papa = parentForm
    End Sub
    Private Sub btnletOut_Click(sender As Object, e As EventArgs) Handles btnletOut.Click
        MsgBox("Not yet Using. Let Out" + vbNewLine + "if you want to using Call BMD")
        Exit Sub
    End Sub

    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        Dim answer As Integer
        answer = MsgBox("Would you like to 'END' this Cargo/Cabin Number?" + vbNewLine + vbNewLine + papa.g20.Text("unique_no"), vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g20.Text("job_no"))
        p.Add("@job_order", papa.g20.Text("job_ord"))
        p.Add("@set_line", papa.g20.Text("set_line"))
        p.Add("@line_cd", papa.g20.Text("line_cd"))
        p.Add("@line_sq", papa.g20.Text("line_sq"))

        p.Add("@cabin_no", papa.g20.Text("unique_no"))
        p.Add("@unique_no", papa.g20.Text("unique_no"))

        p.Add("@qty", 1)

        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnIdentityEnd", p)

        papa.open("pdk050_g20")
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Dim answer As Integer
        answer = MsgBox("Would you like to 'START' this Cargo/Cabin Number?" + vbNewLine + vbNewLine + papa.g20.Text("unique_no"), vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g20.Text("job_no"))
        p.Add("@job_order", papa.g20.Text("job_ord"))
        p.Add("@set_line", papa.g20.Text("set_line"))
        p.Add("@line_cd", papa.g20.Text("line_cd"))
        p.Add("@line_sq", papa.g20.Text("line_sq"))

        p.Add("@cabin_no", papa.g20.Text("unique_no"))
        p.Add("@unique_no", papa.g20.Text("unique_no"))

        p.Add("@qty", 0)

        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnIdentityStart", p)

        papa.open("pdk050_g20")
    End Sub

    Private Sub btnExec_Click(sender As Object, e As EventArgs) Handles btnExec.Click
        If (papa.g20.Text("set_line") = "SET0014" And papa.g20.Text("line_cd") = "CG_Cargo Out" And papa.z_kioskCd.Text = "PD350165") Then
            If uniqueNo.Text <> chkNo.Text Then
                MsgBox("Check Carg No or Cabin No")
                Exit Sub
            End If
        End If
        Dim answer As Integer
        answer = MsgBox("Would you like to 'EXCUTION' this Cargo/Cabin Number?" + vbNewLine + vbNewLine + papa.g20.Text("unique_no"), vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g20.Text("job_no"))
        p.Add("@job_order", papa.g20.Text("job_ord"))
        p.Add("@set_line", papa.g20.Text("set_line"))
        p.Add("@line_cd", papa.g20.Text("line_cd"))
        p.Add("@line_sq", papa.g20.Text("line_sq"))

        p.Add("@cabin_no", papa.g20.Text("unique_no"))
        p.Add("@unique_no", papa.g20.Text("unique_no"))

        p.Add("@qty", 1)

        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnIdentityExec", p)

        papa.open("pdk050_g20")

    End Sub

    Private Sub btnNotgood_Click(sender As Object, e As EventArgs) Handles btnNotgood.Click

    End Sub

    Private Sub btnGood_Click(sender As Object, e As EventArgs) Handles btnGood.Click

    End Sub
End Class