﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frame
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.vinNo = New Frame8.eText()
        Me.engineNo = New Frame8.eText()
        Me.btnletOut = New Frame8.eButton()
        Me.btnExec = New Frame8.eButton()
        Me.rearaxleNo = New Frame8.eText()
        Me.cargoNo = New Frame8.eText()
        Me.cabinNo = New Frame8.eText()
        Me.ChkNo = New Frame8.eText()
        Me.keyNo = New Frame8.eText()
        Me.missionNo = New Frame8.eText()
        Me.btnStart = New Frame8.eButton()
        Me.btnEnd = New Frame8.eButton()
        Me.itmId = New Frame8.eText()
        Me.ItmQty = New Frame8.eText()
        Me.ref8 = New Frame8.eText()
        Me.ref7 = New Frame8.eText()
        Me.ref6 = New Frame8.eText()
        Me.ref5 = New Frame8.eText()
        Me.ref4 = New Frame8.eText()
        Me.uniqueNo = New Frame8.eText()
        Me.qty = New Frame8.eText()
        Me.exe_qty = New Frame8.eText()
        Me.job_qty = New Frame8.eText()
        Me.btnNotgood = New Frame8.eButton()
        Me.btnGood = New Frame8.eButton()
        Me.SuspendLayout()
        '
        'vinNo
        '
        Me.vinNo.AutoHeight = False
        Me.vinNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.vinNo.Location = New System.Drawing.Point(10, 10)
        Me.vinNo.Name = "vinNo"
        Me.vinNo.Size = New System.Drawing.Size(499, 46)
        Me.vinNo.TabIndex = 56
        Me.vinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vinNo.Title = "Frame"
        Me.vinNo.TitleAlign = Frame8.Alignment.Right
        Me.vinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vinNo.TitleWidth = 140
        '
        'engineNo
        '
        Me.engineNo.AutoHeight = False
        Me.engineNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.engineNo.Location = New System.Drawing.Point(10, 61)
        Me.engineNo.Name = "engineNo"
        Me.engineNo.Size = New System.Drawing.Size(499, 46)
        Me.engineNo.TabIndex = 55
        Me.engineNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.engineNo.Title = "Engine"
        Me.engineNo.TitleAlign = Frame8.Alignment.Right
        Me.engineNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.engineNo.TitleWidth = 140
        '
        'btnletOut
        '
        Me.btnletOut.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnletOut.Appearance.Options.UseFont = True
        Me.btnletOut.Location = New System.Drawing.Point(12, 555)
        Me.btnletOut.Name = "btnletOut"
        Me.btnletOut.Size = New System.Drawing.Size(499, 93)
        Me.btnletOut.TabIndex = 54
        Me.btnletOut.Text = "Let Out"
        '
        'btnExec
        '
        Me.btnExec.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExec.Appearance.Options.UseFont = True
        Me.btnExec.Location = New System.Drawing.Point(10, 445)
        Me.btnExec.Name = "btnExec"
        Me.btnExec.Size = New System.Drawing.Size(499, 93)
        Me.btnExec.TabIndex = 53
        Me.btnExec.Text = "Execution"
        '
        'rearaxleNo
        '
        Me.rearaxleNo.AutoHeight = False
        Me.rearaxleNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.rearaxleNo.Location = New System.Drawing.Point(10, 316)
        Me.rearaxleNo.Name = "rearaxleNo"
        Me.rearaxleNo.Size = New System.Drawing.Size(499, 46)
        Me.rearaxleNo.TabIndex = 52
        Me.rearaxleNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rearaxleNo.Title = "Rearaxle"
        Me.rearaxleNo.TitleAlign = Frame8.Alignment.Right
        Me.rearaxleNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rearaxleNo.TitleWidth = 140
        '
        'cargoNo
        '
        Me.cargoNo.AutoHeight = False
        Me.cargoNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.cargoNo.Location = New System.Drawing.Point(10, 265)
        Me.cargoNo.Name = "cargoNo"
        Me.cargoNo.Size = New System.Drawing.Size(499, 46)
        Me.cargoNo.TabIndex = 51
        Me.cargoNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cargoNo.Title = "Cargo"
        Me.cargoNo.TitleAlign = Frame8.Alignment.Right
        Me.cargoNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cargoNo.TitleWidth = 140
        '
        'cabinNo
        '
        Me.cabinNo.AutoHeight = False
        Me.cabinNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.cabinNo.Location = New System.Drawing.Point(10, 215)
        Me.cabinNo.Name = "cabinNo"
        Me.cabinNo.Size = New System.Drawing.Size(499, 46)
        Me.cabinNo.TabIndex = 50
        Me.cabinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cabinNo.Title = "Cabin"
        Me.cabinNo.TitleAlign = Frame8.Alignment.Right
        Me.cabinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cabinNo.TitleWidth = 140
        '
        'ChkNo
        '
        Me.ChkNo.AutoHeight = False
        Me.ChkNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ChkNo.Location = New System.Drawing.Point(10, 367)
        Me.ChkNo.Name = "ChkNo"
        Me.ChkNo.Size = New System.Drawing.Size(499, 46)
        Me.ChkNo.TabIndex = 49
        Me.ChkNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ChkNo.Title = "Check No"
        Me.ChkNo.TitleAlign = Frame8.Alignment.Right
        Me.ChkNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ChkNo.TitleWidth = 140
        '
        'keyNo
        '
        Me.keyNo.AutoHeight = False
        Me.keyNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.keyNo.Location = New System.Drawing.Point(10, 163)
        Me.keyNo.Name = "keyNo"
        Me.keyNo.Size = New System.Drawing.Size(499, 46)
        Me.keyNo.TabIndex = 48
        Me.keyNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.keyNo.Title = "Key"
        Me.keyNo.TitleAlign = Frame8.Alignment.Right
        Me.keyNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.keyNo.TitleWidth = 140
        '
        'missionNo
        '
        Me.missionNo.AutoHeight = False
        Me.missionNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.missionNo.Location = New System.Drawing.Point(10, 112)
        Me.missionNo.Name = "missionNo"
        Me.missionNo.Size = New System.Drawing.Size(499, 46)
        Me.missionNo.TabIndex = 47
        Me.missionNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.missionNo.Title = "Mission"
        Me.missionNo.TitleAlign = Frame8.Alignment.Right
        Me.missionNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.missionNo.TitleWidth = 140
        '
        'btnStart
        '
        Me.btnStart.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStart.Appearance.Options.UseFont = True
        Me.btnStart.Location = New System.Drawing.Point(10, 445)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(240, 93)
        Me.btnStart.TabIndex = 57
        Me.btnStart.Text = "Start"
        '
        'btnEnd
        '
        Me.btnEnd.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnd.Appearance.Options.UseFont = True
        Me.btnEnd.Location = New System.Drawing.Point(269, 445)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(240, 93)
        Me.btnEnd.TabIndex = 58
        Me.btnEnd.Text = "End"
        '
        'itmId
        '
        Me.itmId.AutoHeight = False
        Me.itmId.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.itmId.Location = New System.Drawing.Point(751, 13)
        Me.itmId.Name = "itmId"
        Me.itmId.Size = New System.Drawing.Size(254, 46)
        Me.itmId.TabIndex = 66
        Me.itmId.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmId.Title = "itmId"
        Me.itmId.TitleAlign = Frame8.Alignment.Right
        Me.itmId.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmId.TitleWidth = 140
        '
        'ItmQty
        '
        Me.ItmQty.AutoHeight = False
        Me.ItmQty.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ItmQty.Location = New System.Drawing.Point(751, 64)
        Me.ItmQty.Name = "ItmQty"
        Me.ItmQty.Size = New System.Drawing.Size(254, 46)
        Me.ItmQty.TabIndex = 65
        Me.ItmQty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ItmQty.Title = "ItmQty"
        Me.ItmQty.TitleAlign = Frame8.Alignment.Right
        Me.ItmQty.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ItmQty.TitleWidth = 140
        '
        'ref8
        '
        Me.ref8.AutoHeight = False
        Me.ref8.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref8.Location = New System.Drawing.Point(751, 371)
        Me.ref8.Name = "ref8"
        Me.ref8.Size = New System.Drawing.Size(254, 46)
        Me.ref8.TabIndex = 64
        Me.ref8.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref8.Title = "Ref8"
        Me.ref8.TitleAlign = Frame8.Alignment.Right
        Me.ref8.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref8.TitleWidth = 140
        '
        'ref7
        '
        Me.ref7.AutoHeight = False
        Me.ref7.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref7.Location = New System.Drawing.Point(751, 319)
        Me.ref7.Name = "ref7"
        Me.ref7.Size = New System.Drawing.Size(254, 46)
        Me.ref7.TabIndex = 63
        Me.ref7.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref7.Title = "Ref7"
        Me.ref7.TitleAlign = Frame8.Alignment.Right
        Me.ref7.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref7.TitleWidth = 140
        '
        'ref6
        '
        Me.ref6.AutoHeight = False
        Me.ref6.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref6.Location = New System.Drawing.Point(751, 269)
        Me.ref6.Name = "ref6"
        Me.ref6.Size = New System.Drawing.Size(254, 46)
        Me.ref6.TabIndex = 62
        Me.ref6.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref6.Title = "Ref6"
        Me.ref6.TitleAlign = Frame8.Alignment.Right
        Me.ref6.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref6.TitleWidth = 140
        '
        'ref5
        '
        Me.ref5.AutoHeight = False
        Me.ref5.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref5.Location = New System.Drawing.Point(751, 217)
        Me.ref5.Name = "ref5"
        Me.ref5.Size = New System.Drawing.Size(254, 46)
        Me.ref5.TabIndex = 61
        Me.ref5.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref5.Title = "Ref5"
        Me.ref5.TitleAlign = Frame8.Alignment.Right
        Me.ref5.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref5.TitleWidth = 140
        '
        'ref4
        '
        Me.ref4.AutoHeight = False
        Me.ref4.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref4.Location = New System.Drawing.Point(751, 166)
        Me.ref4.Name = "ref4"
        Me.ref4.Size = New System.Drawing.Size(254, 46)
        Me.ref4.TabIndex = 60
        Me.ref4.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref4.Title = "Ref4"
        Me.ref4.TitleAlign = Frame8.Alignment.Right
        Me.ref4.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref4.TitleWidth = 140
        '
        'uniqueNo
        '
        Me.uniqueNo.AutoHeight = False
        Me.uniqueNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.uniqueNo.Location = New System.Drawing.Point(751, 115)
        Me.uniqueNo.Name = "uniqueNo"
        Me.uniqueNo.Size = New System.Drawing.Size(254, 46)
        Me.uniqueNo.TabIndex = 59
        Me.uniqueNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.uniqueNo.Title = "uniqueNo"
        Me.uniqueNo.TitleAlign = Frame8.Alignment.Right
        Me.uniqueNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.uniqueNo.TitleWidth = 140
        '
        'qty
        '
        Me.qty.AutoHeight = False
        Me.qty.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.qty.Location = New System.Drawing.Point(822, 421)
        Me.qty.Name = "qty"
        Me.qty.Size = New System.Drawing.Size(160, 46)
        Me.qty.TabIndex = 104
        Me.qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.qty.Title = "Qty"
        Me.qty.TitleAlign = Frame8.Alignment.Right
        Me.qty.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.qty.TitleWidth = 70
        '
        'exe_qty
        '
        Me.exe_qty.AutoHeight = False
        Me.exe_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exe_qty.Location = New System.Drawing.Point(841, 472)
        Me.exe_qty.Name = "exe_qty"
        Me.exe_qty.ReadOnly = True
        Me.exe_qty.Size = New System.Drawing.Size(70, 27)
        Me.exe_qty.TabIndex = 106
        Me.exe_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.exe_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.exe_qty.Title = "Qty"
        Me.exe_qty.TitleAlign = Frame8.Alignment.Right
        Me.exe_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.exe_qty.TitleWidth = 0
        '
        'job_qty
        '
        Me.job_qty.AutoHeight = False
        Me.job_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.job_qty.Location = New System.Drawing.Point(865, 472)
        Me.job_qty.Name = "job_qty"
        Me.job_qty.ReadOnly = True
        Me.job_qty.Size = New System.Drawing.Size(140, 27)
        Me.job_qty.TabIndex = 107
        Me.job_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.job_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.job_qty.Title = "/ "
        Me.job_qty.TitleAlign = Frame8.Alignment.Right
        Me.job_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.job_qty.TitleWidth = 70
        '
        'btnNotgood
        '
        Me.btnNotgood.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNotgood.Appearance.Options.UseFont = True
        Me.btnNotgood.Location = New System.Drawing.Point(271, 445)
        Me.btnNotgood.Name = "btnNotgood"
        Me.btnNotgood.Size = New System.Drawing.Size(240, 93)
        Me.btnNotgood.TabIndex = 136
        Me.btnNotgood.Text = "Not Good"
        '
        'btnGood
        '
        Me.btnGood.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGood.Appearance.Options.UseFont = True
        Me.btnGood.Location = New System.Drawing.Point(10, 445)
        Me.btnGood.Name = "btnGood"
        Me.btnGood.Size = New System.Drawing.Size(240, 93)
        Me.btnGood.TabIndex = 135
        Me.btnGood.Text = "Good"
        '
        'Frame
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 676)
        Me.Controls.Add(Me.btnNotgood)
        Me.Controls.Add(Me.btnGood)
        Me.Controls.Add(Me.exe_qty)
        Me.Controls.Add(Me.job_qty)
        Me.Controls.Add(Me.qty)
        Me.Controls.Add(Me.itmId)
        Me.Controls.Add(Me.ItmQty)
        Me.Controls.Add(Me.ref8)
        Me.Controls.Add(Me.ref7)
        Me.Controls.Add(Me.ref6)
        Me.Controls.Add(Me.ref5)
        Me.Controls.Add(Me.ref4)
        Me.Controls.Add(Me.uniqueNo)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.vinNo)
        Me.Controls.Add(Me.engineNo)
        Me.Controls.Add(Me.btnletOut)
        Me.Controls.Add(Me.btnExec)
        Me.Controls.Add(Me.rearaxleNo)
        Me.Controls.Add(Me.cargoNo)
        Me.Controls.Add(Me.cabinNo)
        Me.Controls.Add(Me.ChkNo)
        Me.Controls.Add(Me.keyNo)
        Me.Controls.Add(Me.missionNo)
        Me.Name = "Frame"
        Me.Text = "Frame"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents vinNo As Frame8.eText
    Friend WithEvents engineNo As Frame8.eText
    Friend WithEvents btnletOut As Frame8.eButton
    Friend WithEvents btnExec As Frame8.eButton
    Friend WithEvents rearaxleNo As Frame8.eText
    Friend WithEvents cargoNo As Frame8.eText
    Friend WithEvents cabinNo As Frame8.eText
    Friend WithEvents ChkNo As Frame8.eText
    Friend WithEvents keyNo As Frame8.eText
    Friend WithEvents missionNo As Frame8.eText
    Friend WithEvents btnStart As Frame8.eButton
    Friend WithEvents btnEnd As Frame8.eButton
    Public WithEvents itmId As Frame8.eText
    Public WithEvents ItmQty As Frame8.eText
    Public WithEvents ref8 As Frame8.eText
    Public WithEvents ref7 As Frame8.eText
    Public WithEvents ref6 As Frame8.eText
    Public WithEvents ref5 As Frame8.eText
    Public WithEvents ref4 As Frame8.eText
    Public WithEvents uniqueNo As Frame8.eText
    Friend WithEvents qty As Frame8.eText
    Friend WithEvents exe_qty As Frame8.eText
    Friend WithEvents job_qty As Frame8.eText
    Friend WithEvents btnNotgood As Frame8.eButton
    Friend WithEvents btnGood As Frame8.eButton
End Class
