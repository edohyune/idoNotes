﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class identity
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.itmId = New Frame8.eText()
        Me.itmQty = New Frame8.eText()
        Me.btnletOut = New Frame8.eButton()
        Me.btnExec = New Frame8.eButton()
        Me.ref8 = New Frame8.eText()
        Me.ref7 = New Frame8.eText()
        Me.ref6 = New Frame8.eText()
        Me.ref5 = New Frame8.eText()
        Me.ref4 = New Frame8.eText()
        Me.uniqueNo = New Frame8.eText()
        Me.btnEnd = New Frame8.eButton()
        Me.btnStart = New Frame8.eButton()
        Me.vinNo = New Frame8.eText()
        Me.engineNo = New Frame8.eText()
        Me.rearaxleNo = New Frame8.eText()
        Me.cargoNo = New Frame8.eText()
        Me.cabinNo = New Frame8.eText()
        Me.chkNo = New Frame8.eText()
        Me.keyNo = New Frame8.eText()
        Me.missionNo = New Frame8.eText()
        Me.qty = New Frame8.eText()
        Me.exe_qty = New Frame8.eText()
        Me.job_qty = New Frame8.eText()
        Me.btnNotgood = New Frame8.eButton()
        Me.btnGood = New Frame8.eButton()
        Me.SuspendLayout()
        '
        'itmId
        '
        Me.itmId.AutoHeight = False
        Me.itmId.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.itmId.Location = New System.Drawing.Point(868, -7)
        Me.itmId.Name = "itmId"
        Me.itmId.Size = New System.Drawing.Size(499, 45)
        Me.itmId.TabIndex = 46
        Me.itmId.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmId.Title = "Parts ID"
        Me.itmId.TitleAlign = Frame8.Alignment.Right
        Me.itmId.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmId.TitleWidth = 140
        '
        'itmQty
        '
        Me.itmQty.AutoHeight = False
        Me.itmQty.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.itmQty.Location = New System.Drawing.Point(868, 44)
        Me.itmQty.Name = "itmQty"
        Me.itmQty.Size = New System.Drawing.Size(499, 45)
        Me.itmQty.TabIndex = 45
        Me.itmQty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmQty.Title = "Parts Qty"
        Me.itmQty.TitleAlign = Frame8.Alignment.Right
        Me.itmQty.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.itmQty.TitleWidth = 140
        '
        'btnletOut
        '
        Me.btnletOut.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnletOut.Appearance.Options.UseFont = True
        Me.btnletOut.Location = New System.Drawing.Point(10, 555)
        Me.btnletOut.Name = "btnletOut"
        Me.btnletOut.Size = New System.Drawing.Size(499, 93)
        Me.btnletOut.TabIndex = 44
        Me.btnletOut.Text = "Let Out"
        '
        'btnExec
        '
        Me.btnExec.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExec.Appearance.Options.UseFont = True
        Me.btnExec.Location = New System.Drawing.Point(10, 445)
        Me.btnExec.Name = "btnExec"
        Me.btnExec.Size = New System.Drawing.Size(499, 93)
        Me.btnExec.TabIndex = 43
        Me.btnExec.Text = "Execution"
        '
        'ref8
        '
        Me.ref8.AutoHeight = False
        Me.ref8.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref8.Location = New System.Drawing.Point(822, 294)
        Me.ref8.Name = "ref8"
        Me.ref8.Size = New System.Drawing.Size(499, 45)
        Me.ref8.TabIndex = 42
        Me.ref8.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref8.Title = "Ref8"
        Me.ref8.TitleAlign = Frame8.Alignment.Right
        Me.ref8.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref8.TitleWidth = 140
        '
        'ref7
        '
        Me.ref7.AutoHeight = False
        Me.ref7.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref7.Location = New System.Drawing.Point(12, 367)
        Me.ref7.Name = "ref7"
        Me.ref7.Size = New System.Drawing.Size(499, 45)
        Me.ref7.TabIndex = 41
        Me.ref7.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref7.Title = "Ref7"
        Me.ref7.TitleAlign = Frame8.Alignment.Right
        Me.ref7.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref7.TitleWidth = 150
        '
        'ref6
        '
        Me.ref6.AutoHeight = False
        Me.ref6.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref6.Location = New System.Drawing.Point(12, 316)
        Me.ref6.Name = "ref6"
        Me.ref6.Size = New System.Drawing.Size(499, 45)
        Me.ref6.TabIndex = 40
        Me.ref6.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref6.Title = "Ref6"
        Me.ref6.TitleAlign = Frame8.Alignment.Right
        Me.ref6.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref6.TitleWidth = 150
        '
        'ref5
        '
        Me.ref5.AutoHeight = False
        Me.ref5.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref5.Location = New System.Drawing.Point(12, 265)
        Me.ref5.Name = "ref5"
        Me.ref5.Size = New System.Drawing.Size(499, 45)
        Me.ref5.TabIndex = 39
        Me.ref5.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref5.Title = "Ref5"
        Me.ref5.TitleAlign = Frame8.Alignment.Right
        Me.ref5.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref5.TitleWidth = 150
        '
        'ref4
        '
        Me.ref4.AutoHeight = False
        Me.ref4.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ref4.Location = New System.Drawing.Point(12, 214)
        Me.ref4.Name = "ref4"
        Me.ref4.Size = New System.Drawing.Size(499, 45)
        Me.ref4.TabIndex = 38
        Me.ref4.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref4.Title = "Ref4"
        Me.ref4.TitleAlign = Frame8.Alignment.Right
        Me.ref4.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ref4.TitleWidth = 150
        '
        'uniqueNo
        '
        Me.uniqueNo.AutoHeight = False
        Me.uniqueNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.uniqueNo.Location = New System.Drawing.Point(10, 112)
        Me.uniqueNo.Name = "uniqueNo"
        Me.uniqueNo.Size = New System.Drawing.Size(499, 45)
        Me.uniqueNo.TabIndex = 37
        Me.uniqueNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.uniqueNo.Title = "Identity#"
        Me.uniqueNo.TitleAlign = Frame8.Alignment.Right
        Me.uniqueNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.uniqueNo.TitleWidth = 150
        '
        'btnEnd
        '
        Me.btnEnd.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnd.Appearance.Options.UseFont = True
        Me.btnEnd.Location = New System.Drawing.Point(269, 445)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(240, 93)
        Me.btnEnd.TabIndex = 60
        Me.btnEnd.Text = "End"
        '
        'btnStart
        '
        Me.btnStart.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStart.Appearance.Options.UseFont = True
        Me.btnStart.Location = New System.Drawing.Point(10, 445)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(240, 93)
        Me.btnStart.TabIndex = 59
        Me.btnStart.Text = "Start"
        '
        'vinNo
        '
        Me.vinNo.AutoHeight = False
        Me.vinNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.vinNo.Location = New System.Drawing.Point(10, 61)
        Me.vinNo.Name = "vinNo"
        Me.vinNo.Size = New System.Drawing.Size(499, 45)
        Me.vinNo.TabIndex = 68
        Me.vinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vinNo.Title = "Frame"
        Me.vinNo.TitleAlign = Frame8.Alignment.Right
        Me.vinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vinNo.TitleWidth = 150
        '
        'engineNo
        '
        Me.engineNo.AutoHeight = False
        Me.engineNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.engineNo.Location = New System.Drawing.Point(914, 63)
        Me.engineNo.Name = "engineNo"
        Me.engineNo.Size = New System.Drawing.Size(274, 45)
        Me.engineNo.TabIndex = 67
        Me.engineNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.engineNo.Title = "Engine"
        Me.engineNo.TitleAlign = Frame8.Alignment.Right
        Me.engineNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.engineNo.TitleWidth = 140
        '
        'rearaxleNo
        '
        Me.rearaxleNo.AutoHeight = False
        Me.rearaxleNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.rearaxleNo.Location = New System.Drawing.Point(914, 369)
        Me.rearaxleNo.Name = "rearaxleNo"
        Me.rearaxleNo.Size = New System.Drawing.Size(274, 45)
        Me.rearaxleNo.TabIndex = 66
        Me.rearaxleNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rearaxleNo.Title = "Rearaxle"
        Me.rearaxleNo.TitleAlign = Frame8.Alignment.Right
        Me.rearaxleNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rearaxleNo.TitleWidth = 140
        '
        'cargoNo
        '
        Me.cargoNo.AutoHeight = False
        Me.cargoNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.cargoNo.Location = New System.Drawing.Point(914, 318)
        Me.cargoNo.Name = "cargoNo"
        Me.cargoNo.Size = New System.Drawing.Size(274, 45)
        Me.cargoNo.TabIndex = 65
        Me.cargoNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cargoNo.Title = "Cargo"
        Me.cargoNo.TitleAlign = Frame8.Alignment.Right
        Me.cargoNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cargoNo.TitleWidth = 140
        '
        'cabinNo
        '
        Me.cabinNo.AutoHeight = False
        Me.cabinNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.cabinNo.Location = New System.Drawing.Point(914, 267)
        Me.cabinNo.Name = "cabinNo"
        Me.cabinNo.Size = New System.Drawing.Size(274, 45)
        Me.cabinNo.TabIndex = 64
        Me.cabinNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cabinNo.Title = "Cabin"
        Me.cabinNo.TitleAlign = Frame8.Alignment.Right
        Me.cabinNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cabinNo.TitleWidth = 140
        '
        'chkNo
        '
        Me.chkNo.AutoHeight = False
        Me.chkNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.chkNo.Location = New System.Drawing.Point(12, 163)
        Me.chkNo.Name = "chkNo"
        Me.chkNo.Size = New System.Drawing.Size(497, 45)
        Me.chkNo.TabIndex = 63
        Me.chkNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.chkNo.Title = "Prepare No"
        Me.chkNo.TitleAlign = Frame8.Alignment.Right
        Me.chkNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.chkNo.TitleWidth = 150
        '
        'keyNo
        '
        Me.keyNo.AutoHeight = False
        Me.keyNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.keyNo.Location = New System.Drawing.Point(914, 165)
        Me.keyNo.Name = "keyNo"
        Me.keyNo.Size = New System.Drawing.Size(274, 45)
        Me.keyNo.TabIndex = 62
        Me.keyNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.keyNo.Title = "Key"
        Me.keyNo.TitleAlign = Frame8.Alignment.Right
        Me.keyNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.keyNo.TitleWidth = 140
        '
        'missionNo
        '
        Me.missionNo.AutoHeight = False
        Me.missionNo.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.missionNo.Location = New System.Drawing.Point(914, 114)
        Me.missionNo.Name = "missionNo"
        Me.missionNo.Size = New System.Drawing.Size(274, 45)
        Me.missionNo.TabIndex = 61
        Me.missionNo.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.missionNo.Title = "Mission"
        Me.missionNo.TitleAlign = Frame8.Alignment.Right
        Me.missionNo.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.missionNo.TitleWidth = 140
        '
        'qty
        '
        Me.qty.AutoHeight = False
        Me.qty.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold)
        Me.qty.Location = New System.Drawing.Point(988, 420)
        Me.qty.Name = "qty"
        Me.qty.Size = New System.Drawing.Size(160, 45)
        Me.qty.TabIndex = 105
        Me.qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.qty.Title = "Qty"
        Me.qty.TitleAlign = Frame8.Alignment.Right
        Me.qty.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.qty.TitleWidth = 70
        '
        'exe_qty
        '
        Me.exe_qty.AutoHeight = False
        Me.exe_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exe_qty.Location = New System.Drawing.Point(1024, 471)
        Me.exe_qty.Name = "exe_qty"
        Me.exe_qty.ReadOnly = True
        Me.exe_qty.Size = New System.Drawing.Size(70, 27)
        Me.exe_qty.TabIndex = 106
        Me.exe_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.exe_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.exe_qty.Title = "Qty"
        Me.exe_qty.TitleAlign = Frame8.Alignment.Right
        Me.exe_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.exe_qty.TitleWidth = 0
        '
        'job_qty
        '
        Me.job_qty.AutoHeight = False
        Me.job_qty.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.job_qty.Location = New System.Drawing.Point(1048, 471)
        Me.job_qty.Name = "job_qty"
        Me.job_qty.ReadOnly = True
        Me.job_qty.Size = New System.Drawing.Size(140, 27)
        Me.job_qty.TabIndex = 107
        Me.job_qty.TextBackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.job_qty.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.job_qty.Title = "/ "
        Me.job_qty.TitleAlign = Frame8.Alignment.Right
        Me.job_qty.TitleForeColor = System.Drawing.Color.Gray
        Me.job_qty.TitleWidth = 70
        '
        'btnNotgood
        '
        Me.btnNotgood.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNotgood.Appearance.Options.UseFont = True
        Me.btnNotgood.Location = New System.Drawing.Point(269, 445)
        Me.btnNotgood.Name = "btnNotgood"
        Me.btnNotgood.Size = New System.Drawing.Size(240, 93)
        Me.btnNotgood.TabIndex = 134
        Me.btnNotgood.Text = "Not Good"
        '
        'btnGood
        '
        Me.btnGood.Appearance.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGood.Appearance.Options.UseFont = True
        Me.btnGood.Location = New System.Drawing.Point(10, 445)
        Me.btnGood.Name = "btnGood"
        Me.btnGood.Size = New System.Drawing.Size(240, 93)
        Me.btnGood.TabIndex = 133
        Me.btnGood.Text = "Good"
        '
        'identity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 676)
        Me.Controls.Add(Me.btnNotgood)
        Me.Controls.Add(Me.btnGood)
        Me.Controls.Add(Me.exe_qty)
        Me.Controls.Add(Me.job_qty)
        Me.Controls.Add(Me.qty)
        Me.Controls.Add(Me.engineNo)
        Me.Controls.Add(Me.rearaxleNo)
        Me.Controls.Add(Me.cargoNo)
        Me.Controls.Add(Me.cabinNo)
        Me.Controls.Add(Me.chkNo)
        Me.Controls.Add(Me.keyNo)
        Me.Controls.Add(Me.missionNo)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.itmId)
        Me.Controls.Add(Me.itmQty)
        Me.Controls.Add(Me.btnletOut)
        Me.Controls.Add(Me.btnExec)
        Me.Controls.Add(Me.ref8)
        Me.Controls.Add(Me.ref7)
        Me.Controls.Add(Me.ref6)
        Me.Controls.Add(Me.ref5)
        Me.Controls.Add(Me.ref4)
        Me.Controls.Add(Me.uniqueNo)
        Me.Controls.Add(Me.vinNo)
        Me.Name = "identity"
        Me.Text = "identity"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnletOut As Frame8.eButton
    Friend WithEvents btnExec As Frame8.eButton
    Friend WithEvents btnEnd As Frame8.eButton
    Friend WithEvents btnStart As Frame8.eButton
    Public WithEvents itmId As Frame8.eText
    Public WithEvents itmQty As Frame8.eText
    Public WithEvents ref8 As Frame8.eText
    Public WithEvents ref7 As Frame8.eText
    Public WithEvents ref6 As Frame8.eText
    Public WithEvents ref5 As Frame8.eText
    Public WithEvents ref4 As Frame8.eText
    Public WithEvents uniqueNo As Frame8.eText
    Friend WithEvents vinNo As Frame8.eText
    Friend WithEvents engineNo As Frame8.eText
    Friend WithEvents rearaxleNo As Frame8.eText
    Friend WithEvents cargoNo As Frame8.eText
    Friend WithEvents cabinNo As Frame8.eText
    Friend WithEvents chkNo As Frame8.eText
    Friend WithEvents keyNo As Frame8.eText
    Friend WithEvents missionNo As Frame8.eText
    Friend WithEvents qty As Frame8.eText
    Friend WithEvents exe_qty As Frame8.eText
    Friend WithEvents job_qty As Frame8.eText
    Friend WithEvents btnNotgood As Frame8.eButton
    Friend WithEvents btnGood As Frame8.eButton
End Class
