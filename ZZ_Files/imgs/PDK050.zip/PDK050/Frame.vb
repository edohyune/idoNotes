﻿Imports Frame8
Imports Base8
Imports Base8.Shared
Imports System.Data

Public Class Frame

    Private papa As Object
    Friend Shared ref1 As Object
    Friend Shared ref2 As Object
    Friend Shared ref3 As Object

    Public Sub Set_Param(parentForm As Object)
        papa = parentForm
    End Sub

    Private Sub btnletOut_Click(sender As Object, e As EventArgs) Handles btnletOut.Click
        MsgBox("Not yet Using. Let Out" + vbNewLine + "if you want to using Call BMD")
        Exit Sub

        Dim p As OpenParameters = New OpenParameters
        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g10.Text("job_no"))
        p.Add("@set_line", papa.g10.Text("set_line"))
        p.Add("@line_cd", papa.g10.Text("line_cd"))
        p.Add("@line_sq", papa.g10.Text("line_sq"))

        p.Add("@qty", 0)

        p.Add("@unique_no", papa.g10.Text("unique_no"))
        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnFrameLetout", p)

        papa.open("pdk050_g10")
    End Sub

    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click

        If Not (checkEngineNo()) Then
            Exit Sub
        End If
        If Not (checkEditable()) Then
            Exit Sub
        End If

        Dim answer As Integer
        answer = MsgBox("Would you like to 'END' this Frame Number?" + vbNewLine + vbNewLine + vinNo.Text, vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g10.Text("job_no"))
        p.Add("@job_order", papa.g10.Text("job_ord"))
        p.Add("@set_line", papa.g10.Text("set_line"))
        p.Add("@line_cd", papa.g10.Text("line_cd"))
        p.Add("@line_sq", papa.g10.Text("line_sq"))

        p.Add("@vin_no", vinNo.Text)
        p.Add("@mission_no", missionNo.Text)
        p.Add("@key_no", keyNo.Text)
        p.Add("@cabin_no", cabinNo.Text)
        p.Add("@cargo_no", cargoNo.Text)
        p.Add("@rearaxle_no", rearaxleNo.Text)

        p.Add("@ref4", ref4.Text)
        p.Add("@ref5", ref5.Text)
        p.Add("@ref6", ref6.Text)
        p.Add("@ref7", ref7.Text)
        p.Add("@ref8", ref8.Text)

        p.Add("@qty", 1)

        p.Add("@unique_no", papa.g10.Text("unique_no"))
        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnFrameEnd", p)

        papa.open("pdk050_g10")
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click

        Dim answer As Integer
        answer = MsgBox("Would you like to 'START' this Frame Number?" + vbNewLine + vbNewLine + vinNo.Text, vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g10.Text("job_no"))
        p.Add("@set_line", papa.g10.Text("set_line"))
        p.Add("@line_cd", papa.g10.Text("line_cd"))
        p.Add("@line_sq", papa.g10.Text("line_sq"))

        p.Add("@vin_no", vinNo.Text)
        p.Add("@mission_no", missionNo.Text)
        p.Add("@key_no", keyNo.Text)
        p.Add("@cabin_no", cabinNo.Text)
        p.Add("@cargo_no", cargoNo.Text)
        p.Add("@rearaxle_no", rearaxleNo.Text)

        p.Add("@ref4", ref4.Text)
        p.Add("@ref5", ref5.Text)
        p.Add("@ref6", ref6.Text)
        p.Add("@ref7", ref7.Text)
        p.Add("@ref8", ref8.Text)

        p.Add("@qty", 0)

        p.Add("@unique_no", papa.g10.Text("unique_no"))
        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnFrameStart", p)

        papa.open("pdk050_g10")

    End Sub

    Private Sub btnExec_Click(sender As Object, e As EventArgs) Handles btnExec.Click

        If Not (checkEngineNo()) Then
            Exit Sub
        End If

        If Not (checkEditable()) Then
            Exit Sub
        End If

        Dim answer As Integer
        answer = MsgBox("Would you like to EXCUTIOM this Frame Number?" + vbNewLine + vbNewLine + vinNo.Text, vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g10.Text("job_no"))
        p.Add("@job_order", papa.g10.Text("job_ord"))
        p.Add("@set_line", papa.g10.Text("set_line"))
        p.Add("@line_cd", papa.g10.Text("line_cd"))
        p.Add("@line_sq", papa.g10.Text("line_sq"))

        p.Add("@vin_no", vinNo.Text)
        p.Add("@mission_no", missionNo.Text)
        p.Add("@key_no", keyNo.Text)
        p.Add("@cabin_no", cabinNo.Text)
        p.Add("@cargo_no", cargoNo.Text)
        p.Add("@rearaxle_no", rearaxleNo.Text)

        p.Add("@ref4", ref4.Text)
        p.Add("@ref5", ref5.Text)
        p.Add("@ref6", ref6.Text)
        p.Add("@ref7", ref7.Text)
        p.Add("@ref8", ref8.Text)

        p.Add("@qty", 1)

        p.Add("@unique_no", papa.g10.Text("unique_no"))
        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnFrameExec", p)

        papa.open("pdk050_g10")
    End Sub

    Private Sub ChkNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles ChkNo.TextChanging
        sel_start = ChkNo.SelectionStart
        sel_leght = ChkNo.SelectionLength
        ChkNo.Text = UCase(ChkNo.Text)
        ChkNo.SelectionStart = sel_start
        ChkNo.SelectionLength = sel_leght
        If Not (checkEngineNo()) Then
            Exit Sub
        End If
    End Sub

    Private Function checkEngineNo() As Boolean
        Dim rtnboolean As Boolean

        rtnboolean = True

        If papa.chkBlock Then
            Return rtnboolean
        Else
            If (papa.g10.Text("set_line") = "SET0016" And papa.g10.Text("line_cd") = "F1 A1 Engine Ship" And papa.z_kioskCd.Text = "PD350270") Or _
               (papa.g10.Text("set_line") = "SET0017" And papa.g10.Text("line_cd") = "DKD Engine Ship" And papa.z_kioskCd.Text = "PD350390") Or _
               (papa.g10.Text("set_line") = "SET0018" And papa.g10.Text("line_cd") = "F2 A1 Engine Ship" And papa.z_kioskCd.Text = "PD350520") Or _
               (papa.g10.Text("set_line") = "SET0020" And papa.g10.Text("line_cd") = "F2 A2 Engine Ship" And papa.z_kioskCd.Text = "PD350620") Then

                If papa.g10.Text("engine_no") <> ChkNo.Text Then
                    MsgBox("Check Engine No")
                    rtnboolean = False
                End If
            End If
        End If

        Return rtnboolean

    End Function

    Private Function checkEditable() As Boolean
        Dim rtnboolean As Boolean

        rtnboolean = True

        If papa.chkBlock Then
            Return rtnboolean
        Else
            If missionNo.ReadOnly = False And missionNo.Text = "" Then
                MsgBox("Check Mission No")
                rtnboolean = False
            End If
            If keyNo.ReadOnly = False And keyNo.Text = "" Then
                MsgBox("Check keyNo No")
                rtnboolean = False
            End If
            If rearaxleNo.ReadOnly = False And rearaxleNo.Text = "" Then
                MsgBox("Check rearaxleNo No")
                rtnboolean = False
            End If
            If cabinNo.ReadOnly = False And cabinNo.Text = "" Then
                MsgBox("Check cabinNo No")
                rtnboolean = False
            End If
            If cargoNo.ReadOnly = False And (cargoNo.Text = "" Or cargoNo.Text.Length < 8) Then
                MsgBox("Check cargoNo No")
                rtnboolean = False
            End If

            End If

            Return rtnboolean

    End Function

#Region "ToUpper Text"


    Dim sel_start As Integer
    Dim sel_leght As Integer

    Private Sub cabinNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles cabinNo.TextChanging
        sel_start = cabinNo.SelectionStart
        sel_leght = cabinNo.SelectionLength
        cabinNo.Text = UCase(cabinNo.Text)
        cabinNo.SelectionStart = sel_start
        cabinNo.SelectionLength = sel_leght
    End Sub

    Private Sub vinNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles vinNo.TextChanging
        sel_start = vinNo.SelectionStart
        sel_leght = vinNo.SelectionLength
        vinNo.Text = UCase(vinNo.Text)
        vinNo.SelectionStart = sel_start
        vinNo.SelectionLength = sel_leght
    End Sub

    Private Sub engineNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles engineNo.TextChanging
        sel_start = engineNo.SelectionStart
        sel_leght = engineNo.SelectionLength
        engineNo.Text = UCase(engineNo.Text)
        engineNo.SelectionStart = sel_start
        cabinNo.SelectionLength = sel_leght
    End Sub

    Private Sub missionNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles missionNo.TextChanging
        sel_start = missionNo.SelectionStart
        sel_leght = missionNo.SelectionLength
        missionNo.Text = UCase(missionNo.Text)
        missionNo.SelectionStart = sel_start
        missionNo.SelectionLength = sel_leght
    End Sub

    Private Sub keyNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles keyNo.TextChanging
        sel_start = keyNo.SelectionStart
        sel_leght = keyNo.SelectionLength
        keyNo.Text = UCase(keyNo.Text)
        keyNo.SelectionStart = sel_start
        keyNo.SelectionLength = sel_leght
    End Sub

    Private Sub cargoNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles cargoNo.TextChanging
        sel_start = cargoNo.SelectionStart
        sel_leght = cargoNo.SelectionLength
        cargoNo.Text = UCase(cargoNo.Text)
        cargoNo.SelectionStart = sel_start
        cargoNo.SelectionLength = sel_leght
    End Sub

    Private Sub rearaxleNo_TextChanging(sender As Object, newValue As String, oldValue As String, ByRef cancel As Boolean) Handles rearaxleNo.TextChanging
        sel_start = rearaxleNo.SelectionStart
        sel_leght = rearaxleNo.SelectionLength
        rearaxleNo.Text = UCase(rearaxleNo.Text)
        rearaxleNo.SelectionStart = sel_start
        rearaxleNo.SelectionLength = sel_leght
    End Sub
#End Region
End Class