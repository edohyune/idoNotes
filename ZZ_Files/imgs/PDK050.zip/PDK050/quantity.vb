﻿Imports Frame8
Imports Base8
Imports Base8.Shared
Imports System.Data

Public Class quantity

    Private papa As Object
    Public Sub Set_Param(parentForm As Object)
        papa = parentForm
    End Sub


#Region "Number Button"
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        insertKey("1")
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        insertKey("2")
    End Sub
    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        insertKey("3")
    End Sub
    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        insertKey("4")
    End Sub
    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        insertKey("5")
    End Sub
    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        insertKey("6")
    End Sub
    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        insertKey("7")
    End Sub
    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        insertKey("8")
    End Sub
    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        insertKey("9")
    End Sub
    Private Sub btn0_Click(sender As Object, e As EventArgs) Handles btn0.Click
        insertKey("0")
    End Sub
    Private Sub btnDel_Click(sender As Object, e As EventArgs) Handles btnDel.Click
        insertKey("Del")
    End Sub
    Private Sub btnAll_Click(sender As Object, e As EventArgs) Handles btnAll.Click
        insertKey("All")
    End Sub

    Private Sub insertKey(p1 As String)
        If p1 = "Del" Then
            qty.Text = ""
        ElseIf p1 = "All" Then
            qty.Text = (pw_qty.ToDec - exe_qty.ToDec).ToString
        Else
            qty.Text = Val(qty.Text + p1)
        End If
    End Sub
#End Region

    Private Sub btnletOut_Click(sender As Object, e As EventArgs) Handles btnletOut.Click
        MsgBox("Not yet Using. Let Out" + vbNewLine + "if you want to using Call BMD")
        Exit Sub
    End Sub

    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        MsgBox("Error Code : #KIOSK Parts button END")
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        MsgBox("Error Code : #KIOSK Parts button Start")
    End Sub

    Private Sub btnExec_Click(sender As Object, e As EventArgs) Handles btnExec.Click
        If Not (checkQty()) Then
            Exit Sub
        End If
        Dim answer As Integer
        answer = MsgBox("Would you like to 'EXCUTION' this Parts?" + vbNewLine + vbNewLine + _
                        papa.g30.Text("itmnm") + "(" + papa.g30.Text("itmcd") + ")" + vbNewLine + _
                        "Quantity : " + qty.Text, vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If
        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g30.Text("job_no"))
        p.Add("@job_uno", papa.g30.Text("job_uno"))
        p.Add("@job_order", papa.g30.Text("job_ord"))
        p.Add("@set_line", papa.g30.Text("set_line"))
        p.Add("@line_cd", papa.g30.Text("line_cd"))
        p.Add("@line_sq", papa.g30.Text("line_sq"))

        p.Add("@mission_no", missionNo.Text)
        p.Add("@key_no", keyNo.Text)
        p.Add("@cabin_no", cabinNo.Text)
        p.Add("@cargo_no", cargoNo.Text)
        p.Add("@rearaxle_no", rearaxleNo.Text)

        p.Add("@ref4", ref4.Text)
        p.Add("@ref5", ref5.Text)
        p.Add("@ref6", ref6.Text)
        p.Add("@ref7", ref7.Text)
        p.Add("@ref8", ref8.Text)

        p.Add("@qty", qty.Text)

        p.Add("@unique_no", papa.g30.Text("unique_no"))
        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain


        papa.open("pdk050_btnQuantityExec", p)

        papa.open("pdk050_g30")

    End Sub

    Private Function checkQty() As Boolean
        Dim rtnboolean As Boolean
        rtnboolean = True

        If pw_qty.ToDec - exe_qty.ToDec - qty.ToDec < 0 Then
            MsgBox("Qty Error")
            qty.Text = ""
            rtnboolean = False
        End If

        Return rtnboolean
    End Function

    Private Sub EButton1_Click(sender As Object, e As EventArgs) Handles EButton1.Click
        If Not (checkQty()) Then
            Exit Sub
        End If

        Dim answer As Integer
        answer = MsgBox("Would you like to 'EXCUTION' this Parts?" + vbNewLine + vbNewLine + _
                        papa.g30.Text("itmnm") + "(" + papa.g30.Text("itmcd") + ")" + vbNewLine + _
                        "Quantity : " + qty.Text, vbQuestion + vbYesNo)
        If answer <> vbYes Then
            Exit Sub
        End If

        Dim p As OpenParameters = New OpenParameters

        p.Add("@co_cd", "01")
        p.Add("@kiosk_cd", papa.z_kioskCd.Text)

        p.Add("@job_no", papa.g30.Text("job_no"))
        p.Add("@job_uno", papa.g30.Text("job_uno"))
        p.Add("@job_order", papa.g30.Text("job_ord"))
        p.Add("@set_line", papa.g30.Text("set_line"))
        p.Add("@line_cd", papa.g30.Text("line_cd"))
        p.Add("@line_sq", papa.g30.Text("line_sq"))

        p.Add("@mission_no", missionNo.Text)
        p.Add("@key_no", keyNo.Text)
        p.Add("@cabin_no", cabinNo.Text)
        p.Add("@cargo_no", cargoNo.Text)
        p.Add("@rearaxle_no", rearaxleNo.Text)

        p.Add("@ref4", ref4.Text)
        p.Add("@ref5", ref5.Text)
        p.Add("@ref6", ref6.Text)
        p.Add("@ref7", ref7.Text)
        p.Add("@ref8", ref8.Text)

        p.Add("@qty", qty.Text)

        p.Add("@unique_no", papa.g30.Text("unique_no"))
        p.Add("@dt", papa.z_today.Text)

        p.Add("@isadmin", papa.z_ismanager.text) 'checked admain

        papa.open("pdk050_btnQuantityExec", p)

        papa.open("pdk050_g30")
    End Sub
End Class