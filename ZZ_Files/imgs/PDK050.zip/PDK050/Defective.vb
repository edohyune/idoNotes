﻿Imports System8.PDK051
Imports System8

Public Class Defective

    Private popup2 As PDK051
    Public Sub InitPopUP(Frm As Object, vinNo As String)
        popup2 = New PDK051

        If popup2 IsNot Nothing Then
            popup2.Dock = Windows.Forms.DockStyle.Fill

            '            'popup 화면에 버턴이 있다면 popup내에서 제어해도 되고 여기서도 제어 가능하다

            '            'AddHandler PopUp.btn_exit.Click, AddressOf btn_exit_click
            '            'AddHandler PopUp.btn_ok.Click, AddressOf btn_ok_click
            '            'AddHandler PopUp.btn_save.Click, AddressOf btn_save_click
            'PopUp.Tag = pParam
            Me.Controls.Add(popup2)

            popup2.Init()

            popup2.Set_Param(Frm, vinNo)
        End If
    End Sub

    Sub openGrid(p1 As String)
        popup2.Open_Param(p1)
    End Sub

    Sub initKiosk(btn_ty As String, letOut As String)
        popup2.initKiosk(btn_ty, letOut)
    End Sub



End Class